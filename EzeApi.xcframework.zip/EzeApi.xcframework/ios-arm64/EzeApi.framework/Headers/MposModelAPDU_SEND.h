//
//  MposModelAPDU_SEND.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the data sent to ICC/PICC, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelAPDU_SEND : NSObject

/*!
 @abstract command(CLA, INS, P1, P2), 4 bytes
 */
@property Byte* Command; // [4]

/*!
 @abstract length of data to send
 */
@property UInt16 Lc;

/*!
 @abstract data to send, maximum length is 512 bytes
 */
@property Byte* DataIn; // [512];

/*!
 @abstract expeted data length to be return
 */
@property UInt16 Le;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;
- (id)initWithCmd:(Byte  *)cmd withData:(Byte *)dataIn withDataLen:(UInt32)lc withExpLen:(UInt16)le;


@end
