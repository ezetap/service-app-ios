//
//  MposModelST_KCV_INFO.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the KCV information, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelST_KCV_INFO : NSObject

/*!
 @abstract
 KCV check mode
 @discussion
 Note: when using @link //apple_ref/occ/instm/MposApiPedManager/pedGetKcvWithKeyType:keyIdx:kcvInfoInOut: @/link, mode 0 is actually the same as mode 1 in @link //apple_ref/occ/instm/MposApiPedManager/pedWriteKeyWithKeyInfo:withKcv: @/link
 */
@property Byte iCheckMode;

/*!
 @abstract
 KCV related data
 @discussion
 see @link //apple_ref/occ/instm/MposApiPedManager/pedGetKcvWithKeyType:keyIdx:kcvInfoInOut: @/link , @link //apple_ref/occ/instm/MposApiPedManager/pedWriteKeyWithKeyInfo:withKcv: @/link , @link //apple_ref/occ/instm/MposApiPedManager/pedWriteTIKWithGroupIdx:srcKeyIdx:keyLen:keyValue:ksn:kcvInfo: @/link.<br>
 maximum total length is 128 bytes.	 
 */
@property Byte *aucCheckBuf; // [128];
    
/*!
 @abstract
 a flag indicating whether it's doing get kcv or not.
 @discussion
 <b>only for internal use, APP should ignore this flag.</b>
 when calling @link //apple_ref/occ/instm/MposApiPedManager/pedGetKcvWithKeyType:keyIdx:kcvInfoInOut: @/link, MUST set to true, set to false in other cases.
 */
@property BOOL isForGetKcv;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
