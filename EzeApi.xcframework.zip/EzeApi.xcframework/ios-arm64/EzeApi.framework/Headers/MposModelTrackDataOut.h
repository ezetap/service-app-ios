//
//  MposModelTrackDataOut.h
//  MposApi
//
//  Created by admin on 8/28/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelDataWithEncryptionMode.h"

@interface MposModelTrackDataOut : NSObject
/*!
 *@abstract the generated track1 data.
 */
@property NSData *track1;

/*!
 @abstract the generated track2 data.
 */
@property NSData *track2;

/*!
 @abstract the generated track3 data.
 */
@property NSData *track3;

/*!
 @abstract card number with mask of asterisk. eg: 47617390*****010.
 it's used when encMode != CLEAR.
 */
@property NSString *maskedPan;

/*!
 @abstract data encryption mode, see @link //apple_ref/c/econst/EncryptionMode @/link
 if encMode == SENSITIVE_CIPHER_DUKPTDES, it shows that the tracks is encrypted with DUKPT.
 if encMode == SENSITIVE_CIPHER_MSKEY, it shows that the tracks is encrypted with MSKEY.
 */
@property EncryptionMode encMode;

/*!
 @abstract the current KSN, maybe 10 bytes or nil. it is used to decrypt the tracks when encMode == SENSITIVE_CIPHER_DUKPTDES.
 */
@property NSData *ksn;

/*!
 @abstract service code
 */
@property NSData *serviceCode;

- (id)initTrackDataOutWithEncMode:(EncryptionMode)encMode ksn:(NSData*)ksnData track1:(NSData*)t1 track2:(NSData*)t2 track3:(NSData*)t3 maskedPan:(NSString*)pan serviceCode:(NSData*)servicecode;
@end
