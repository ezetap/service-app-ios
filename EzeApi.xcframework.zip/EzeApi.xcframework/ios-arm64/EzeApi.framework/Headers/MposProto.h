//
//  Proto.h
//  MposApi
//
//  Created by admin on 5/28/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposCmd.h"
#import "MposRespCode.h"
#import "MposApiRetCodes.h"

@protocol MposApiEmvManagerDelegate;

@interface MposProto : NSObject

@property (nonatomic, weak) id<MposApiEmvManagerDelegate> emvDelegate;

+ (id)sharedInstance;

- (Byte)lrcOfData:(const Byte *)data from:(UInt32)offset withLen:(NSUInteger)len;

- (SInt32)sendCmdWaitAck:(MposCmdType)cmd withData:(const Byte  *)req withLen:(NSUInteger)len;
- (SInt32)processResponse:(MposCmdType)cmd respCode:(MposRespCode  *)respCode respData:(Byte *)resp respDataLen:(UInt32 *)respLen;
- (SInt32)processPassiveCmd:(MposCmdType)cmd withData:(const Byte *)resp withLen:(NSUInteger)len;
- (BOOL)sendCmd:(MposCmdType)cmd withData:(const Byte *)req withLen:(NSUInteger)len;
- (MposApiRetCode)sendCmd:(MposCmdType)cmd withData:(const Byte *)req withLen:(NSUInteger)len respData:(Byte *)resp respDataLen:(UInt32  *)respLen;

-(void)close;
-(void)setupTimeouts:(SInt32)timeout;

@end
