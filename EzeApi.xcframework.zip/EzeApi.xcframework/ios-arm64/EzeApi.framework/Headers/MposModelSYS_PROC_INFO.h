//
//  MposModelSYS_PROC_INFO.h
//  MposApi
//
//  Created by admin on 6/6/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelTRAN_LOG.h"

@interface MposModelSYS_PROC_INFO : NSObject

/*!
 @abstract
 0:KERNTYPE_DEF<br>
 1:KERNTYPE_JCB<br>
 2:KERNTYPE_MC<br>
 3:KERNTYPE_VIS<br>
 4:KERNTYPE_PBOC<br>
 5:KERNTYPE_AE<br>
 6:KERNTYPE_ZIP<br>
 */
@property Byte currentClssType;


/*!
 @abstract
 0:CLSS_PATH_NORMAL<br>
1:CLSS_VISA_MSD<br>
2:CLSS_VISA_QVSDC<br>
3:CLSS_VISA_VSDC<br>
4:CLSS_VISA_CONTACT<br>
5:CLSS_MC_MAG<br>
6:CLSS_MC_MCHIP<br>
7:CLSS_VISA_WAVE2<br>
8:CLSS_JCB_WAVE2 <br>
9:CLSS_VISA_MSD_CVN17<br>
10:CLSS_VISA_MSD_LEGACY<br>
11:CLSS_JCB_MAG<br>
12:CLSS_JCB_EMV<br>
13:CLSS_LEGACY<br>
14:CLSS_DPAS_MAG<br>
15:CLSS_DPAS_EMV<br>
16:CLSS_DPAS_ZIP<br>
17:CLSS_AE_MAG<br>
18:CLSS_AE_EMV<br>
*/
@property Byte currentPathType;


/*!
 @abstract
 0x00:cvm_no <br>
 0x10:cvm_sig<br>
 0x11:cvm_onlinePin<br>
 0x12:cvm_offlinePin<br>
 0x1F:cvm_consumer_device<br>
 */
@property Byte cvmMethods;


/*!
 @abstract
 0x00:offline declined(AAC) <br>
 0x01:offline approved(TC)<br>
 0x02:online request(ARQC)<br>
 */
@property Byte cardProcessResult;


/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
