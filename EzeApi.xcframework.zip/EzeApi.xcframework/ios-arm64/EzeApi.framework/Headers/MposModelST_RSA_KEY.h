//
//  MposModelST_RSA_KEY.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the RSA KEY information, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelST_RSA_KEY : NSObject

/*!
 @abstract
 the length of modulus, in bits.
 */
@property UInt32 iModulusLen;

/*!
 @abstract
 modulus, &lt;= 512 bytes
 */
@property Byte *aucModulus; // [512];

/*!
 @abstract
 the length of exponent, in bits
 */
@property UInt32 iExponentLen;

/*!
 @abstract
 exponent, in bits, &lt;= 512 bytes
 */
@property Byte *aucExponent; // [512];

/*!
 @abstract
 key info, defined by application, maximum 128 bytes
 */
@property Byte *aucKeyInfo; // [128];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
