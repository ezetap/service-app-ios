//
//  MposApiEmvManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelEMV_APPLABEL_LIST.h"
#import "MposModelEMV_CANDLIST.h"
#import "MposModelEMV_APPLIST.h"
#import "MposModelEMV_CAPK.h"
#import "MposModelEMV_MCK_PARAM.h"
#import "MposModelEMV_PARAM.h"
#import "MposModelEMV_REVOC_LIST.h"
#import "MposModelEMV_ELEMENT_ATTR.h"
#import "MposModelEMV_TM_ECP_PARAM.h"
#import "MposModelCLSS_TRANS_PARAM.h"
#import "MposApiRetCodes.h"
#import "MposModelDataWithEncryptionMode.h"
#import "MposDebugInfo.h"
#import "MposICCStatus.h"

/*!
 @abstract OK
 */
#define EMV_OK                          0

/**** return codes for delegate ****/

//for onWaitAppSelWithTryCnt
/*!
 @abstract user cancel
 */
#define EMV_USER_CANCEL					(-7)
/*!
 @abstract timeout
 */
#define EMV_TIME_OUT					(-8)

/*!
 @abstract Enumeration of input amount result
 @discussion 
 @constant EMV_INPUT_AMT_OK             input amount normally
 @constant EMV_INPUT_AMT_USER_CANCEL    input amount cancelled
 @constant EMV_INPUT_AMT_TIME_OUT       input amount time out
 */
typedef enum {
    EMV_INPUT_AMT_OK                    = 0,
    EMV_INPUT_AMT_USER_CANCEL			= -7,
    EMV_INPUT_AMT_TIME_OUT				= -8,
}EmvInputAmtResult;

/*!
 @abstract Enumeration of input password result
 @discussion
 @constant EMV_GET_HOLDER_PWD_OK            input password normally
 @constant EMV_GET_HOLDER_PWD_USER_CANCEL   input password cancelled
 @constant EMV_GET_HOLDER_PWD_TIME_OUT      input password time out
 @constant EMV_GET_HOLDER_PWD_NO_PINPAD     NO PINPAD
 @constant EMV_GET_HOLDER_PWD_NO_PASSWORD   NO password or user cancelled
 */
typedef enum {
    EMV_GET_HOLDER_PWD_OK               = 0,
    EMV_GET_HOLDER_PWD_USER_CANCEL		= -7,
    EMV_GET_HOLDER_PWD_TIME_OUT			= -8,
    EMV_GET_HOLDER_PWD_NO_PINPAD     	= -13,
    EMV_GET_HOLDER_PWD_NO_PASSWORD   	= -14,
}EmvGetHolderPwdResult;

//for onReferProc
/*!
 @abstract Enumeration of handling referral result
 @discussion
 @constant EMV_REFER_APPROVE                transaction approved
 @constant EMV_REFER_DENIAL                 transaction denial
 */
typedef enum {
    EMV_REFER_APPROVE 					= 1,
    EMV_REFER_DENIAL  					= 2,
}EmvReferResult;

//for onOnlineProc
/*!
 @abstract Enumeration of online process result
 @discussion
 @constant EMV_ONLINE_APPROVE               online approved
 @constant EMV_ONLINE_FAILED                online failed
 @constant EMV_ONLINE_REFER                 online referral
 @constant EMV_ONLINE_DENIAL                online denial
 @constant EMV_ONLINE_ABORT                 online abort(for PBOC)
 */
typedef enum {
    EMV_ONLINE_APPROVE 					= 0,
    EMV_ONLINE_FAILED 					= 1,
    EMV_ONLINE_REFER 					= 2,
    EMV_ONLINE_DENIAL 					= 3,
    EMV_ONLINE_ABORT 					= 4,
}EmvOnlineProcResult;

//for onUnknownTLVData
/*!
 @abstract Enumeration of unknown TAG handling result
 @discussion
 @constant EMV_UNKNOWN_TAG_VALUE_PROVIDED               tag value provided
 @constant EMV_UNKNOWN_TAG_VALUE_IGNORED                tag value ignored
 */
typedef enum {
    EMV_UNKNOWN_TAG_VALUE_PROVIDED 		= 0,
    EMV_UNKNOWN_TAG_VALUE_IGNORED 		= -1,
}EmvUnknownTagProcessFlag;

//for onCertVerify
/*!
 @abstract Enumeration of cardholder verify(PBOC2.0) result
 @discussion 
    PBOC2.0 adds the CVM, which is for cardholder credential verify. During the transaction, 
    when the EMV kernel finds that the current used PBOC card need to do the cardholder verify, it will call this function. 
 @constant EMV_CERT_VERIFY_OK              Verify succeeded
 @constant EMV_CERT_VERIFY_ERR             Verify failed
 */
typedef enum {
    EMV_CERT_VERIFY_OK 					= 0,
    EMV_CERT_VERIFY_ERR 				= 1,
}EmvCertVerifyResult;

/***** macros ****/
//for setScriptProcMethod
/*!
 @abstract Enumeration of issuer script processing method
 @discussion 
 @constant EMV_SCRIPT_PROC_NORMAL        EMV normal processing method (default)
 @constant EMV_SCRIPT_PROC_UNIONPAY      CUP processing method
 */
typedef enum {
    EMV_SCRIPT_PROC_NORMAL  	= 0,
    EMV_SCRIPT_PROC_UNIONPAY  	= 1,
}EmvScriptProcFlag;

/*!
 @abstract APP selection matching type enumeration
 @discussion 
 @constant EMV_APP_SEL_PARTIAL_MATCH    partial matching
 @constant EMV_APP_SEL_FULL_MATCH       full matching
 */
typedef enum {
    EMV_APP_SEL_PARTIAL_MATCH  	= 0,
    EMV_APP_SEL_FULL_MATCH  	= 1,
}EmvAppSelFlag;

//for startTrans/completeTrans/procTrans: result and ac type
/*!
 @abstract transaction result enumeration
 @discussion 
 @constant EMV_TRANS_RESULT_OK           trasaction ok
 @constant EMV_TRANS_RESULT_NOT_ACCEPT   trasaction not accept
 @constant EMV_TRANS_RESULT_DENIAL       trasaction denial
 */
typedef enum {
    EMV_TRANS_RESULT_OK			= 0,
    EMV_TRANS_RESULT_NOT_ACCEPT	= -10,
    EMV_TRANS_RESULT_DENIAL		= -11,
}EmvTransResult;

/*!
 @abstract AC type enumeration
 @discussion 
 @constant EMV_AC_AAC           terminal request TC, but rejected by Card CID
 @constant EMV_AC_TC            transaction approved
 @constant EMV_AC_ARQC          online
 @constant EMV_AC_AAC_HOST      rejected because of online transaction returns EMV_ONLINE_DENIAL
 */
typedef enum {
    EMV_AC_AAC       			= 0,
    EMV_AC_TC        			= 1,
    EMV_AC_ARQC      			= 2,
    EMV_AC_AAC_HOST  			= 3,
}EmvAcType;

//for EMV_PARAM.TransType
/*!
 @abstract EMV transaction type enumeration
 @discussion 
 @constant EMV_TRANS_TYPE_CASH          cash
 @constant EMV_TRANS_TYPE_GOODS       	goods
 @constant EMV_TRANS_TYPE_SERVICE       service
 @constant EMV_TRANS_TYPE_CASHBACK      cashback
 @constant EMV_TRANS_TYPE_INQUIRY       inquiry
 @constant EMV_TRANS_TYPE_TRANSFER      transfer
 @constant EMV_TRANS_TYPE_PAYMENT       payment
 @constant EMV_TRANS_TYPE_ADMIN         administration
 @constant EMV_TRANS_TYPE_CASHDEPOSIT   cash deposit
 */
typedef enum {
    EMV_TRANS_TYPE_CASH			= 0x01,
    EMV_TRANS_TYPE_GOODS		= 0x02,
    EMV_TRANS_TYPE_SERVICE      = 0x04,
    EMV_TRANS_TYPE_CASHBACK     = 0x08,
    EMV_TRANS_TYPE_INQUIRY		= 0x10,
    EMV_TRANS_TYPE_TRANSFER	  	= 0x20,
    EMV_TRANS_TYPE_PAYMENT		= 0x40,
    EMV_TRANS_TYPE_ADMIN		= 0x80,
    EMV_TRANS_TYPE_CASHDEPOSIT  = 0x90,
}EmvTransType;

//for setConfigFlag
/*!
 @abstract EMV config flags
 @discussion 
 @constant EMV_CONFIG_FLAG_BIT_SUPPORT_ADVICE               bit mask of flag of whether to support advice
 @constant EMV_CONFIG_FLAG_BIT_CONFIRM_AMT_WHEN_NO_PIN      bit mask of flag of whether to ask user to confirm when no PIN input is required
 @constant EMV_CONFIG_FLAG_BIT_SUPPORT_TRANSLOG             bit mask of flag of whether to support transaction log
 */
typedef enum {
    EMV_CONFIG_FLAG_BIT_SUPPORT_ADVICE 				= 0x01,
    EMV_CONFIG_FLAG_BIT_CONFIRM_AMT_WHEN_NO_PIN 	= 0x02,
    EMV_CONFIG_FLAG_BIT_SUPPORT_TRANSLOG 			= 0x04,
}EmvConfigFlag;

//for onGetHolderPwd: pinflag/pinstatus
/*!
 @abstract EMV PIN flags
 @discussion 
 @constant EMV_PIN_FLAG_NO_PIN_REQUIRED     no PIN required, but need to show amount to card holder.
 @constant EMV_PIN_FLAG_ONLINE              ONLINE PIN
 @constant EMV_PIN_FLAG_OFFLINE             OFFLINE PIN
 */
typedef enum {
    EMV_PIN_FLAG_NO_PIN_REQUIRED		= 0,
    EMV_PIN_FLAG_ONLINE                 = 1,
    EMV_PIN_FLAG_OFFLINE				= 2,
}EmvPinFlag;

/*!
 @abstract EMV OFFLINE PIN status
 @discussion 
 @constant EMV_OFFLINE_PIN_STATUS_PED_TIMEOUT     PIN input timeout
 @constant EMV_OFFLINE_PIN_STATUS_PED_WAIT        PIN input interval not enough
 @constant EMV_OFFLINE_PIN_STATUS_PED_FAIL        PED locked or other failure
 */
typedef enum {
    EMV_OFFLINE_PIN_STATUS_PED_TIMEOUT  = 1,
    EMV_OFFLINE_PIN_STATUS_PED_WAIT 	= 2,
    EMV_OFFLINE_PIN_STATUS_PED_FAIL 	= 3,
}EmvOfflinePinStatus;

/*!
 @abstract EMV Manager delegate, APP should implement this interface.
 */
@protocol MposApiEmvManagerDelegate <NSObject>

@required

/*!
 @abstract <b><font color="red">NOTE: for D180, this function will not be called </font></b><br>
 Wait for user to select an application from the application candidate list. If there is only one application in the application list and it doesn't require cardholder confirmation, this function will not be called.
 @param tryCnt
 TryCnt=0 means it is called for the first time, otherwise, it has been called more than one time. (According to the EMV specification, if this function has been called more than one time, terminal should prompt for 'APP NOT ACCEPT, TRY AGAIN' or some other word like that.).
 @param appNum
 The number of the application in the list.
 @param apps
 [input]a pointer to the applications array
 @result
 >=0: The sequence number selected by the user(For example: 0 stands for apps[0] was selected) <br>
 @link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link: Application selection is canceled by user<br>
 @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link: Application selection timeout.
 */
- (SInt32)onWaitAppSelWithTryCnt:(UInt32)tryCnt appNum:(UInt32)appNum apps:(MposModelEMV_APPLIST**) apps;

/*!
 @abstract <b><font color="red">NOTE: only for D180 </font></b><br> Wait for user to select an application from the application candidate list. If there is only one application in the application list and it doesn't require cardholder confirmation, this function will not be called.
 @param tryCnt
 TryCnt=0 means it is called for the first time, otherwise, it has been called more than one time. (According to the EMV specification, if this function has been called more than one time, terminal should prompt for 'APP NOT ACCEPT, TRY AGAIN' or some other word like that.).
 @param appNum
 The number of the application in the list.
 @param apps
 [input]a pointer to the applications array
 @result
 >=0: The sequence number selected by the user(For example: 0 stands for apps[0] was selected) <br>
 @link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link: Application selection is canceled by user<br>
 @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link: Application selection timeout.
 */
- (SInt32)onCandAppSelWithTryCnt:(UInt32)tryCnt appNum:(UInt32)appNum apps:(MposModelEMV_CANDLIST**) apps;

/*!
 @abstract Input transaction amount.
 @param authAmount
 [output]transaction amount
 @param cashbackAmountOrNil
 [output]cashback amount. give Nil if not interested in it <br>
 <b>Note, the amount MUST be presented with the smallest unit</b>
 @result
 input amount result
 */
- (EmvInputAmtResult)onInputAuthAmount:(NSString **)authAmount cashbackAmount:(NSString **)cashbackAmountOrNil;

/*!
 @abstract Wait for cardholder to input PIN.
 @param pinFlag
 pinFlag
 @param tryFlag
 valid only when pinFlag is @link //apple_ref/c/econst/EMV_PIN_FLAG_OFFLINE @/link<br>
 0 : It's the first time calling this function to get the cardholder's PIN in this transaction <br>
 1 : It's not the first time calling this function to get the cardholder's PIN in this transaction. (It appears only when verifying the offline PIN and failing). <br>
 @param remainCnt
 valid only when pinFlag is @link //apple_ref/c/econst/EMV_PIN_FLAG_OFFLINE @/link<br>
 The chance remained to verify the PIN. If RemainCnt equals 1, it means only one chance remained to verify the PIN, and if the following PIN verification is still failed, the PIN will be blocked
 @param pinStatus
 valid only when pinFlag is @link //apple_ref/c/econst/EMV_PIN_FLAG_OFFLINE @/link<br>
 PIN status
 @result
 the result of handling getting holder password
 */
- (EmvGetHolderPwdResult)onGetHolderPwdWithPinFlag:(EmvPinFlag)pinFlag tryFlag:(UInt32)tryFlag remainCnt:(UInt32)remainCnt pinStatus:(EmvOfflinePinStatus)pinStatus;

/*!
 @abstract <b><font color="red">NOTE: for D180, this function will not be called </font></b><br>
 Process referral activated by the issuer
 @result
 the result of handling referral
 */
- (EmvReferResult)onReferProc;

/*!
 @abstract <b><font color="red">NOTE: for D180, this function will not be called </font></b><br>
 Online transaction.
 @param respCode
 [output] Authorization response code, 2 bytes. Set RspCode[0] as 0 in case of online failed.
 @param authCode
 [output] 1 byte length + Authorization code, length is 0 if there's no Authorization code.
 @param authData
 [output] 4 bytes length + Issuer authentication data returned from host, length is 0 if there's no Issuer authentication data.
 @param script
 [output] 4 bytes length + Issuer script. If the scripts are not sent in one 8583 field, then put all the scripts together and return by this parameter. length is 0 if there's no issuer script.
 @result
 the result of online processing
 */
- (EmvOnlineProcResult)onOnlineProcWithRespCode:(Byte[2])respCode authCode:(Byte *)authCode authData:(Byte *)authData script:(Byte *)script;

/*!
 @abstract <b><font color="red">NOTE: for D180, this function will not be called </font></b><br>
 Online or offline advice processing
 */
- (void)onAdviceProc;
/*!
 @abstract Prompt for "PIN OK"
 */
- (void)onVerifyPinOk;

/*!
 @abstract <b><font color="red">NOTE: for D180, this function will not be called </font></b><br>
 Get the data of the unknown tag.
 @param tag
 Tag. It may be not defined by EMV, or defined by EMV but can't be found in the IC card.
 @param len
 The length of the tag according to the DOL requirement.
 @param value
 [output] The value of the tag, filled by the application.
 @result
 the result of processing unknown tag
 */
- (EmvUnknownTagProcessFlag)onUnknownTLVDataForTag:(SInt16)tag withLen:(UInt32)len withValue:(Byte *)value;

/*!
 @abstract Cardholder credential verify(PBOC2.0)
 @discussion
 PBOC2.0 adds the CVM, which is for cardholder credential verify. During the transaction, when the EMV kernel finds that the current used PBOC card need to do the cardholder verify, it will call this function.
 The application should call the function @link //apple_ref/occ/instm/MposApiEmvManager/getTLVDataForTag:value: @/link  to read the credential number and credential type, and provide the relevant information to the operator.
 This function is only used for PBOC.
 @result
 the result of cert verifying
 */
- (EmvCertVerifyResult)onCertVerify;

/*!
 @abstract Set parameter after application selection.
 @discussion
 1.This function is used to set some AID specific parameter after performing application selection and before GPO.
 2.Application can call @link //apple_ref/occ/instm/MposApiEmvManager/setTLVDataForTag:withValue: @/link in this function to set these parameters.
 3.When the return value of this function is not @link //apple_ref/c/macro/EMV_OK @/link, kernel will abort the current transaction.
 4.if terminal supports SM algorithm, should set value of tag 0xDF69 to 1
 @result
 @link //apple_ref/c/macro/EMV_OK @/link: Succeed<br>
 others: Abort/Terminate current transaction.
 */
- (SInt32)onSetParam;

@end

/*!
 @abstract MposApiEmvManager is used to process EMV transation
 */
@interface MposApiEmvManager : NSObject

/*!
 @abstract EMV delegate
 */
@property (weak, nonatomic) id<MposApiEmvManagerDelegate> delegate;

/*!
 @abstract get MposApiEmvManager shared instance
 @result
 MposApiEmvManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Get terminal parameter.
 @discussion
 @param emvParam
    terminal parameter
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getParameter:(MposModelEMV_PARAM *)emvParam;

/*!
 @abstract set terminal parameter
 @param emvParam
 		terminal parameter.
 @result
    return code.
 */
- (MposApiRetCode)setParameter:(const MposModelEMV_PARAM *)emvParam;

/*!
 @abstract Get the value of the data element by specifying the tag.
 @param tag
 [input] Tag of EMV standard or extended data element.
 @param mode
 [input] encryption mode see @link //apple_ref/c/econst/EncryptionMode @/link
 @param index
 [input] index of the key to be used when mode != CLEAR.
 @param value
    [output]value of the specified tag 
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getTLVDataForTag:(UInt16)tag mode:(EncryptionMode)mode keyIndex:(Byte)index value:(MposModelDataWithEncryptionMode **)value;

/*!
 @abstract Set the value of the data element by specifying the tag.
 @param tag
 Tag of EMV standard or extended data element.
 @param value
 [input]The value of the data element specified by the tag.
 @result
 return code.
 */
- (MposApiRetCode)setTLVDataForTag:(UInt16)tag withValue:(const NSData *)value;

/*!
 @abstract Get the issuer script processing result.
 @param result
 [output]issuer script processing result
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getScriptResult:(NSData **)result;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Set PCI offline PIN verification parameter
 @param timeout
 Timeout of input PIN, unit: ms, maximum 300,000 ms. 	
 @param expPinLen
 the allowed length of PIN. It is a string of the enumeration of 0-12 and separated by ','. For example, '0,4,6' means it is allowed to input 4 or 6 digits for PIN, and to directly press Enter without input PIN.
 @result
 return code.
 */
- (MposApiRetCode)setPciModeParamWithTimeout:(UInt32)timeout expPinLen:(const NSString  *)expPinLen;

/*!
 @abstract Get the version of EMV kernel and the release date.
 @param ver
 [output]Version and release date of kernel with the maximum length of 20 bytes. For example, "v26 2008.10.09".
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)readVerInfo:(NSString **)ver;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Clear the transaction log of kernel.
 @discussion
 1.Kernel will record the amount of the last 8 transactions. When performing terminal risk management, kernel will add the amount of current transaction with the amount of the last transaction found in the log giving that the PAN is same and the result will be used for floor limit check.
 2.This function is provided for application to erase this log after settlement or other cases when necessary.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)clearTransLog;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 add proprietary data elements
 @discussion
 1.Kernel only supports EMV defined standard data element. This function is used to add the list of any proprietary data elements to kernel so it will save the corresponding ones. Thus the application can access the data through @link //apple_ref/occ/instm/MposApiEmvManager/getTLVDataForTag:value: @/link
 2.Refer to appendix E for structure @link //apple_ref/c/tdef/EmvElementAttrType @/link. The number in the list must equal nAddNum. MaxLen and Tag must not be zero. Otherwise, parameter error will be returned.
 3.Each time calling this function, kernel will replace the original list.
 4.If data duplicate happens when reading ICC, the latest data will be used.
 @param attr
    [input]a pointer to the array of issuer proprietary data elements
 @param num
    number of objects in the array
 @result
 return code.
 */
- (MposApiRetCode)addIccTagWithAttr:(const MposModelEMV_ELEMENT_ATTR **)attr withNum:(UInt32)num;

/*!
 @abstract
 set issuer script processing method
 @param method
 Issuer script processing method
 @result
 return code.
 */
- (MposApiRetCode)setScriptProcMethod:(EmvScriptProcFlag)method;

/*!
 @abstract Add a new CA public key.
 @discussion Overwrites if already exsists. CAPK is provided by the acquirer, if it does not conform to  @link //apple_ref/occ/cl/MposModelEMV_CAPK @/link, please convert it first.
 @param capk
 CA public key
 @result
 return code.
 */
- (MposApiRetCode)addCAPK:(const MposModelEMV_CAPK *)capk;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Delete a CA public key.
 @param keyId
 The index of the key.
 @param rid
[input]Registered Application Provider Identifier.
 @result
 return code.
 */
- (MposApiRetCode)delCAPKWithKeyId:(UInt32)keyId rid:(const Byte[5])rid;

/*!
 @abstract Delete all CA public key.
 @result
 return code.
 */
- (MposApiRetCode)delAllCAPK;

/*!
 @abstract Get a CA public key.
 @param keyId
 The key storage index.
 @param capkOut
 [output]CAPK for specified index
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getCAPKWithKeyId:(UInt32)keyId capkOut:(MposModelEMV_CAPK *)capkOut;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Check the validity of the public keys.
 @discussion 
  Only one expired key will be returned when calling this function. When the function returns false, the application should handle it and then continually call this function until it returns true.
 @param KeyIdOutOrNULL
 [output]The index of the expired key. valid only when function returns false. give null if not interested in it.
 KeyIdOutOrNULL[0] is the keyId when valid.
 @param ridOutOrNULL
 [output]The RID of the expired key. valid only when function returns false. give null if not interested in it
 @param isNotExpired
 [output]true: key is valid, false: key is expired, can further check keyId[0] and rid if needed
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)checkCAPKWithKeyIdOut:(Byte *)KeyIdOutOrNULL ridOut:(Byte[5])ridOutOrNULL isNotExpired:(BOOL *)isNotExpired;

/*!
 @abstract Add an EMV application to terminal application list.
 @param app
 [input]application data
 @result
 return code.
 */
- (MposApiRetCode)addApp:(const MposModelEMV_APPLIST *)app;

/*!
 @abstract Get an application from the terminal application list.
 @param index
 the application index
 @param appOut
 [output]specified application data
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getAppWithIndex:(UInt32)index appOut:(MposModelEMV_APPLIST *)appOut;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function</font></b><br>
 Delete an application from the application list.
 @param aid
 [input]Application ID, compressed BCD, no more than 16 bytes.
 @result
 return code.
 */
- (MposApiRetCode)delAppWithAid:(const NSData *)aid;

/*!
 @abstract Delete all applications from the application list.
 @result
 return code.
 */
- (MposApiRetCode)delAllApp;

/*!
 @abstract  <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Get the parameter of current finally selected application.
 @param appPara
 [output]the parameter of current finally selected application
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getFinalAppPara:(MposModelEMV_APPLIST *)appPara;

/*!
 @abstract Modify the parameter of current finally selected application.
 @discussion <b><font color="red">NOTE: for D180, since the parameters are not saved when adding application, so after app selection, please get the selected AID(9F06) and set the parameters with this method</font></b>
 @param appPara
 [input]application data
 @result
 return code.
 */
- (MposApiRetCode)modFinalAppPara:(const MposModelEMV_APPLIST *)appPara;

/*!
 @abstract Get the label list of the application candidate list.
 @param num
 [output]number of labels
 @param labels
 [output]a pointer to the array of the label list
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getLabelListWithOutputNum:(UInt32 *)num labels:(MposModelEMV_APPLABEL_LIST **)labels;

/*!
 @abstract Add a revoked issuer public key certification to revoked certification list.
 @param revocList
 [input]the revoked issuer public key certification.
 @result
 return code.
 */
- (MposApiRetCode)addRevocList:(const MposModelEMV_REVOC_LIST *)revocList;

/*!
 @abstract Delete a revoked issuer public key certification.
 @param index
 The corresponding CA public key index of the revoked issuer public key certification.
 @param rid
 [input]The corresponding RID of the revoked issuer public key certification.
 @result
 return code.
 */
- (MposApiRetCode)delRevocListWithIndex:(UInt32)index rid:(const Byte[5])rid;

/*!
 @abstract Delete all revoked issuer public key certifications.
 @result
 return code.
 */
- (MposApiRetCode)delAllRevocList;

/*!
 @abstract Initialize the EMV kernel data element storage structure
 @discussion This function is used for contactless PBOC only.
 Please call this function before EMVSwitchClss to initialize the EMV kernel data element storage structure.
 @result
 return code.
 */
- (MposApiRetCode)initTLVData;

/*!
 @abstract EMV application selection
 @param slot
 Card slot number
 @param transNo
 The sequence number of the transaction.
 @param showDestination
 to indicates where APP List is displayed, 0 - Android, 1 - POS
 @discussion
    1.Before calling this function, the EMV IC card must be in the specified card slot which can be detected by the function @link //apple_ref/occ/func/iccDetectSlot:result: @/link.
    2.According to the EMV specification, if it returns @link //apple_ref/c/econst/EMV_ERR_NO_APP @/link and @link //apple_ref/c/econst/EMV_ERR_DATA @/link, application must prompt for 'Swipe card'.(The application can decide how to do according to the actual requirement)
    3.@link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link and @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link are returned by callback function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onWaitAppSelWithTryCnt:appNum:apps: @/link,
     If the function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onWaitAppSelWithTryCnt:appNum:apps: @/link doesn't return these two values, this function does not return them either.
    4.@link //apple_ref/c/econst/EMV_ERR_ICC_RSP_6985 @/link is returned when GPO responses 6985 and there's no application left in the application candidate list, the terminal application should then decide whether to terminate the transaction or to fallback.
 @result
 return code.
 Besides GENERAL ERROR code, it may return codes as follows:<br>
 @link //apple_ref/c/econst/MPOSAPI_OK @/link: Succeed<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_RESET @/link:  IC card reset failed.<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_CMD @/link: IC card command failed.<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_BLOCK @/link: IC card has been blocked.<br>
 @link //apple_ref/c/econst/EMV_ERR_NO_APP @/link: There is no IC card application supported by terminal.<br>
 @link //apple_ref/c/econst/EMV_ERR_APP_BLOCK @/link: The EMV application has been blocked.<br>
 @link //apple_ref/c/econst/EMV_ERR_DATA @/link: IC card data format error.<br>
 @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link:Application selection timeout.<br>
 @link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link: Application selection is canceled by user.<br>
 */
-(MposApiRetCode)appSelectWithSlot:(SInt32)slot transNo:(SInt32)transNo showDestination:(Byte)flag;

/*!
 @abstract Read the selected application's data, transaction amount, etc.
 @discussion
 @link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link and @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link  are returned by callback function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link. If the function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link doesn't return these two values, this function does not return them either.
 @result
 return code.
 */
- (MposApiRetCode)readAppData;

/*!
 @abstract IC card data authentication
 @discussion
 1. This function returning @link EMV_OK @/link does not stand for data authentication succeeded.
 2. The application can get the result of the authentication through function @link getTLVDataForTag:value: @/link and query the value of TVR. If the authentication method is CDA , this function just recovers the IC card private key, the authentication will not be done until performing Generate AC command.
 @result
 return code.
 */
- (MposApiRetCode)cardAuth;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 Process EMV transaction.
 @discussion
 1.@link //apple_ref/c/econst/EMV_ERR_USER_CANCEL @/link and @link //apple_ref/c/econst/EMV_ERR_TIME_OUT @/link are returned by callback function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link. If the function @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link  doesn't return these two values, this function does not return them  either.
 2.@link //apple_ref/c/econst/EMV_ERR_NOT_ACCEPT @/link and @link //apple_ref/c/econst/EMV_ERR_DENIAL @/link stand for transaction failed. According to the EMV specification,@link //apple_ref/c/econst/EMV_ERR_NOT_ACCEPT @/link will be returned on condition that the service does not accepted, and @link //apple_ref/c/econst/EMV_ERR_DENIAL @/link will be returned on other conditions.
 3.@link //apple_ref/c/econst/EMV_ERR_ICC_RSP_6985 @/link is returned when GAC responses 6985, the terminal application should then decide whether to terminate the transaction or to fallback.
 @result
 return code.
 */
- (MposApiRetCode)procTrans;

/*!
 @abstract Read the card's transaction log.
 @discussion
 This function is similar with the function @link appSelectWithSlot:transNo:@/link . The difference between them is that this function can add the block application to candidate list base on the different parameter setting when the application selection is done.
 @param slot
 Card slot number.
 @param flag
 Decide whether the block application will be added to candidate list or not.  0-Add, 1-Not add (The default is 0)
 @result
 return code.
 */
- (MposApiRetCode)appSelectForLogWithSlot:(UInt32)slot flag:(UInt32)flag;

/*!
 @abstract Read transaction log
 @discussion
 After the application finished the application selection with function @link appSelectWithSlot:transNo:@/link,
 this function can be called to read the transaction log of the selected application.
 RecordNo, Record number begins at 1.
 This function can only read the transaction log to the EMV kernel buffer. Application can read
 the specific log by the function  @link getLogItemWithTag:valueOut:@/link, such as transaction amount, transaction time and so on.
 @param recordNo
    Record number
 @result
 return code.
 */
- (MposApiRetCode)readLogRecordWithRecordNo:(UInt32)recordNo;

/*!
 @abstract Read the data items of transaction log(PBOC2.0 compatible EMV2)
 @discussion
 For each transaction log record that was read by function @link readLogRecordWithRecordNo:@/link,
 application can read the specific log information by this function.
 @param tag
    The tag of data items that need to read.
 @param value
    [output] the log item read
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getLogItemWithTag:(UInt16)tag valueOut:(NSData **)value;

/*!
 @abstract Get the kernel MCK parameter.
 @param mckParam
 [output]the MCK paramter
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getMCKParam:(MposModelEMV_MCK_PARAM *)mckParam;

/*!
 @abstract Set MCK parameter.
 @param mckParam
 [input]MCK param to set
 @result
 return code.
 */
- (MposApiRetCode)setMCKParam:(const MposModelEMV_MCK_PARAM *)mckParam;

/*!
 @abstract Set the terminal electronic cash related parameters.
 @param tmEcpParam
 [input]The electronic cash parameters which need to be set.
 @result
 return code.
 */
- (MposApiRetCode)setTmECPParam:(const MposModelEMV_TM_ECP_PARAM *)tmEcpParam;

/*!
 @abstract Read the electronic cash balance from card.
 @param balance
 [output]the electronic cash balance read
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getCardEcbBalance:(UInt32 *)balance;

/*!
 @abstract Performing process restrict, cardholder verification, terminal risk management & 1st GAC.
 @discussion
 For the transaction result in sending advice message when declined, developer should get the CID from kernel, and check if the advice message is needed.
 @param authAmt
 This authorization amount will overwrite the auth amount in @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link.
 @param cashbackAmt
 This authorization amount will overwrite the cashback amount in @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link.
 @param acType
 AC type
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.<br>
 Besides GENERAL ERROR code, it may return codes as follows:<br>
 @link //apple_ref/c/econst/MPOSAPI_OK @/link: Succeed<br>
 @link //apple_ref/c/econst/EMV_ERR_DENIAL @/link : Transaction denied.<br>
 @link //apple_ref/c/econst/EMV_ERR_DATA @/link : IC card data format error.<br>
 @link //apple_ref/c/econst/EMV_ERR_NOT_ACCEPT @/link : Transaction is not accepted.<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_CMD @/link : IC card command failed.<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_RSP_6985 @/link : ICC response 6985 in 1st GAC.<br>
 @link //apple_ref/c/econst/EMV_ERR_RSP @/link : IC card response code error.<br>
 @link //apple_ref/c/econst/EMV_ERR_PARAM @/link : Parameter error.
 */
- (MposApiRetCode)startTransWithAuthAmt:(UInt32)authAmt cashbackAmt:(UInt32)cashbackAmt acType:(EmvAcType *)acType;

/*!
 @abstract Performing online data processing (issuer authentication, script processing, etc) & 2nd GAC.
 @discussion
 1.The following data element, if exists, must be sent to kernel through @link //apple_ref/occ/instm/MposApiEmvManager/setTLVDataForTag:withValue: @/link before calling this function: ARC-8A, AC-89, IAD-91
 2.For the transaction result in sending advice message when declined, developer should get the CID from kernel, and check if the advice message is needed.
 @param commutStatus
 @link EMV_ONLINE_APPROVE @/link: Online approved or online referral approved<br>
 @link EMV_ONLINE_FAILED @/link: Online failed<br>
 @link EMV_ONLINE_DENIAL @/link: Online rejected or online referral rejected
 @param script
[input]Issuer script data in TLV format
 @param acType
 output AC type
 @result
 return code.
 Besides GENERAL ERROR code, it may return codes as follows:<br>
 @link //apple_ref/c/econst/MPOSAPI_OK @/link: Succeed<br>
 @link //apple_ref/c/econst/EMV_ERR_DENIAL @/link : transaction denied<br>
 @link //apple_ref/c/econst/EMV_ERR_DATA @/link : IC card data format error.<br>
 @link //apple_ref/c/econst/EMV_ERR_NOT_ACCEPT @/link :  transaction not accept<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_CMD @/link : IC card command failed.<br>
 @link //apple_ref/c/econst/EMV_ERR_ICC_RSP_6985 @/link :  IC card responses with 6985 when GPO.<br>
 @link //apple_ref/c/econst/EMV_ERR_RSP @/link : IC card response code error.<br>
 @link //apple_ref/c/econst/EMV_ERR_PARAM @/link : parameter error
 */
- (MposApiRetCode)completeTransWithCommuStatus:(UInt32)commutStatus script:(const NSData *)script acType:(EmvAcType *)acType;

/*!
 @abstract Set configuration.
 @param flag
 Only bit 1(the lowest one) & bit 2 are valid at moment.<br>
    bit 1:	1 = support advice<br>
    	0 = not support (default)<br>
    bit 2�?<br>
    1= always asking  user to confirm amount even no PIN input is required；@link EMV_CONFIG_FLAG_BIT_CONFIRM_AMT_WHEN_NO_PIN @/link <br>
    0 -does not ask user to confirm when no PIN input is required (default) <br>
    bit 3�?<br>
    1 = support transaction log: @link EMV_CONFIG_FLAG_BIT_SUPPORT_TRANSLOG @/link <br>
    0 = not support transaction log<br>
 @result
 return code.
 */
- (MposApiRetCode)setConfigFlag:(UInt32)flag;

/*!
 @abstract Set response data of final selection and GPO command into EMV kernel
 @discussion <b>This function is only used for Clss PBOC application</b>
 @param transParam
 [input]Transaction related parameters
 @param selData
 [input]Response data of final selection command.,which need to be got by @link //apple_ref/occ/instm/MposApiClssManager/entryGetFinalSelectData: @/link in Entry library
 @param GPOData
 [input]The data of GPO command and response, which need to be got by @link //apple_ref/occ/instm/MposApiClssManager/pbocGetGPOData: @/link in qPBOC library.
 @result
 return code.
 */
- (MposApiRetCode)switchClssWithTransParam:(const MposModelCLSS_TRANS_PARAM *)transParam selData:(const NSData *)selData GPOData:(const NSData *)GPOData;

/*!
 @abstract Set transaction amount and cashback amount.
 @discussion
 1. If the amount exceeds 0xffffffff, please use this function to set the amount to kernel.Please call this function before @link procTrans @/link or @link startTransWithAuthAmt:cashbackAmt:acType: @/link
 2. If use this function to set amount, please set authAmount and cashbackAmount in @link //apple_ref/occ/intfm/MposApiEmvManagerDelegate/onInputAuthAmount:cashbackAmount: @/link to 0 and returns @link EMV_OK @/link
 @param authAmt
 [input]Authorised Amount, please provide with human-readable string.
  Inside this method, the string will be translated to be conform to the format of tag '9F02'(i.e."\x11\x23\x45\x67\x89\x00").
  @param cashbackAmt
 [input]cashback Amount, please provide with human-readable string(say "112345678900").
  Inside this method, the string will be translated to be conform to the format of tag '9F03'(i.e."\x11\x23\x45\x67\x89\x00").
 @result
 return code.
 */
- (MposApiRetCode)setAuthAmount:(const NSString *)authAmt cashbackAmt:(const NSString *)cashbackAmt;

/*!
 @abstract read load log of selected application(PBOC3.0)
 @discussion
 1. after application selection with  @link appSelectForLogWithSlot:flag: @/link , calling this function to read the transaction log of the selected application.the recordNo is from 1.
 2. This function is to read the logs into EMV kernel buffer, further calling @link getSingleLoadLogItemForTag:value: @/link to read the contents of the log.
 @param recordNo
 record no. starting from 1
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)readSingleLoadLogWithRecordNo:(UInt32)recordNo;

/*!
 @abstract read load log item (PBOC3.0)
 @discussion
 read contents of the log which is loaded with @link readSingleLoadLogWithRecordNo: @/link previously
 @param tag
 the tag to read
 @param value
 [output]the value of the specified tag
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getSingleLoadLogItemForTag:(UInt16)tag value:(NSData **)value;

/*!
 @abstract Get the log data which is read from card.
 @discussion
 1. If the application read loading log before calling this function, the log data which is got by this function is loading log data. Please refer to PBOC 3.0 Book 13 for the format of the loading log data.<br>
 2. If the application read transaction log before calling this function, the log data which is got by this function is transaction log data. Please refer to PBOC 3.0 Book 13 for the format of the transaction log data.
 @param data
    [output] the log data
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getLogData:(NSData **)data;

/*!
 @abstract Get debug information
 @discussion
 1.This function is only used to get the debug information when a transaction is failed. <br/>
 2.So far, it only can be used to get the error code of offline data
 @param debugInfo
 [output] the log data
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getDebugInfo:(MposDebugInfo **)debugInfo;

/*!
 @abstract Read the response status word of the PIN Verify command
 @discussion

 @param iccStatus
 [output] SWA SWB
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getVerifyICCStatus:(MposICCStatus **)iccStatus;

@end
