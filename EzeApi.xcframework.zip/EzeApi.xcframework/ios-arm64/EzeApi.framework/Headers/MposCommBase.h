//
//  MposCommBase.h
//  MposComm
//
//  Created by kevintu@paxsz.com on 11/17/14.
//  Copyright (c) 2014 pax. All rights reserved.
//

#import <Foundation/Foundation.h>

#define COMM_CON_TIMEOUT_DEFAULT    (10000)
#define COMM_SEND_TIMEOUT_DEFAULT   (20000)
#define COMM_RECV_TIMEOUT_DEFAULT   (20000)

/*!
 @abstract connected callback prototype (currently used for Bluetooth)
 @param addr    address
 @param name    name
 */
typedef void (^didConnectedBlock)(NSString *addr, NSString *name);
/*!
 @abstract disconnected callback prototype (currently used for Bluetooth)
 @param addr    address
 @param name    name
 */
typedef void (^didDisconnectedBlock)(NSString *addr, NSString *name);
/*!
 @abstract data received callback prototype (currently used for Bluetooth)
 @param data    data received
 */
typedef void (^didReceivedDataBlock)(NSData *data);

/*!
 @abstract Mpos Communication protocol
 */
@protocol MposCommInf <NSObject>

@required
/*!
 @abstract connect
 @result
 true on success, false otherwise
 */
- (BOOL)connect;

/*!
 @abstract send data
 @param buf
 buffer to send
 @result
 true on success, false otherwise
 */
- (BOOL)send:(NSData  *)buf;

/*!
 @abstract receive data with expected length, and store into spcified buffer and offset
 @param buf
 the pointer to the buffer where the received data is stored
 @param offset
 the offset in the buffer to store
 @param len
 the expected length to receive
 @result
 the length of data received, -1 on error, -2 on cancelled
 */
- (SInt32)recv:(UInt8 *)buf to:(UInt32)offset exp:(UInt32)len;

/*!
 @abstract receive data, non-blocking
 @result
 the data received. nil if nothing received or error
 */
- (NSData *)recv;

/*!
 @abstract reset receiving buffer
 */
- (void)reset;

/*!
 @abstract close the connection
 */
- (void)close;

/*!
 @abstract check the connection status
 @result
 true if connected, false otherwise
 */
- (BOOL)isConnected;

/*!
 @abstract cancel receive process
 */
- (void)cancelRecv;

@optional

/*!
 @abstract set asynchronized communcation event callbacks(currenly used for Bluetooth)
 @param connectedBlock  connected callback
 @param disconnectedBlock   disconnected callback
 @param onReceivedDataBlock  received data callback
 */
- (void)didConnected:(didConnectedBlock)connectedBlock
     didDisconnected:(didDisconnectedBlock)disconnectedBlock
     didReceivedData:(didReceivedDataBlock)onReceivedDataBlock;

@end

/*!
 @abstract MposCommBase is an abstract class that conforms to MposCommInf protocol.
 Please override the methods in MposCommInf.
 */
@interface MposCommBase : NSObject<MposCommInf>

/*!
 @abstract  connection timeout, default to 10000ms
 */
@property NSInteger connectTimeout;
/*!
 @abstract  send timeout, default to 20000ms
 */
@property NSInteger sendTimeout;
/*!
 @abstract  receive timeout, default to 20000ms
 */
@property NSInteger recvTimeout;

@end
