//
//  MposTransErrCodes.h
//  MposApi
//
//  Created by admin on 7/16/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//
#import "MposApiRetCodes.h"

@interface MposApiRetCodes (privateMethod)

+ (SInt32)transErrCode:(SInt32)errCode forCmd:(MposCmdType)cmd;
//+ (BOOL)isCommonErrCode:(SInt32)errCode;
+ (BOOL)isErrCodeNoNeedTransform:(SInt32)errCode;
@end