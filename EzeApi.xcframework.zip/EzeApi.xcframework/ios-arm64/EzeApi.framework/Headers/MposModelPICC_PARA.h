//
//  MposModelPICC_PARA.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the PICC parameters, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelPICC_PARA : NSObject

/*!
 @abstract
 The version information of Driver's, for example: "1.01A" can only be read
 */
@property Byte* drv_ver;

/*!
 @abstract
 The date informaion of driver,such as:"2006.08.25"; Read only
 */
@property Byte* drv_date;

/*!
 @abstract
 The output conductance of A card is write enable:1_alowed,Others—not allowed
 */
@property Byte a_conduct_w;

/*!
 @abstract
 The A card control variable of output conductance,invalid 0~63,over can be seen as 63,The defaut value is 63;
 */
@property Byte a_conduct_val;

/*!
 @abstract
 The output conductance of M1 card is write enable
 */
@property Byte m_conduct_w;

/*!
 @abstract
 The M1 card control variable of output conductance, invalid 0~63,over can be seen as 63,The defaut value is 1;
 */
@property Byte m_conduct_val;

/*!
 @abstract
 The modulation index of B card is written enable
 */
@property Byte b_modulate_w;

/*!
 @abstract
 The B card control variable of modulation index, invalid 0~63,over can be seen as 63,The defaut value is 4
 */
@property Byte b_modulate_val;

/*!
 @abstract
 Receiving buffer of card is written enable
 */
@property Byte card_buffer_w;

/*!
 @abstract
 Receiving buffer parameter of card (Unit:byte), valid: 1~256. when over 256,it will use 256;if it is 0,it will not be written in
 */
@property UInt16 card_buffer_val;

/*!
 @abstract
 Written enable for S(WTX) response to sending times
 */
@property Byte wait_retry_limit_w;

/*!
 @abstract
 The most repeat times of S(WTX) response, default is 3
 */
@property UInt16 wait_retry_limit_val;

/*!
 @abstract
 Card type check is allow to write
 */
@property Byte card_type_check_w;

/*!
 @abstract
 0-Check card type,other-do not check the card type(default to check the card type )
 */
@property Byte card_type_check_val;

/*!
 @abstract
 Receiver sensitivity of type B card is written enable: 1--allowed, others--disallowed
 */
@property Byte card_RxThreshold_w;

/*!
 @abstract
 Receiver sensitivity of type B card
 */
@property Byte card_RxThreshold_val;

/*!
 @abstract
 felica modulation depth allow to write: 1--allowed, others-- not allowed
 */
@property Byte f_modulate_w;

/*!
 @abstract
 felica modulation depth
 */
@property Byte f_modulate_val;

/*!
 @abstract
 type A card modulation depth allow to write: 1--allowed, others--disallowed
 */
@property Byte a_modulate_w;

/*!
 @abstract
 type A card modulation depth, 0~63.
 */
@property Byte a_modulate_val;

/*!
 @abstract
 Receiver sensitivity of type A card allow to write: 1--allowed, others--disallowed
 */
@property Byte a_card_RxThreshold_w;

/*!
 @abstract
 Receiver sensitivity of type A card
 */
@property Byte a_card_RxThreshold_val;

/*!
 @abstract
 Antenna gain of type A card allow to write: 1--allowed, others--disallowed
 */
@property Byte a_card_antenna_gain_w;

/*!
 @abstract
 Antenna gain of type A card
 */
@property Byte a_card_antenna_gain_val;

/*!
 @abstract
 Antenna gain of type B card allow to write: 1--allowed, others--disallowed
 */
@property Byte b_card_antenna_gain_w;

/*!
 @abstract
 Antenna gain of type B card
 */
@property Byte b_card_antenna_gain_val;

/*!
 @abstract
 Antenna gain of type Felica allow to write: 1--allowed, others--disallowed
 */
@property Byte f_card_antenna_gain_w;

/*!
 @abstract
 Antenna gain of type Felica
 */
@property Byte f_card_antenna_gain_val;

/*!
 @abstract
 The version information of Driver's, for example: "1.01A" can only be read
 */
@property Byte f_card_RxThreshold_w;

/*!
 @abstract
 Receiver sensitivity of Felica
 */
@property Byte f_card_RxThreshold_val;

/*!
 @abstract
 reserved, 76 bytes
 */
@property Byte *reserved;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
