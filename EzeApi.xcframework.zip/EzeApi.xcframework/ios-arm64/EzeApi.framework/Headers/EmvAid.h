//
//  EmvAid.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelEMV_APPLIST.h"

@interface EmvAid : NSObject

@property(strong, nonatomic) NSMutableArray<MposModelEMV_APPLIST *> *appList;
- (MposModelEMV_APPLIST *) getSpecificApp: (Byte *)bytes;


@end
