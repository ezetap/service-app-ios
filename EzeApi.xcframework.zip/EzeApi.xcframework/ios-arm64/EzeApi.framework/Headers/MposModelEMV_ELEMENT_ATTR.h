//
//  MposModelEMV_ELEMENT_ATTR.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

//EMV_ELEMENT_ATTR
/*!
 @abstract EMV element attribute type
 @discussion
 @constant EMV_ELEMENT_ATTR_N           numeric, bcd format, right-aligned, may left padded with 0x0s
 @constant EMV_ELEMENT_ATTR_B           binary
 @constant EMV_ELEMENT_ATTR_CN          numeric, bcd format, left-aligned, may right padded with 0xFs
 @constant EMV_ELEMENT_ATTR_AN          alphabet and numeric(a-z,A-Z,0-9)
 @constant EMV_ELEMENT_ATTR_ANS         alphabet, numeric and special characters
 */
typedef enum {
    EMV_ELEMENT_ATTR_N 				= 0x04,
    EMV_ELEMENT_ATTR_B    			= 0x08,
    EMV_ELEMENT_ATTR_CN   			= 0x10,
    EMV_ELEMENT_ATTR_AN   			= 0x20,
    EMV_ELEMENT_ATTR_ANS  			= 0x40,
}EmvElementAttrType;

/*!
 @abstract EMV source of data element
 @discussion
 @constant EMV_SRC_TM           Terminal
 @constant EMV_SRC_ICC          IC card
 @constant EMV_SRC_ISS          Issuer
 */
typedef enum {
    EMV_SRC_TM   						= 1,
    EMV_SRC_ICC                         = 0,
    EMV_SRC_ISS  						= 2,
}EmvElementAttrSrc;

/*!
 @abstract EMV data element attributes, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_ELEMENT_ATTR : NSObject

/*!
 @abstract The maximum length for this tag.
 */
@property UInt32 MaxLen;

/*!
 @abstract Tag
 */
@property UInt16 Tag;

/*!
 @abstract The format of this data, see @link //apple_ref/c/tdef/EmvElementAttrType @/link
 */
@property UInt16 Attr;

/*!
 @abstract The template which this tag belongs, 0 if none, at most 2 templates
 */
@property UInt16 *usTemplate;//[2];

/*!
 @abstract The source of data element, see @link //apple_ref/c/tdef/EmvElementAttrSrc @/link
 */
@property Byte ucSource;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;
@end
