//
//  MposModelST_KEY_INFO.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the M/S KEY information, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelST_KEY_INFO : NSObject

/*!
 @abstract
 the source key type, can be PED_TLK,PED_TMK,PED_TPK,PED_TAK,PED_TDK, it's level MUST not lower than the level of ucDstKeyType
 */
@property Byte ucSrcKeyType;

/*!
 @abstract
 the source key index used to derive, start from 1. 0 means the key to write is in plain text.
 */
@property Byte ucSrcKeyIdx;

/*!
 @abstract
 the type of the key to write, can be PED_TLK,PED_TMK,PED_TPK,PED_TAK,PED_TDK
 */
@property Byte ucDstKeyType;

/*!
 @abstract
 the key index of the key to write
 */
@property Byte ucDstKeyIdx;

/*!
 @abstract
 the length of the key to write, 8/16/24
 */
@property Byte iDstKeyLen;

/*!
 @abstract
 key value, maximum length is 24 bytes
 */
@property Byte *aucDstKeyValue; // [24];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
