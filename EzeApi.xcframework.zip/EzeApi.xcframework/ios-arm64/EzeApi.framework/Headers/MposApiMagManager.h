//
//  MagManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiRetCodes.h"
#import "MposModelTrackDataOut.h"

/*!
 @abstract MposApiMagManager is used to read magnetic stripe card
 */
@interface MposApiMagManager : NSObject

/*!
 @abstract get MposApiMagManager shared instance
 @result
 MposApiMagManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Reset magnetic stripe card reader, and clears buffer of magnetic stripe card.
 @result
 return code.
 */
- (MposApiRetCode)magReset;

/*!
 @abstract Switch on magnetic stripe card reader.
 @result
 return code.
 */
- (MposApiRetCode)magOpen;

/*!
 @abstract Switch off magnetic stripe card reader.
 @result
 return code.
 */
- (MposApiRetCode)magClose;

/*!
 @abstract Check whether a card is swiped.
 @param flag
 true: Card swiped, false: No swiping
 @result
 return code.
 */
- (MposApiRetCode)magIsSwiped:(BOOL *)flag;

/*!
 @abstract Read data of track 1, 2, 3 from magnetic stripe card buffer.<br>
 The encoding of the track data is NSISOLatin1StringEncoding
 @param mode
 [input] encryption mode see @link //apple_ref/c/econst/EncryptionMode @/link 
 
 @param index
 [input] index of the key to be used when mode != CLEAR.
 
 @param trackDataOut
 [output]see @link //apple_ref/occ/cl/MposModelTrackDataOut @/link.

  @result
 return code.
 */
- (MposApiRetCode)magReadWithEncryptionMode:(EncryptionMode)mode keyIndex:(Byte)index TrackDataOut:(MposModelTrackDataOut **)trackDataOut;
@end
