//
//  EmvTest.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiEmvManager.h"

@interface EmvTest : NSObject

@property (strong, nonatomic) MposApiEmvManager *emvManager;

- (void) addApp;

@end
