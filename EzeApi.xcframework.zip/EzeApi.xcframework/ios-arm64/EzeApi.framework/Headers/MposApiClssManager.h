//
//  MposApiClssManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiEmvManager.h"
#import "MposModelCLSS_PBOC_AID_PARAM.h"
#import "MposModelCLSS_PRE_PROC_INFO.h"
#import "MposModelCLSS_PRE_PROC_INTER_INFO.h"
#import "MposModelCLSS_READER_PARAM.h"
#import "MposModelCLSS_TM_AID_LIST.h"
#import "MposModelCLSS_TRANS_PARAM.h"
#import "MposModelCLSS_READER_PARAM_MC.h"
#import "MposModelCLSS_TERM_CONFIG_MC.h"
#import "MposModelSYS_PROC_INFO.h"
#import "MposModelPOSLOG.h"
#import "MposModelClSS_MC_AID_PARAM_MC.h"
#import "MposModelClSS_VISA_AID_PARAM.h"

@class MposModelCLSS_APP_LIST;

//clss kernel type
/*!
 @abstract Contactless kernel type enumeration
 @discussion
 @constant CLSS_KERNTYPE_DEF    default
 @constant CLSS_KERNTYPE_JCB    JCB
 @constant CLSS_KERNTYPE_VIS    VIS
 @constant CLSS_KERNTYPE_PBOC   PBOC
 @constant CLSS_KERNTYPE_AE     AE
 @constant CLSS_KERNTYPE_ZIP    ZIP
 @constant CLSS_KERNTYPE_FLASH  FLASH
 */
typedef enum {
    CLSS_KERNTYPE_DEF 					= 0,
    CLSS_KERNTYPE_JCB 					= 1,
    CLSS_KERNTYPE_MC  					= 2,
    CLSS_KERNTYPE_VIS 					= 3,
    CLSS_KERNTYPE_PBOC 					= 4,
    CLSS_KERNTYPE_AE 					= 5,
    CLSS_KERNTYPE_ZIP 					= 6,
    CLSS_KERNTYPE_FLASH 				= 7,
} ClssKernType;

//trans path
/*!
 @abstract PICC transaction path enumeration
 @discussion
 @constant CLSS_VISA_MSD        VISA MSD
 @constant CLSS_VISA_QVSDC      VISA qVSDC
 @constant CLSS_VISA_VSDC       VISA full VSDC
 @constant CLSS_VISA_CONTACT    VISA contact
 */
typedef enum {
    CLSS_VISA_MSD     					= 1,
    CLSS_VISA_QVSDC   					= 2,
    CLSS_VISA_VSDC    					= 3,
    CLSS_VISA_CONTACT 					= 4,
} ClssTransPath;

//cvm type
/*!
 @abstract Contactless CVM type
 @discussion
 @constant RD_CVM_NO                NO CVM
 @constant RD_CVM_SIG               signature
 @constant RD_CVM_ONLINE_PIN        online PIN
 */
typedef enum {
    RD_CVM_NO							= 0x00,
    RD_CVM_SIG							= 0x10,
    RD_CVM_ONLINE_PIN					= 0x11,
    RD_CVM_OFFLINE_PIN                  = 0x12,
    RD_CVM_CONSUMER_DEVICE              = 0x1F
} ClssCVMType;

/*!
 @abstract MposApiClssManager is used to process contactless transation
 */
@interface MposApiClssManager : NSObject

/*!
 @abstract get MposApiClssManager shared instance
 @result
 MposApiClssManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Query the version of entry kernel.
 @param ver
 [output]Entry's version number and issue date
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)entryReadVerInfo:(NSString **)ver;

/*!
 @abstract Add an application to application list.
 @param aid
 [input]AID
 @param selFlg
 AID matching flag
 @param kernType
 application kernel type
 @result
 return code.
 */
- (MposApiRetCode)entryAddAidListWithAid:(const NSData *)aid selFlg:(EmvAppSelFlag)selFlg kernType:(ClssKernType)kernType;

/*!
 @abstract Delete an application from the application list
 @param aid
 [input]AID
 @result
 return code.
 */
- (MposApiRetCode)entryDelAidList:(const NSData *)aid;

/*!
 @abstract Delete all applications in the application list
 @result
 return code.
 */
- (MposApiRetCode)entryDelAllAidList;

/*!
 @abstract Set AID's corresponding parameters used in Preliminary Transaction Processing.
 @discussion
 1.This function must be called before transaction preprocessing.<br>
 2.If the AID's corresponding parameters used in Preliminary Transaction Processing already exists, the old one will be replaced by this new one.<br>
 3.Before set the preliminary parameter, you must add its application into kernel first. If not, this function will return EMV_ERR_NOT_FOUND.<br>
 @param preProcInfo
 [input]Parameters used in transaction preprocessing corresponding to an AID
 @result
 return code.
 */
- (MposApiRetCode)entrySetPreProcInfo:(const MposModelCLSS_PRE_PROC_INFO *)preProcInfo;

/*!
 @abstract Delete AID's correspongding parameters used in preliminary transaction processing.
 @discussion
 This function must be called before preliminary transaction processing. 
 @param aid
 [input]AID
 @result
 return code.
 */
- (MposApiRetCode)entryDelPreProcInfo:(const NSData *)aid;

/*!
 @abstract Delete all parameters used in preliminary transaction processing.
 @discussion
 This function must be called before preliminary transaction processing.
 @result
 return code.
 */
- (MposApiRetCode)entryDelAllPreProcInfo;

/*!
 @abstract Transaction preprocessing.
 @discussion
 This function must be called before detecting card.
 @param transParam
 [input]related parameters of transaction.
 @result
 return code.
 */
- (MposApiRetCode)entryPreTransProc:(const MposModelCLSS_TRANS_PARAM *)transParam;

/*!
 @abstract Application selection.
 @discussion
 Before calling this function, @link //apple_ref/occ/instm/MposApiPiccManager/piccDetectWithMode:detected:cardType:serialNo:cid:other: @/link  must be called to judge whether a type A or type B card is detected or not. 
 @param slot
 currently not used
 @param readLogFlag
 currently not used
 @result
 return code.
 */
- (MposApiRetCode)entryAppSltWithSlot:(UInt32)slot readLogFlag:(UInt32)readLogFlag;

/*!
 @abstract Final selection, application with the highest priority will be selected automatically by kernel.
 @discussion
 if @link //apple_ref/c/econst/EMV_ERR_RSP @/link , @link //apple_ref/c/econst/EMV_ERR_APP_BLOCK @/link, @link //apple_ref/c/econst/EMV_ICC_BLOCK @/link or @link //apple_ref/c/econst/EMV_CLSS_RESELECT_APP @/link is returned,
 application should call @link entryDelCurCandApp @/link to delete current application. If there're oehter applications in the candidate list, call this function again to re-select application.
 @param kernType
 [output]kernel type
 @param aidOut
 [output]AID
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 Besides GENERAL ERROR code, it may return codes as follows:<br>
 @link //apple_ref/c/econst/MPOSAPI_OK @/link: OK <br>
 @link //apple_ref/c/econst/EMV_ICC_CMD_ERR @/link: IC Card command failed. <br>
 @link //apple_ref/c/econst/EMV_EMV_RSP_ERR @/link: IC card response code error. <br>
 @link //apple_ref/c/econst/EMV_EMV_NO_APP @/link: No EMV application that terminal supported. <br>
 @link //apple_ref/c/econst/EMV_EMV_APP_BLOCK @/link: application blocked <br>
 @link //apple_ref/c/econst/EMV_ICC_BLOCK @/link: IC card has been blocked <br>
 @link //apple_ref/c/econst/EMV_EMV_OK @/link: data error, further check the detailed code with @link entryGetErrorCode: @/link <br>
 @link //apple_ref/c/econst/EMV_CLSS_RESELECT_APP @/link: re-select application(only for paypss application)
 */
- (MposApiRetCode)entryFinalSelectWithKernTypeOut:(ClssKernType *)kernType aidOut:(NSData **)aidOut;

/*!
 @abstract Delete the current application from the candidate list
 @discussion
 If the Get Processing Options command return status 6985. You need to use this function to delete the first application in the candidate list. Then you can redo the final select.
 @result
 return code.
 */
- (MposApiRetCode)entryDelCurCandApp;

/*!
 @abstract Get the finally selected AID's corresponding parameters, which are dynamically set during preliminary transaction processing.
 @discussion
 1.This function must be called between final selection and transaction processing;
 2.After calling this function, further call @link pbocSetTransDataWithTransParam:preProcInterInfo: @/link to set the parameter.  
 @param preProcInterFlg
 [output]the finally selected AID's corresponding parameters
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)entryGetPreProcInterFlg:(MposModelCLSS_PRE_PROC_INTER_INFO *)preProcInterFlg;

/*!
 @abstract  Get related data returned from card in final selection
 @discussion
 1.This function must be called between final selection and Get Processing Options;
 2.After calling this function, further call @link pbocSetFinalSelectData: @/link to set the parameter. 
 @param data
 [output]Related data saved during final selection.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)entryGetFinalSelectData:(NSData **)data;

/*!
 @abstract select blocked application
 @discussion
 1.This function must be called between final selection and Get Processing Options .<br>
 2.After calling this function, further call @link pbocSetFinalSelectData: @/link to set the parameter. 
 @param transParam
 [input]related parameters of transaction.
 @param termAid
 [input]AID related paramters of the blocked application 
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)entryAppSelectUnlockAppWithTransParam:(const MposModelCLSS_TRANS_PARAM *)transParam termAid:(const MposModelCLSS_TM_AID_LIST *)termAid;

/*!
 @abstract get detailed error code
 @discussion
 currently it's only used when @link entryAppSltWithSlot:readLogFlag: @/link returns @link //apple_ref/c/econst/EMV_ERR_NO_APP_PPSE @/link or
 @link entryGetFinalSelectData: @/link returns @link //apple_ref/c/econst/EMV_ERR_DATA @/link.
 @param errorCode
 [output]error code
 1. For @link entryAppSltWithSlot:readLogFlag: @/link，errocode can be @link //apple_ref/c/econst/EMV_ERR_DATA @/link ，@link //apple_ref/c/econst/EMV_ERR_RSP @/link , @link //apple_ref/c/econst/EMV_ERR_APP_BLOCK @/link.
 2. For @link entryGetFinalSelectData: @/link ，errocode can be @link //apple_ref/c/econst/EMV_ERR_DATA @/link ，@link //apple_ref/c/econst/EMV_ERR_RSP @/link , @link //apple_ref/c/econst/EMV_ERR_NO_DATA @/link.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)entryGetErrorCode:(SInt32 *)errorCode;

/*!
 @abstract set the specification version that Entry conforms
 @discussion
 1.this is only used for PayPass application
 2.must be called before @link entryAppSltWithSlot:readLogFlag: @/link
 @param ver
 0x03: support paypass v3.0<br>
 0x02: support paypass v2.1 (default)
 @result
 return code.
 */
- (MposApiRetCode)entrySetMCVersion:(UInt32)ver;


/*!
 @abstract Query the version number of PayWave kernel.
 @param ver
 [output]version of qPBOC kernel
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocReadVerInfo:(NSString **)ver;

/*!
 @abstract Get the data element specified by the tag.
 @param tag
 [input]Tag of EMV standard or extended data.
 @param mode
 [input] encryption mode see @link //apple_ref/c/econst/EncryptionMode @/link
 @param index
 [input] index of the key to be used when mode != CLEAR.
 @param value
 [output]the value of the specified tag, see @link //apple_ref/occ/cl/MposModelDataWithEncryptionMode @/link.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetTLVDataForTag:(UInt16)tag mode:(EncryptionMode)mode keyIndex:(Byte)index value:(MposModelDataWithEncryptionMode **)value;

/*!
 @abstract Set the data element specified by the tag.
 @param tag
 EMV standard or extended data element Tag.
 @param value
 [input]The value of the data element specified by the tag.
 @result
 return code.
 */
- (MposApiRetCode)pbocSetTLVDataForTag:(UInt16)tag withValue:(const NSData *)value;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>Set the data element by user-defined tag
 @param tag
 User-defined tag.
 @param value
 [input]The value of the data element specified by the tag.
 @result
 return code.
 */
- (MposApiRetCode)pbocSetEMVUnknownTLVDataForTag:(UInt16)tag withValue:(const NSData *)value;

/*!
 @abstract Get related parameters of the reader.
 @param readerParam
 [output]reader's relative parameters
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetReaderParam:(MposModelCLSS_READER_PARAM *)readerParam;

/*!
 @abstract Set related parameter of card reader
 @discussion
 This function must be called before Initiate Application Processing(GPO)  to set the reader's relative parameters.
 @param readerParam
 [input]reader's relative parameters
 @result
 return code.
 */
- (MposApiRetCode)pbocSetReadParam:(const MposModelCLSS_READER_PARAM *)readerParam;

/*!
 @abstract Set QPBOC application related parameters corresponding to the AID
 @discussion
 This function must be called before Initiate Application Processing(GPO) to set application's relative parameters.
 @result
 return code.
 */
- (MposApiRetCode)pbocSetAidParam:(MposModelCLSS_PBOC_AID_PARAM *)aidParam;

/*!
 @abstract Add a new CA public key.
 @discussion 
 1. 1.If the public key is already existed, the new key will replace the old one.
 2. CA public key is provided by acquire. Sometimes, the key is not assigned with the structure of @link //apple_ref/occ/cl/MposModelEMV_CAPK @/link, In this case, the application must convert the public key before it can be added to the EMV library.
 2. when using SM algorithm. HashInd of CAPK must be 0x07 and ArithInd must be 0x04.
 @param capk
 CA public key
 @result
 return code.
 */
- (MposApiRetCode)pbocAddCAPK:(const MposModelEMV_CAPK *)capk;

/*!
 @abstract Delete a CA public key.
 @param keyId
 The index of the key.
 @param rid
 [input]Registered Application Provider Identifier.
 @result
 return code.
 */
- (MposApiRetCode)pbocDelCAPKWithKeyId:(UInt32)keyId rid:(const Byte[5])rid;

/*!
 @abstract Get a CA public key.
 @param keyId
 the key index
 @param capkOut
 [output]the specified CA public key
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetCAPKWithKeyId:(UInt32)keyId capkOut:(MposModelEMV_CAPK *)capkOut;

/*!
 @abstract Delete all CA public keys
 @discussion
 Application developer is suggested to call this function to delete all CA Public Keys in kernel at the beginning of each transaction, and set CA Public Key according to current application's requirment. In this way, application only need to set one CA Public Key each time.
 @result
 return code.
 */
- (MposApiRetCode)pbocDelAllCAPK;

/*!
 @abstract Add a revoked issuer public key certification to certification revocation list
 @discussion If the revoked issuer public key certification already exists, this function directly returns success. 
 @param revocList
 [input]the revoked issuer public key certification
 @result
 return code.
 */
- (MposApiRetCode)pbocAddRevocList:(const MposModelEMV_REVOC_LIST *)revocList;

/*!
 @abstract Delete a revoked issuer public key certification.
 @param index
 The corresponding CA public key index of the revoked issuer public key certification.
 @param rid
 [input]The corresponding RID of the revoked issuer public key certification (5 byte)
 @result
 return code.
 */
- (MposApiRetCode)pbocDelRevocListWithIndex:(UInt32)index rid:(const Byte[5])rid;

/*!
 @abstract Delete all revoked issuer public key certifications.
 @result
 return code.
 */
- (MposApiRetCode)pbocDelAllRevocList;

/*!
 @abstract Set the data returned from card during final selection
 @discussion
 1.get the data of final selection firstly before setting
 2.must be called before @link pbocProcTransWithTransPathOut:acType: @/link
 @param data
 [input]the data to set
 @result
 return code.
 */
- (MposApiRetCode)pbocSetFinalSelectData:(const NSData *)data;

/*!
 @abstract Set related parameters of transaction and transfer the result of preliminary transaction processing
 @discussion
 1.must be called before @link pbocProcTransWithTransPathOut:acType: @/link
 2.if not support qPBOC, application can ignore pre-processing, however, you should clear qPBOC bit of @link //apple_ref/occ/instp/MposModelCLSS_PRE_PROC_INTER_INFO/aucReaderTTQ @/link
 @param transParam
 [input]the related parameters of transaction, note that the authorized amount and transaction type settings are different from EMV L2
 @param preProcInterInfo
 [input]the result of preliminary transaction processing, it's archieved with @link entryGetPreProcInterFlg: @/link
 @result
 return code.
 */
- (MposApiRetCode)pbocSetTransDataWithTransParam:(const MposModelCLSS_TRANS_PARAM *)transParam preProcInterInfo:(MposModelCLSS_PRE_PROC_INTER_INFO *)preProcInterInfo;

/*!
 @abstract This function includes the processing of GPO and record reading of MSD, qVSDC or  Wave2.
 @discussion
 1.When this function is performed successfully, if AC type is TC,application need to  judge whether to do offline authentication or exception file checking according to the transaction path. While if the AC type is AAC or ARQC, offline rejection or online authorization shall be performed immediately;
 2.if returns @link //apple_ref/c/econst/CLSS_ERR_RESELECT_APP @/link ，use @link entryDelCurCandApp @/link to delete currently applcation and re-select applcation
 3.if terminal supports SM algorithm, must call  @link pbocSetTLVDataForTag:withValue: @/link  to set 'DF69' to 1 before calling this function.
 @param transPath
 [output]transaction path
 @param acType
 [input]AC type
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 Besides GENERAL ERROR code, it may return codes as follows:<br>
 @link //apple_ref/c/econst/MPOSAPI_OK @/link: OK <br>
 @link //apple_ref/c/econst/EMV_ERR_PARAM @/link: parameter error <br>
 @link //apple_ref/c/econst/CLSS_ERR_RESELECT_APP @/link: re-select applcation <br>
 @link //apple_ref/c/econst/CLSS_ERR_USE_CONTACT @/link: Terminate CLSS transaction and use contact interface to process transaction instead. <br>
 @link //apple_ref/c/econst/CLSS_ERR_CARD_EXPIRED @/link: card expired <br>
 others: Terminate transaction and redetect card.
 */
- (MposApiRetCode)pbocProcTransWithTransPathOut:(ClssTransPath *)transPath acType:(EmvAcType *)acType;

/*!
 @abstract Do offline data authentication and return AC type
 @discussion
 After this function is performed successfully, application shall continue with subsequenced process according to the AC returned in this function parameter.(such as offline approve, offline decline,or online authorization)
 @param acType
 [output]AC type
 @param flag
 [output]DDA failed or not flag
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocCardAuthWithAcTypeOut:(EmvAcType *)acType isDDAFailed:(BOOL *)flag;

/*!
 @abstract Get CVM Type (signature or online PIN verification)
 @param cvmType
 [output]CVM type
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetCvmType:(ClssCVMType *)cvmType;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>get mapped track1 data(ASCII) under MSD and qPBOC transaction path
 @discussion
 application can use track1 equivalent data to gnereate the data
 @param data
 [output]track1 data
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetTrack1MapData:(NSString **)data;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>get mapped track2 data(ASCII) under MSD and qPBOC transaction path
 @discussion
 application can use track2 equivalent data to gnereate the data
 @param data
 [output]track2 data
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetTrack2MapData:(NSString **)data;

/*!
 @abstract get the retuned data of GPO
 @discussion
 if trasaction path of @link pbocProcTransWithTransPathOut:acType: @/link returned is @link CLSS_VISA_VSDC @/link, you should call this function to get returned data of GPO, and then set the data with PBOC interface.
 @param data
 [output]returned data of GPO
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetGPOData:(NSData **)data;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>re-send last read record command and continue transaction
 @param transPath
 [output]transaction path
 @param acType
 [input]AC type
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocReSendLastCmdWithTransPathOut:(ClssTransPath *)transPath acType:(EmvAcType *)acType;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>send Get Data command to get data from card
 @discussion
 application can call this function after finall selection.
 @param tag
 the tag to get value, currently only support tag start with 9F.
 @param data
 [output]the value get from the card for the specified tag 
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pbocGetDataCmdWithTag:(UInt16)tag data:(NSData **)data;

/*!
 @abstract initialize the blocked application
 @discussion
 if the transaction path is PBOC, then it's OK, other paths are treated as error. 
 @result
 return code.
 */
- (MposApiRetCode)pbocProcTransUnlockApp;

/*!
 @abstract download capk
 @discussion
 @param  capk
 [input] emv CA public key
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadCAPK:(const MposModelEMV_CAPK *)capk;

/*!
 @abstract download application
 @discussion
 @param  preProcInfo
 [input] Parameters used in transaction preprocessing corresponding to an AID
 @link //apple_ref/c/econst/MposModelCLSS_APP_LIST @/link).
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadApp:(const MposModelCLSS_APP_LIST *)appList;
/*!
 @abstract Download reader param for PayWave
 @discussion
 @param  readerParam
 [input] reader parameters
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadVisaReaderParam:(const MposModelCLSS_READER_PARAM *)readerParam;

/*!
 @abstract Download AID param for Visa PayWave
 @discussion
 @param  visaAidParam
 [input] application id parameters
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadVisaAidParam:(const MposModelClSS_VISA_AID_PARAM *)visaAidParam;

/*!
 @abstract Download reader param for PayPass
 @discussion
 @param  readerParamMC
 [input] reader parameters of mastecard
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadMCReaderParam:(const MposModelCLSS_READER_PARAM_MC *)readerParamMC;

/*!
 @abstract Download AID param for Visa PayPass
 @discussion
 @param  mcAidParam
 [input] application id parameters
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadMCAidParam:(const MposModelClSS_MC_AID_PARAM_MC *)mcAidParam;

/*!
 @abstract Download terminal configuration for PayPass
 @discussion
 @param  termConfigMC
 [input] terminal configuration
 @result
 return code.
 */
- (MposApiRetCode)integrateDownloadMCTermConfig:(const MposModelCLSS_TERM_CONFIG_MC *)termConfigMC;

/*!
 @abstract Delete all CAPK
 @discussion
 @result
 return code.
 */
- (MposApiRetCode)integrateDeleteAllCAPK;

/*!
 @abstract  Delete one CAPK specified by keyId and rid
 @discussion
 @param  keyId
 [input] The index of the key.
 @param  rid
 [input] Registered Application Provider Identifier.
 @result
 return code.
 */
- (MposApiRetCode)integrateDleteOneCAPKWithKeyId:(UInt32)keyId rid:(const Byte[5])rid;

/*!
 @abstract Delete all AID
 @discussion
 @result
 return code.
 */
- (MposApiRetCode)integrateDeleteAllAID;

/*!
 @abstract Delete one specified AID
 @discussion
 @param  aid
 [input] AID to be deleted
 @result
 return code.
 */
- (MposApiRetCode)integrateDeleteOneAID:(const NSData *)aid;

/*!
 @abstract Init transaction
 @discussion After successfully init the transaction, the terminal should polling the card(including Magnetic Swipe Card, IC Card and Contactless Card)
 The polling timeout is specified by @link //apple_ref/occ/instp/MposModelPOSLOG/uiTimeOut @/link.
 @param  poslog
 [input] ransaction parameters, such as amount, date, merchantID and so on 
 @result
 return code.
 */
- (MposApiRetCode)integrateTransInitWithParams:(const MposModelPOSLOG *)poslog;

/*!
 @abstract Cancel card polling <br>This method should be called right after @link integrateTransInitWithParams:@/link. if you want to cancel card polling.
 @discussion
 @result
 return code.
 @deprecated
 */
- (MposApiRetCode)integrateTransCancel;

/*!
 @abstract
 Get card polling status<br>
 If Contactless Card detected, please further call other methods in this class; <br>
 If Magnetic Swipe Card detected, please call methods in @link MposApiMagManager @/link. <br>
 if IC Card detected, please call methods in @link //apple_ref/occ/cl/MposApiIccManager @/link.<br>
 @discussion
 @param  status
 [output]
  		0 - Magnetic Swipe Card detected<br>
  		1 - IC Card detected<br>
  		2 - Contactless Card detected<br>
 @result
 @deprecated
 return code.
 */
- (MposApiRetCode)integrateWaitCardStatus:(UInt32 *)status;

/*!
 @abstract
  Transaction processing<br>
  Before calling this method, you should call @link integrateWaitCardStatus: @/link. to judge whether the card is tapped or not
 @discussion
 @param  result
 [output] transaction result
 @result
 return code.
 */
- (MposApiRetCode)integrateTransStartWithResult:(MposModelSYS_PROC_INFO *)result;

/*!
 @abstract
  Transaction Process to finish PayWave transaction<br>
  Only when issuer authentication data was received,and card type is visa paywave.
  Calling this function, and ask card holder tap card again to finish online authorization
 @discussion
 @param  script
 [input] script data
 @param  result
 [output] transaction result
 @result
 return code.
 */
- (MposApiRetCode)integrateTransWaveFinishWithScript:(const NSData *)script withResult:(MposModelSYS_PROC_INFO *)result;

/*!
 @abstract set TLV data to emv kernel
 @discussion
 TLV should be set before ClssTransStart
 @param  tlvArray
 [input] tlv data,include one or more @link MposModelCLSS_TLV @/link objects
 @result
 return code.
 @deprecated
 */
-(MposApiRetCode)integrateSetTLVDataForTag:(NSArray*)tlvArray;

/*!
 @abstract get TLV data from emv kernel
 @discussion
 @param  tag
 [input] tlv tag
 @param  type
 [input]
 KERNTYPE_DEF 0
 KERNTYPE_JCB 1
 KERNTYPE_MC  2
 KERNTYPE_VIS 3
 KERNTYPE_PBOC  4
 KERNTYPE_AE 5
 KERNTYPE_RFU 6
 @param mode
 [input] encryption mode see @link //apple_ref/c/econst/EncryptionMode @/link
 @param index
 [input] index of the key to be used when mode != CLEAR.
 @param  value
 [output]the value of the specified tag, see @link //apple_ref/occ/cl/MposModelDataWithEncryptionMode @/link.
 @result
 return code.
 */
-(MposApiRetCode)integrateGetTLVDataForTag:(UInt32)tag whithType:(Byte)type mode:(EncryptionMode)mode keyIndex:(Byte)index value:(MposModelDataWithEncryptionMode **)value;
@end
