//
//  MposModelCLSS_PRE_PROC_INFO.h
//  MposApi
//
//  Created by ytqk on 7/18/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract pre-processing parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_PRE_PROC_INFO : NSObject

/*!
 @abstract Terminal floor limit of terminal (the same as terminal floor limit of EMV L2)
 */
@property UInt32 ulTermFLmt;

/*!
 @abstract Contactless transaction limit of reader(other transaction interface must be used if authorized amount is greater than this value)
 */
@property UInt32 ulRdClssTxnLmt;

/*!
 @abstract CVM required limit of reader
 */
@property UInt32 ulRdCVMLmt;

/*!
 @abstract Contactless floor limit of reader
 */
@property UInt32 ulRdClssFLmt;

/*!
 @abstract AID, 5~16 bytes
 */
@property Byte *aucAID;//[17];

/*!
 @abstract AID length
 */
@property Byte ucAidLen;

/*!
 @abstract Kernel type corresponding to the AID(e.g. VISA, MasterCard, PBOC)
 *  KERNTYPE_DEF 0
 *  KERNTYPE_JCB 1
 *  KERNTYPE_MC  2
 *  KERNTYPE_VIS 3
 *  KERNTYPE_PBOC  4
 *  KERNTYPE_AE 5
 *  KERNTYPE_ZIP 6
 *  KERNTYPE_FLASH 7
 *  KERNTYPE_RFU 8
 */
@property Byte ucKernType;


/*!
 @abstract AID selection flag, 1 - full match, 0 - partial match
 see @link //apple_ref/c/econst/EmvAppSelFlag @/link
 */
@property Byte ucSelFlg;

// payWave
/*!
 @abstract Is cryptogram version 17 supported? 1-yes, 0-no
 */
@property Byte ucCrypto17Flg;

/*!
 @abstract 
 0-TTQ requires online cryptogram when authorized amount is equal to 0
 1-Internal qVSDC does not support flag bit setting when authorized amount is equal to 0
 */
@property Byte ucZeroAmtNoAllowed;

/*!
 @abstract Does card reader support status check? 1-yes, 0-no
 */
@property Byte ucStatusCheckFlg;

/*!
 @abstract Reader's terminal transaction qualifiers, used in VISA/PBOC, tag =9F66, 5 bytes
 */
@property Byte *aucReaderTTQ;//[5];

// common
/*!
 @abstract whether the Terminal Floor Limit is present (the same as Terminal Floor Limit of EMV L2)
 */
@property Byte ucTermFLmtFlg;

/*!
 @abstract whether reader Contactless Transaction Limit is present
 */
@property Byte ucRdClssTxnLmtFlg;

/*!
 @abstract whether reader CVM Required Limit is present
 */
@property Byte ucRdCVMLmtFlg;

/*!
 @abstract wheterh reader Contactless Floor Limit is present
 */
@property Byte ucRdClssFLmtFlg;

/*!
 @abstract reserved, 2 bytes
 */
@property Byte *aucRFU;//[2];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
