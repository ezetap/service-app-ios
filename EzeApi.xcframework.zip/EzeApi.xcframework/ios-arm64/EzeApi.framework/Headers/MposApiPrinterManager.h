//
//  MposApiPrinterManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c, 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MposApiRetCodes.h"

/*!
 @abstract printer status enumeration
 @constant PRN_STATUS_OK                OK
 @constant PRN_STATUS_BUSY              busy
 @constant PRN_STATUS_NO_PAPER          out of paper
 @constant PRN_STATUS_DATA_FORMAT_ERR	print data format error
 @constant PRN_STATUS_FAULT             printer fault
 @constant PRN_STATUS_OVERHEATED        overheated
 @constant PRN_STATUS_UNFINISHED        unfinished
 @constant PRN_STATUS_NO_SUCH_FONT      lack of font
 @constant PRN_STATUS_DATA_TOO_LONG     data too long
 */
typedef enum {
    PRN_STATUS_OK 			=0x00,
    PRN_STATUS_BUSY 		=0x01,
    PRN_STATUS_NO_PAPER 	=0x02,
    PRN_STATUS_DATA_FORMAT_ERR =0x03,
    PRN_STATUS_FAULT	 	=0x04,
    PRN_STATUS_OVERHEATED 	=0x08,
    PRN_STATUS_UNFINISHED 	=0xf0,
    PRN_STATUS_NO_SUCH_FONT =0xfc,
    PRN_STATUS_DATA_TOO_LONG =0xfe,
}PrnStatus;

/*!
 @abstract maximum dots per line
 */
#define PRN_DOTS_PER_LINE (384)

/*!
 @abstract <b><font color="red">NOTE: D180, D200 doesn't support this function</font></b><br>MposApiPrinterManager is used to controll the printer, only usable for terminal with printer
 */
@interface MposApiPrinterManager : NSObject

/*!
 @abstract encoding of the string to print, default to kCFStringEncodingGB_18030_2000
 */
@property CFStringEncoding encoding;        //default to kCFStringEncodingGB_18030_2000

/*!
 @abstract get MposApiPrinterManager shared instance
 @result
 MposApiPrinterManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Set up printing character/ line spaces.
 @param xSpace
 character space
 @param ySpace
 line space
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnSetSpacesWithXSpace:(Byte)xSpace ySpace:(Byte)ySpace;

/*!
 @abstract Set character printing left boundary.
 @param indent
 dots in left boundary, range: 0~300
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnSetIndent:(UInt32)indent;

/*!
 @abstract Set printing gray level
 @param grayLevel
 <ul>
 <li>1 : default level, normal print slip
 <li>2 : reserved
 <li>3 : two-layer thermal printing
 <li>4 : two-layer thermal printing, higher gray level than 3
 <li>50~500 :  gray level is set according to percentage of default value. If it is 50, then set gray level to be 50% of default value; if it is 500, then set grey level to be 500% of default value.
 <li>Others : reserved and modification is invalid
 </ul>
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnSetGray:(UInt32)grayLevel;

/*!
 @abstract Inquire current printer status.
 @param status
 [output]printer status
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnStatus:(PrnStatus *)status;

/*!
 @abstract print a tring. 
 @discussion
  Note that this function doesn't print the string immediately, it only transmits the string to the printing buffer. call @link prnStart @/link to start printing. Total dots per line is 384.
 @param str
 [input] the string to print<br>
     support\r\n\f<br>
     support extra control as follows:
     <ul>
     	<li>%Ff, Font control, f is font size, ranged from 0 to 7, 8 fonts for english and chinese each.<br>
     		For English,  0: 8*16, 1: 16*24, 2: 8*32, 3: 16*48,
          	4: 16*16, 5: 32*24, 6: 16*32, 7: 32*48.<br>
           	For Chinese,  0: 16*16, 1: 24*24, 2: 16*32, 3: 24*48,
           	4: 32*16, 5: 48*24, 6: 32*32, 7: 48*48.
        <li>
        %Rr, Inversion control, r toggles inversion. 0 is normal, 1 is invert.
     </ul>       
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnStr:(const NSString *)str;

/*!
 @abstract print image.
 @discussion
 Note that this function doesn't print the image immediately, it only transmits the image to the printing buffer, call @link prnStart @/link to start printing. Note that the pixels outside the paper will be truncated.
 @param image
 image data to prin
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnImage:(const UIImage *)image;

/*!
 @abstract feed paper.
 @discussion
 Note that this function doesn't feed paper immediately, call @link prnStart @/link start feeding.
 @param dots
 dots to feed
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnFeed:(UInt32)dots;

/*!
 @abstract restore the default setting, reset the printing buffer.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnReset;

/*!
 @abstract start printing.
 @discussion
 Note that this function doesn't clean the printing buffer, i.e. calling this function multiple times will result in printing the same content multiple times. If you want to clear the printing buffer, call  @link prnReset @/link
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)prnStart;

@end
