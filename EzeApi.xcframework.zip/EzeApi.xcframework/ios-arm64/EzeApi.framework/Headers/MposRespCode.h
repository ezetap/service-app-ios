//
//  Proto.h
//  MposApi
//
//  Created by admin on 5/28/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MPOS_RET_SENSITIVE_CIPHER_DUKPTDES  -0x110000
#define MPOS_RET_SENSITIVE_CIPHER_MSKEY    (-0x110000 - 1)
typedef struct {
    UInt32 code;
    Byte cmd;
    Byte subCmd;
}MposRespCode;