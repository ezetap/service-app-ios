//
//  MposModelCLSS_READER_PARAM_MC.h
//  MposApi
//
//  Created by admin on 6/6/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposModelCLSS_READER_PARAM_MC : NSObject

/*!
 @abstract Merchant category code '9F15'(2Bytes)
 */
@property Byte *aucMerchCatCode;//[2];   // 商户分类码'9F15'(2字节)
/*!
 @abstract Merchant Identifier(15Bytes)
 */
@property Byte *aucMerchantID;//[15];    // 商户标识(15字节)

/*!
 @abstract <div class="zh">收单行标志, 6字节</div>
 <div class="en">Acquirer Identifier, 6 bytes</div>
 */
@property Byte *AcquierId;//[6];       //收单行标志

/*!
 @abstract <div class="zh">终端标识(终端号), 8字节 </div>
 <div class="en">Terminal Identification(Terminal number), 8 bytes</div>
 */
@property Byte *aucTmID;//[8];           // 终端标识(终端号)
/*!
 @abstract <div class="zh">终端类型</div>
 <div class="en">Terminal Type</div>
 */
@property Byte ucTmType;             // 终端类型
/*!
 @abstract 
  <div class="zh">终端性能, 3字节</div>
  <div class="en">Terminal Capabilities, 3 bytes</div>
 */
@property Byte *aucTmCap;//[3];          // 终端性能
/*!
 @abstract <div class="zh">终端附加性能, 5字节</div>
 <div class="en">Additional Terminal Capabilities, 5 bytes</div>
 */
@property Byte *aucTmCapAd;//[5];        // 终端附加性能

/*!
 @abstract if aucTmCntrCode valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucTmCntrCodeFlg;

/*!
 @abstract <div class="zh">终端国家代码, 2字节</div>
  <div class="en">Terminal Country Code, 2 bytes</div>
 */
@property Byte *aucTmCntrCode ;//[2];     // 终端国家代码

/*!
 @abstract if aucTmTransCur valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucTmTransCurFlg;

/*!
 @abstract <div class="zh">终端交易货币代码'5F2A'(2字节)</div>
  <div class="en">Transaction Currency Code '5F2A'(2Bytes)</div>
 */
@property Byte *aucTmTransCur;//[2];      // 终端交易货币代码'5F2A'(2字节)

/*!
 @abstract if ucTmTransCurExp valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucTransCurExpFlg;

/*!
 @abstract <div class="zh">终端交易货币指数'5F36'(1字节)</div>
  <div class="en"> Transaction Currency Exponent '5F36'(1Byte)</div>
 */
@property Byte ucTmTransCurExp;       // 终端交易货币指数'5F36'(1字节)

/*!
 @abstract if ucTransCateCode valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucTransCateCodeFlg;

/*!
 @abstract Transaction Category Code '9F53'
 */
@property Byte ucTransCateCode;

/*!
 @abstract <div class="zh">保留, 2字节</div>
  <div class="en">reserved, 2 bytes</div>
 */
@property Byte *aucRFU;//[2];


/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
