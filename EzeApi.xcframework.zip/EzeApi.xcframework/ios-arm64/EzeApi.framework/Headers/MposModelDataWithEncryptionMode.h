//
//  MposModelDataWithEncryptionMode.h
//  MposApi
//
//  Created by admin on 5/11/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract data encryption mode
 @constant CLEAR                                cleartext
 @constant SENSITIVE_CIPHER_DUKPTDES            sensitive data encrypted using dukpt des
 @constant SENSITIVE_CIPHER_MSKEY               sensitive data encrypted using ms key
 @constant SENSITIVE_CIPHER_MSKEY_T2_BCD        track2 data encrypted using ms key, the track2 data must be converted to BCD format
 @constant sensitive data encrypted using ms key. same as SENSITIVE_CIPHER_MSKEY except that the returned track1 data is complete
 */
typedef enum {
    CLEAR,
    SENSITIVE_CIPHER_DUKPTDES,
    SENSITIVE_CIPHER_MSKEY,
    SENSITIVE_CIPHER_MSKEY_T2_BCD,
    SENSITIVE_CIPHER_MSKEY_T1_COMPLETE
    
} EncryptionMode;

/*!
 @abstract the data model with encrytion mode information
 */
@interface MposModelDataWithEncryptionMode : NSObject

/*!
 @abstract init with specified encryption mode and data
 */
- (id)initWithEncyptionMode:(EncryptionMode)encMode data:(NSData *)data ksn:(NSData *)ksn maskedPan:(NSData *)maskedPan;

/*!
 @abstract data encryption mode,CLEAR or SENSITIVE_CIPHER_DUKPTDES, SENSITIVE_CIPHER_MSKEY
  see @link //apple_ref/c/econst/EncryptionMode @/link
 */
@property EncryptionMode encMode;

/*!
 @abstract used when encMode is SENSITIVE_CIPHER_DUKPTDES, it contains 10 bytes ksn.
 */
@property NSData *ksn;

/*!
 @abstract used for same TAGS when encMode is not CLEAR. eg: TAG 5A, it contains masked pan.
 */
@property NSData *maskedPan;

/*!
 @abstract
 if encMode is CLEAR the data is cleartext of the TAG.
 if encMode is SENSITIVE_CIPHER_MSKEY or SENSITIVE_CIPHER_DUKPTDES, the data is ciphertext of the TAG.
 */
@property NSData *data;

@end
