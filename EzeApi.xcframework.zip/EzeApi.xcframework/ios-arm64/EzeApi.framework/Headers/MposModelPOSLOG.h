//
//  MposModelPOSLOG.h
//  MposApi
//
//  Created by admin on 6/6/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelCURRENCY_CONFIG.h"

@interface MposModelPOSLOG : NSObject

/*!
 @abstract authorized amount. should include ulAmntOther if there's cashback. maximum 12 digits
 */
@property Byte *szAmount;	//[12+1];				// 授权金额(unsigned long), 若为返现, 则该金额需包括ulAmntOther的金额
/*!
 @abstract cashback amount. maximum 12 digits
 */
@property Byte *ulAmntOther;	//[12+1];          // 其他金额(unsigned long)
/*!
 @abstract STAN, maximum 12 digits
 */
@property Byte *ulSTAN;		//[12];				    // STAN
/*!
 @abstract transaction type (tag '9C')
 */
@property Byte ucPreTransType;             //for Clss Core
/*!
 @abstract trans date time, in format "YYYYMMDDhhmmss", 14 bytes
 */
@property Byte *szDateTime;		//[14+1];			// YYYYMMDDhhmmss
/*!
 @abstract terminal id, maximum 12 bytes
 */
@property Byte *uPosTID;		//[12];
/*!
 @abstract merchant id, maximum 16 bytes
 */
@property Byte *uMerchantID;		//[16];
/*!
 @abstract transaction type string to display, maximum 10 bytes
 */
@property Byte *ucPosTransType;		//[10];				// 交易类型, for coustmer
/*!
 @abstract currency configuration
 */
@property MposModelCURRENCY_CONFIG *stTranCurrency; //10 bytes
/*!
 @abstract timeout value to wait for tapping card, in unit of 100ms. default to 500(i.e. 50s) for 0
 */
@property UInt32 uiTimeOut;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
