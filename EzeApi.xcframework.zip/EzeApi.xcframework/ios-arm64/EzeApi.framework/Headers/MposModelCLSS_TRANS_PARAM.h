//
//  MposModelCLSS_TRANS_PARAM.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract contactless transaction paramter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_TRANS_PARAM : NSObject

/*!
 @abstract authorized amount
 */
@property UInt32 ulAmntAuth;

/*!
 @abstract other amount
 */
@property UInt32 ulAmntOther;

/*!
 @abstract transaction number
 */
@property UInt32 ulTransNo;

/*!
 @abstract transaction type(tag '9C')
 */
@property Byte ucTransType;

/*!
 @abstract transaction date YYMMDD, 3 bytes
 */
@property Byte *aucTransDate;//[4];

/*!
 @abstract transaction time HHMMSS, 3 bytes
 */
@property Byte *aucTransTime;//[4];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
