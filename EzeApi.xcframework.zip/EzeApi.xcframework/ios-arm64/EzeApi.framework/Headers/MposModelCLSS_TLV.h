//
//  MposModelCLSS_TLV.h
//  MposApi
//
//  Created by sunny on 7/24/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the TLV data, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_TLV : NSObject

/*!
 @abstract TAG should be in BCD
 */
@property Byte* ucTag; //[4]

/*!
 @abstract real length of ucTag
 */
@property Byte ucTagLen;

/*!
 @abstract data to be send, should be in BCD,maximum length is 25 bytes
 */
@property Byte* ucValue; //[25]

/*!
 @abstract real length of ucTagData
 */
@property Byte ucValueLen;

/*!
 @abstract
  KERNTYPE_DEF 0
  KERNTYPE_JCB 1
  KERNTYPE_MC  2
  KERNTYPE_VIS 3
  KERNTYPE_PBOC  4
  KERNTYPE_AE 5
  KERNTYPE_RFU 6
*/
@property Byte ucTagType;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
