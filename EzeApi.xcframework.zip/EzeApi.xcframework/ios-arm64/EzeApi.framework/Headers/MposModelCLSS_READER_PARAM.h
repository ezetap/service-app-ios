//
//  MposModelCLSS_READER_PARAM.h
//  MposApi
//
//  Created by ytqk on 7/18/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract reader parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_READER_PARAM : NSObject

/*!
 @abstract Transform modulus of referenced currency code and transaction currency code (exchange rate from transaction currency to referenced currency *1000)
 */
@property UInt32   ulReferCurrCon; 

/*!
 @abstract The length of Merchant Name and Location
 */
@property UInt16  usMchLocLen;

/*!
 @abstract Merchant Name and Location(1-256 Byte)
 */
@property Byte *aucMchNameLoc;//[257]; 

/*!
 @abstract  Merchant category code '9F15'(2Bytes)
 */
@property Byte *aucMerchCatCode;//[2];

/*!
 @abstract Merchant Identifier(15Bytes)
 */
@property Byte *aucMerchantID;//[15]; 

/*!
 @abstract Acquirer Identifier, 6 bytes
 */
@property Byte *AcquierId;//[6]; 

/*!
 @abstract Terminal Identification(Terminal number), 8 bytes
 */
@property Byte *aucTmID;//[8];

/*!
 @abstract Terminal Type
 */
@property Byte   ucTmType;

/*!
 @abstract Terminal Capabilities, 3 bytes
 */
@property Byte *aucTmCap;//[3];

/*!
 @abstract Additional Terminal Capabilities, 5 bytes
 */
@property Byte *aucTmCapAd;//[5];

/*!
 @abstract Terminal Country Code, 2 bytes
 */
@property Byte *aucTmCntrCode ;//[2];

/*!
 @abstract Transaction Currency Code '5F2A'(2Bytes)
 */
@property Byte *aucTmTransCur;//[2];

/*!
 @abstract Transaction Currency Exponent '5F36'(1Byte)
 */
@property Byte   ucTmTransCurExp;

/*!
 @abstract Transaction Reference Currency Code '9F3C'(2Bytes)
 */
@property Byte *aucTmRefCurCode;//[2];

/*!
 @abstract Transaction Reference Currency Exponent '9F3D'(1Byte)
 */
@property Byte   ucTmRefCurExp;	

/*!
 @abstract reserved, 3 bytes
 */
@property Byte *aucRFU;//[3];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
