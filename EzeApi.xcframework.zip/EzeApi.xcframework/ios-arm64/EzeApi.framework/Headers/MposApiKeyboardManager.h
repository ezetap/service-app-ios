//
//  MposApiKeyboardManager.h
//  MposApi
//
//  Created by admin on 18/4/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiRetCodes.h"

/*!
 @abstract Key value enumeration
 @constant KEY_INVALID       Invalid key or NO key detected
 @constant KEY_F1            F1
 @constant KEY_F2            F2
 @constant KEY_0             0
 @constant KEY_1             1
 @constant KEY_2             2
 @constant KEY_3             3
 @constant KEY_4             4
 @constant KEY_5             5
 @constant KEY_6             6
 @constant KEY_7             7
 @constant KEY_8             8
 @constant KEY_9             9
 @constant KEY_CLEAR         CLEAR
 @constant KEY_CANCEL        CANCEL
 @constant KEY_ENTER         ENTER
 @constant KEY_ALPHA         ALPHA
 @constant KEY_NUM           #
 */
typedef enum {
    KEY_INVALID  =-1,
    
    KEY_F1      =0x01,
    KEY_F2      =0x01,
    KEY_0       ='0',
    KEY_1       ='1',
    KEY_2       ='2',
    KEY_3       ='3',
    KEY_4       ='4',
    KEY_5       ='5',
    KEY_6       ='6',
    KEY_7       ='7',
    KEY_8       ='8',
    KEY_9       ='9',
    KEY_CLEAR   =0x08,
    KEY_CANCEL  =0x1B,
    KEY_ENTER   =0x0d,
    
    // below 2 keys are for D800
    KEY_ALPHA   =0x07,
    KEY_NUM     =0x23,      // #*
}KeyCode;

/*!
 @abstract MposApiKeyboardManager is used to control the keyboard
 */
@interface MposApiKeyboardManager : NSObject

/*!
 @abstract encoding of the string to display, default to kCFStringEncodingGB_18030_2000
 */
@property CFStringEncoding encoding;        //default to kCFStringEncodingGB_18030_2000

/*!
 @abstract get MposApiKeyboardManager shared instance
 @result
 MposApiKeyboardManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Check whether there are unread key values in keyboard buffer
 @discussion
 Keyboard has a 32-bytes key buffer. Key values can be read out by @link kbGetkeyWithTimeout:keyCode: @/link if there exist key values in buffer
 @param flag
 [output] true for yes, false otherwise
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)kbhit:(BOOL *)flag;

/*!
 @abstract Clear all the key values which have not been read in current keyboard buffer
 @result
 return code.
 */
- (MposApiRetCode)kbflush;

/*!
 @abstract get the first key code from the buffer. Will wait for key pressing if not pressed previously
 @discussion
 At most 32 key codes can be cached, key code will be discarded if cache is full. 
 @param timeout
 timeout to get the key code, in ms.
 @param keyCodeOrNULL
 [output] key code. give NULL if not interested in it. Specially, if NOT NULL and NO key detected, then output @link KEY_INVALID @/link
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)kbGetkeyWithTimeout:(UInt32)timeout keyCode:(KeyCode *)keyCodeOrNULL;

/*!
 @abstract
 get input string
 @discussion
 1.mode bits priority: bit3>bit4>bit5, mode & 0x38 can't be 0;
 2.the inputted characters will be displayed either with plain text or with '*'(controlled by bit 3);
 3.set bit7 to 1 if initial string is needed;
 4.Func key is NOT recorded in the output string;
 5.Pressing clear key will delete 1 character for plain text for clear all inputted charaters for password;
 6.Pressing 1 key multiple times quickly(in 1 second) to switch among digit and alpha characters;
 @param mode
 mode, bit setting are:
 <ul>
 <li>D7	1(0) enter to quit and with inital string. 1-yes, 0-no
 <li>D6	1(0) font size. 1-big, 0-small
 <li>D5	1(0) can input digits. 1-yes, 0-no
 <li>D4	1(0) can input alhpa characters. 1-yes, 0-no
 <li>D3	1(0) password mode(display '*'). 1-yes, 0-no
 <li>D2	1(0) alignment. 1-left, 0-right
 <li>D1	1(0) with dot. 1-yes, 0-no
 <li>D0	1(0) display inversed.  1-no, 0-yes
 </ul>
 @param minLen
 minimum length required to input
 @param maxLen
 maximum length allowed to input(at most 128 bytes)
 @param x
 x coordinate of the start position to input
 @param y
 y coordinate of the start position to input
 @param initialStringOrNil
 [input]initial string. null for missing.  <b>only valid when D7 is 1</b>
 @param status
 [output]input status. only status[0] is valid.  0x00: OK, 0x0D: enter to quit, 0xFF: cancelled
 @param stringOut
 [output]the input string, only valid when status[0] is 0
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)kbGetStringWithMode:(Byte)mode minLen:(Byte)minLen maxLen:(Byte)maxLen x:(UInt32)x y:(UInt32)y initialString:(const NSString *)initialStringOrNil status:(Byte *)status stringOut:(NSString **)stringOut;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 get input string with Chinese character support
 @discussion
 1.IME switched by pressing F1 key(pinyin->capital->lower-case->quwei). F2 key is used for page scrolling;<br>
 2.When using pinyin, pressing related button in order. e.g. to input '�?, enter'14664', press enter and select it.<br>
 3.When inputing alpha characters or digits, in capital mode or lower-case mode, pressing 1 key multiple times quickly(in 0.8 second) to switch to the needed one and select it.<br>
 4.press clear key to clear inputted character.<br> 
 5.D300 doesn't support this function
 @param max
 maximum length allowed to input(at most 128 bytes)
 @param timeout
 timeout(in second), 0 means wait forever
 @param initialStringOrNil
 [input]initial string. null for missing. 
 @param status
 [output]input status.  only status[0] is valid.  0x00: OK, 0xFD: timeout, 0xFF: cancelled
 @param stringOut
 [output]inputted characters, only valid when status[0] is 0
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)kbGetHzStringWithMaxLen:(Byte)max timeout:(UInt16)timeout initialString:(const NSString  *)initialStringOrNil status:(Byte *)status stringOut:(NSString **)stringOut;

/*!
 @abstract
 keyboard backlight mode
 @discussion
 the default backligh mode is 1
 @param mode
 0-off; 1-auto-off after 15 seconds; 2-on; 3-always off, cannot be activated by card insertion/swiping.
 @result
 return code.
 */
- (MposApiRetCode)kbBacklightWithMode:(Byte)mode;

/*!
 @abstract set keyboard locking mode
 @discussion
 Default mode is 1. Keyborad can be unlocked by pressing power switch, swiping card or inserting ICC card.Note that if screen is locked, then keyboard is locked and LCD backlight's brightness is 10%, in that case, setting keyboard backlight to on has no effect.
 @param mode
   0-keyboard locked, can be unlocked by pressing power switch, swiping card or inserting IC card;<br>
   1-auto-lock if idle for 30 seconds, can be lock/unlocked by pressing power switch;<br>
   2-unlocked, pressing power switch doesn't lock/unlock. @result
 return code.
 */
- (MposApiRetCode)kbLockWithMode:(Byte)mode;

/*!
 @abstract
get current status of keyboard
 @discussion
 Entering sleep status when keyboard locking detected can save power.<br>
 @param cmd
 0- if locked or not; 1 - if there's key code in key buffer or not; 2- if beep or not when pressing; 3- if keyboard backlight on or not;
 @param result
 cmd=0: 0- unlocked, 1- locked<br>
 cmd=1: >=0 number of key code<br>
 cmd=2: 0- not beep, 1- beep<br>
 cmd=3: 0- backlight off, 1- backlight on
 @result
 return code.
 */
- (MposApiRetCode)kbCheckWithCmd:(UInt32)cmd result:(SInt32 *)result;

/*!
 @abstract Set whether a beep should be made when a key is pressed
 @param flag
 0 - not beep,  1 - beep
 @result
 return code.
 */
- (MposApiRetCode)kbMuteWithFlag:(Byte)flag;

@end
