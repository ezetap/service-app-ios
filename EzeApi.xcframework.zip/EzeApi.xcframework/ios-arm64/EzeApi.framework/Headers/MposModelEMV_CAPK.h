//
//  MposModelEMV_CAPK.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract CA public key, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_CAPK : NSObject

/*!
 @abstract Registered Application Provider Identifier, 5 bytes
 */
@property Byte *RID;//[5];

/*!
 @abstract key index
 */
@property Byte KeyID;

/*!
 @abstract HASH arithmetic index (must be 1)
 */
@property Byte HashInd;

/*!
 @abstract RSA arithmetic index (must be 1)
 */
@property Byte ArithInd;

/*!
 @abstract module length
 */
@property Byte ModulLen;

/*!
 @abstract module, maximum 248 bytes
 */
@property Byte *Modul;//[248];

/*!
 @abstract exponent length (1 or 3)
 */
@property Byte ExpLen;

/*!
 @abstract exponent ("\x03" or "\x01\x00\x01")
 */
@property Byte *Exp;//[3];

/*!
 @abstract the expire date of the key (format : YYMMDD)
 */
@property Byte *ExpDate;//[3];

/*!
 @abstract key check sum, 20 bytes
 */
@property Byte *CheckSum;//[20];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
