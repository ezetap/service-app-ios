//
//  MposModelCLSS_PBOC_AID_PARAM.h
//  MposApi
//
//  Created by ytqk on 7/18/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract QPBOC application paramter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_PBOC_AID_PARAM : NSObject
/*!
 @abstract Terminal floor limit - the same as Terminal floor limit of contact EMV
 */
@property UInt32 ulTermFLmt;
/*!
 @abstract reserved, 4 bytes
 */
@property Byte *aucRFU;//[4];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
