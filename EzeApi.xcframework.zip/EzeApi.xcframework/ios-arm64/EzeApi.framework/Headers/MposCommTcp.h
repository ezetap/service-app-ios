//
//  MposCommTcp.h
//  MposComm
//
//  Created by kevintu@paxsz.com on 11/13/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import "MposCommBase.h"

/*!
 @abstract MposCommTcp manages TCP communications
 */
@interface MposCommTcp: MposCommBase<MposCommInf>

/*!
 @abstract init with host:port
 @param host
 host name or IP address
 @param port
 port
 */
- (id)initWithHost:(NSString *)host port:(NSInteger)port;

@end
