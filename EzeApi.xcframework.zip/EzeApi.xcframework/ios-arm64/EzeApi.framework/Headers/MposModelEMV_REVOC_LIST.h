//
//  MposModelEMV_REVOC_LIST.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract revoked CA public key, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_REVOC_LIST : NSObject

/*!
 @abstract RID(5 bytes)
 */
@property Byte *ucRid;//[5]

/*!
 @abstract Index of CA public key
 */
@property Byte ucIndex;

/*!
 @abstract Serial number of the issuer public key certification(3 bytes)
 */
@property Byte *ucCertSn;//[3]

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
