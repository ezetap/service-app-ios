//
//  MposApiPiccManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelPICC_PARA.h"
#import "MposModelAPDU_SEND.h"
#import "MposModelAPDU_RESP.h"
#import "MposApiRetCodes.h"

/*!
 @abstract PICC setup mode enumeration
 @constant PICC_SETUP_MODE_READ 	read configuration
 @constant PICC_SETUP_MODE_WRITE 	write configuration
 */
typedef enum {
    PICC_SETUP_MODE_READ = 'r',
    PICC_SETUP_MODE_WRITE = 'w',
}PiccSetupMode;

/*!
 @abstract PICC light index enumeration
 @constant PICC_LIGHT_RED       RED light
 @constant PICC_LIGHT_GREEN     GREEN light
 @constant PICC_LIGHT_YELLOW    YELLOW light
 @constant PICC_LIGHT_BLUE      BLUE light
 */
typedef enum {
    PICC_LIGHT_RED =0x01,
    PICC_LIGHT_GREEN =0x02,
    PICC_LIGHT_YELLOW =0x04,
    PICC_LIGHT_BLUE =0x08,
}PiccLightIdx;

/*!
 @abstract PICC card detect mode enumeration
 @constant PICC_DETECT_MODE_ISO14443        Detect type A card once, and detect type B card once; this conforms to ISO14443
 @constant PICC_DETECT_MODE_EMV             Detect type A card once, and detect type B card once; this conforms to EMV, generally you should use this mode
 @constant PICC_DETECT_MODE_TYPE_A_ONLY     Only detect type A card once
 @constant PICC_DETECT_MODE_TYPE_B_ONLY     Only detect type B card once
 @constant PICC_DETECT_MODE_TYPE_M1_ONLY    Only detect type M1 card once
 */
typedef enum {
    PICC_DETECT_MODE_ISO14443 =0x00,
    PICC_DETECT_MODE_EMV =0x01,
    PICC_DETECT_MODE_TYPE_A_ONLY ='A',
    PICC_DETECT_MODE_TYPE_B_ONLY ='B',
    PICC_DETECT_MODE_TYPE_M1_ONLY ='M',
}PiccDetectMode;

/*!
 @abstract PICC card type enumeration
 @constant PICC_CARD_TYPE_A         type A
 @constant PICC_CARD_TYPE_B         type B
 @constant PICC_CARD_TYPE_M         type M
 */
typedef enum {
    PICC_CARD_TYPE_A ='A',
    PICC_CARD_TYPE_B ='B',
    PICC_CARD_TYPE_M ='M',
}PiccCardType;

/*!
 @abstract PICC card remove mode enumeration
 @constant PICC_REMOVE_MODE_HALT    HALT, quit after sending halt command to card;no card removed check during this process.
 @constant PICC_REMOVE_MODE_REMOVE  REMOVE, sending halt command to card, and check card removal
 @constant PICC_REMOVE_MODE_EMV     card removal conforms to EMV.
 */
typedef enum {
    PICC_REMOVE_MODE_HALT ='H',
    PICC_REMOVE_MODE_REMOVE ='R',
    PICC_REMOVE_MODE_EMV ='E',
}PiccRemoveMode;

/*!
 @abstract M1 card operation mode enumeration
 @constant PICC_M1_OPERATE_INC_VALUE  Increase value
 @constant PICC_M1_OPERATE_DEC_VALUE  Decreate value
 @constant PICC_M1_OPERATE_BACKUP     Save as/backup
 */
typedef enum {
    PICC_M1_OPERATE_INC_VALUE ='+',
    PICC_M1_OPERATE_DEC_VALUE ='-',
    PICC_M1_OPERATE_BACKUP    ='>',
}PiccM1Operate;

/*!
 @abstract MposApiPiccManager is used to interact with Proximity IC Card. 
 */
@interface MposApiPiccManager : NSObject

/*!
 @abstract get MposApiPiccManager shared instance
 @result
 MposApiPiccManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Power on and reset contactless module, and check whether initial staus of the module is normal.
 @result
 return code.
 */
- (MposApiRetCode)piccOpen;

/*!
 @abstract Write specific parameter settings to suit special application environment; or read the current parameter settings.
 @param mode
 PICC setup mode
 @param piccPara
 [input] parameter settings
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccSetupWithMode:(PiccSetupMode)mode withPara:(MposModelPICC_PARA  *)piccPara;

/*!
 @abstract Detect PICC card according to appointed mode; when find the card, chooses and activates it.
 @param mode
 card detect mode
 @param detected
 [output] if card detected or not
 @param cardTypeOrNULL
 [output] 1 byte card type. set to NULL if not interested in it.
 @param serialNoOrNil
 [output] L+V: L: 1-byte length, V: L bytes serial no value. L is usually 4, 7 or 10 bytes  <br>
     give null to ignore this output
 @param cidOrNULL
 [output] card logical channel number. The channel number is allocated internally by driver, and range is 0~14 <br>
     give null to ignore this output
 @param otherOrNil
     [output] detailed error code and card response information<br>
     Format: error code (2 bytes) + card response data (L + V) + reserved <br>  
	Other[0-1]: return detailed error code(low bytes ahead); As card searching process is complicated, use this return value to locate exception error accurately 
	Other [2...]: <br>
	<ul>
		<li>For type A card, ATS (Answer To Select) is returned, and its length should be less than 62 bytes
		<li>For type B card, ATQB (Answer To Request B) is returned, and its length should be 12 bytes
		<li>For M1 card, ATQA (Answer To Request A) is returned, and its length should be 2 bytes. 
		<li>Please refer to relevant sections in ISO14443-3 and ISO14443-4 for detailed information of ATS, ATQB and ATQA.
		Other[...299]: content at the end are reserved bytes for future use; output is 0x00 at present If the message needs outputting, the size of the buffer should be at lease 300 bytes.            
	</ul>
    give null to ignore this output
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccDetectWithMode:(PiccDetectMode)mode detected:(BOOL *)detected cardType:(Byte *)cardTypeOrNULL serialNo:(NSData **)serialNoOrNil cid:(Byte *)cidOrNULL other:(NSData **)otherOrNil;

/*!
 @abstract In specific channel, send data of APDU format to card and receive response
 @param cid
 card logical channel number. from the CID output of @link piccDetectWithMode:detected:cardType:serialNo:cid:other: @/link, range is 0~14, currently it's always 0
 @param apduSend
 [input] Data structure send to PICC card
 @param apduResp
 [output] Data structure received from PICC card.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccIsoCommandWithCid:(Byte)cid apduSend:(const MposModelAPDU_SEND *)apduSend apduResp:(MposModelAPDU_RESP *)apduResp;

/*!
 @abstract Send stop command to card according to specific mode, or send halt command, judge whether card is removed from inductive area in addition.
 @param mode
 card remove mode
 @param cid
 card logical channel number. from the CID output of @link piccDetectWithMode:detected:cardType:serialNo:cid:other: @/link, range is 0~14, currently it's always 0
 @param removed
 [output] card removed or not
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccRemoveWithMode:(PiccRemoveMode)mode cid:(Byte)cid removed:(BOOL *)removed;

/*!
 @abstract 关闭PICC模块
 @result
 return code.
 */
- (MposApiRetCode)piccClose;

/*!
 @abstract Verify password A or B that should be submitted when reading/writing correspoding block of M1 card
 @param type
 'A'or'a':Password A is submitted.<br>
 'B'or'b':Password B is submitted.<br>
 @param blkNo
 Specifys visiting block number.
 @param pwd
 [input] password
 @param serialNo
 [input] serial number, from serialNo of @link piccDetectWithMode:detected:cardType:serialNo:cid:other: @/link.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)m1Authority:(Byte)type blkNo:(Byte)blkNo pwd:(const NSData *)pwd serialNo:(const NSData *)serialNo;

/*!
 @abstract Read content of block specified by M1 card (totally 16 bytes).
 @param blkNo
 Specifys visiting block number.
 @param value
 [output] 16 bytes block content.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)m1ReadBlock:(Byte)blkNo value:(Byte *)value;

/*!
 @abstract Write specified content to specified block of M1 card (totally 16 bytes).
 @param blkNo
 Specifys visiting block number.
 @param value
 [input] 16 bytes block content to write
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)m1WriteBlock:(Byte)blkNo value:(const Byte *)value;

/*!
 @abstract Increase or decrease value of M1 card purse, and updates main purse or backup purse finally.
 @param type
 '+':Increase value.  '-':Decrease value. '>':Save as/ backup operation.
 @param blkNo
 Specifys visiting block number.
 @param amount
 [input] amount value
 @param updateBlkNo
 Specifies number of block to which operation result will write
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)m1Operate:(Byte)type blkNo:(Byte)blkNo amount:(UInt32)amount updateBlkNo:(Byte)updateBlkNo;

/*!
 @abstract Control status of 4 LED lights of RF module.
 @param ledIdx
 LED index, use bit-or operation to control more than 1 light simultaneously.
 @param isOn
 on/off flag. true-ON, false-OFF
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccLightForLedIdx:(PiccLightIdx)ledIdx isOn:(BOOL)isOn;

/*!
 @abstract Initializing mifare interface chip as FeliCa modulate coding function.
 @param rate
 Setting transmission speed with card. 0-212Kbps,1-424Kbps. 
 @param pol
 Setting FeliCa modulate function. <br>
       0 forward modulate output. <br>
       1 reverse modulate output.<br>
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)piccInitFelica:(Byte)rate pol:(Byte)pol;

@end
