//
//  MposApiRetCodes.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract Return codes of MposApi
 @discussion Please use @link retCode2String: @/link to transfer the return code into human readable string
 @constant MPOSAPI_OK                         OK
 @constant GENERAL_ERR_PROTO_NAKED            protocol error-NAKed
 @constant GENERAL_ERR_PROTO_NO_ENOUGH_DATA   protocol error-no enough data
 @constant GENERAL_ERR_PROTO_DATA_FORMAT      protocol error-data format error
 @constant GENERAL_ERR_PROTO_CHKSUM           protocol error-checksum eror
 @constant GENERAL_ERR_PROTO_CONN             protocol error-connection failed
 @constant GENERAL_ERR_PROTO_SEND             protocol error-send failed
 @constant GENERAL_ERR_PROTO_RECV             protocol error-receive failed
 @constant GERERAL_ERR_UNSUPPORTED_FUNCTION   general error-not support this function
 @constant BASE_ERR_START                     BASE SYSTEM error-start value
 @constant BASE_ERR_DATETIME_FORMAT_YY        BASE SYSTEM error-error date time format : YY
 @constant BASE_ERR_DATETIME_FORMAT_MM        BASE SYSTEM error-error date time format : MM
 @constant BASE_ERR_DATETIME_FORMAT_DD        BASE SYSTEM error-error date time format : DD
 @constant BASE_ERR_DATETIME_FORMAT_hh        BASE SYSTEM error-error date time format : hh
 @constant BASE_ERR_DATETIME_FORMAT_mm        BASE SYSTEM error-error date time format : mm
 @constant BASE_ERR_DATETIME_FORMAT_ss        BASE SYSTEM error-error date time format : ss
 @constant BASE_ERR_RTC                       BASE SYSTEM error-RTC error
 @constant EMV_ERR_START                      EMV error-EMV error start value
 @constant EMV_ERR_ICC_RESET                  EMV error-IC card reset failed
 @constant EMV_ERR_ICC_CMD                    EMV error-IC card command failed
 @constant EMV_ERR_ICC_BLOCK                  EMV error-IC card blocked
 @constant EMV_ERR_RSP      	              EMV error-IC card response code error
 @constant EMV_ERR_APP_BLOCK                  EMV error-application blocked
 @constant EMV_ERR_NO_APP                     EMV error-no EMV application supported
 @constant EMV_ERR_USER_CANCEL                EMV error-user cancel
 @constant EMV_ERR_TIME_OUT                   EMV error-timeout
 @constant EMV_ERR_DATA                       EMV error-card data error
 @constant EMV_ERR_NOT_ACCEPT                 EMV error-transaction not accept
 @constant EMV_ERR_DENIAL                     EMV error-transaction denial
 @constant EMV_ERR_KEY_EXP                    EMV error-key expired
 @constant EMV_ERR_NO_PINPAD                  EMV error-no pinpad or pinpad doesn't work
 @constant EMV_ERR_NO_PASSWORD                EMV error-no pin
 @constant EMV_ERR_SUM   		              EMV error-capk checksum error
 @constant EMV_ERR_NOT_FOUND                  EMV error-data not found
 @constant EMV_ERR_NO_DATA                    EMV error-no specified data
 @constant EMV_ERR_OVERFLOW                   EMV error-data overflow
 @constant EMV_ERR_NO_TRANS_LOG               EMV error-no tranlog entry
 @constant EMV_ERR_RECORD_NOTEXIST            EMV error-no record
 @constant EMV_ERR_LOGITEM_NOTEXIST           EMV error-no log item
 @constant EMV_ERR_ICC_RSP_6985               EMV error-icc responded code 6985
 @constant CLSS_ERR_USE_CONTACT               EMV error-use contact interface
 @constant EMV_ERR_FILE				          EMV error-file error
 @constant CLSS_ERR_TERMINATE      	          EMV error-clss transaction terminated
 @constant CLSS_ERR_FAILED				      EMV error-clss transaction failed
 @constant CLSS_ERR_DECLINE			          EMV error-clss transaction declined
 @constant EMV_ERR_PARAM			          EMV error-parameter error
 @constant CLSS_ERR_WAVE2_OVERSEA             EMV error-CLSS_ERR_WAVE2_OVERSEA
 @constant CLSS_ERR_WAVE2_TERMINATED          EMV error-wave2 DDA response TLV format error
 @constant CLSS_ERR_WAVE2_US_CARD             EMV error-CLSS_ERR_WAVE2_US_CARD
 @constant CLSS_ERR_WAVE3_INS_CARD   	      EMV error-CLSS_ERR_WAVE3_INS_CARD
 @constant CLSS_ERR_RESELECT_APP      	      EMV error-need reselect app
 @constant CLSS_ERR_CARD_EXPIRED      	      EMV error-card expired
 @constant EMV_ERR_NO_APP_PPSE			      EMV error-no app and PPSE sel error
 @constant CLSS_ERR_USE_VSDC			      EMV error-CLSS_ERR_USE_VSDC
 @constant CLSS_ERR_CVMDECLINE			      EMV error-CVM result in decline for AE (for AE)
 @constant CLSS_ERR_REFER_CONSUMER_DEVICE	  EMV error-GPO response 6986
 @constant ICC_ERR_START                      IC Card error-start value
 @constant ICC_ERR_TIMEOUT                    IC Card error-ICC communication timeout
 @constant ICC_ERR_PULLOUT_CARD               IC Card error-IC Card pulled out 
 @constant ICC_ERR_PARITY                     IC Card error-parity error
 @constant ICC_ERR_CHANNEL                    IC Card error-channel error
 @constant ICC_ERR_DATA_LEN_OUT               IC Card error-ICC data length error
 @constant ICC_ERR_PROTOCOL                   IC Card error-protocol error (neither T=0 nor T=1)
 @constant ICC_ERR_NO_RESET_CARD              IC Card error-card not reset
 @constant ICC_ERR_NOT_CALL                   IC Card error-cannot communicate or not power on
 @constant MAG_ERR_START                      Mag error-start value
 @constant PED_ERR_START                      PED error-start value
 @constant PED_ERR_NO_KEY                     PED error-Key does not exist
 @constant PED_ERR_KEYIDX                     PED error-Key index error, parameter index is not in the range
 @constant PED_ERR_DERIVE                     PED error-When key is written, the source key level is lower than the destination level
 @constant PED_ERR_CHECK_KEY_FAIL             PED error-Key verification failed
 @constant PED_ERR_NO_PIN_INPUT               PED error-No PIN input
 @constant PED_ERR_INPUT_CANCEL               PED error-Cancel to enter PIN
 @constant PED_ERR_WAIT_INTERVAL              PED error-Calling function interval is less than minimum interval time
 @constant PED_ERR_CHECK_MODE                 PED error-KCV mode error, do not support
 @constant PED_ERR_NO_RIGHT_USE               PED error-Not allowed to use the key. When key label is not correct or source key type is bigger than destination key type, PED will return this code
 @constant PED_ERR_KEY_TYPE                   PED error-Key type error
 @constant PED_ERR_EXPLEN                     PED error-Expected PIN length string error
 @constant PED_ERR_DSTKEY_IDX                 PED error-Destination key index error
 @constant PED_ERR_SRCKEY_IDX                 PED error-Source key index error
 @constant PED_ERR_KEY_LEN                    PED error-Key length error
 @constant PED_ERR_INPUT_TIMEOUT              PED error-PIN input timeout
 @constant PED_ERR_NO_ICC                     PED error-IC card does not exist
 @constant PED_ERR_ICC_NO_INIT                PED error-IC card is not intilized
 @constant PED_ERR_GROUP_IDX                  PED error-DUKPT index error
 @constant PED_ERR_PARAM_PTR_NULL             PED error-Pointer parameter error
 @constant PED_ERR_LOCKED                     PED error-PED locked
 @constant PED_ERROR                          PED error-PED general error
 @constant PED_ERR_NOMORE_BUF                 PED error-No free buffer
 @constant PED_ERR_NEED_ADMIN                 PED error-Not administration
 @constant PED_ERR_DUKPT_OVERFLOW             PED error-DUKPT overflow
 @constant PED_ERR_KCV_CHECK_FAIL             PED error-KCV check error
 @constant PED_ERR_SRCKEY_TYPE                PED error-When key is written, the ID of source key does not match the type of source key
 @constant PED_ERR_UNSPT_CMD                  PED error-Command not supprt
 @constant PED_ERR_COMM                       PED error-Communication error
 @constant PED_ERR_NO_UAPUK                   PED error-No user authentication public key
 @constant PED_ERR_ADMIN                      PED error-Administration error
 @constant PED_ERR_DOWNLOAD_INACTIVE          PED error-PED download inactive
 @constant PED_ERR_KCV_ODD_CHECK_FAIL         PED error-KCV parity check fail
 @constant PED_ERR_PED_DATA_RW_FAIL           PED error-Read PED data fail
 @constant PED_ERR_ICC_CMD                    PED error-ICC operation fail
 @constant PED_ERR_INPUT_CLEAR                PED error-Pressing CLEAR to exit input
 @constant PED_ERR_NO_FREE_FLASH              PED error-PED No enough space
 @constant PED_ERR_DUKPT_NEED_INC_KSN         PED error-DUKPT need inc ksn
 @constant PED_ERR_KCV_MODE                   PED error-KCV MODE error
 @constant PED_ERR_DUKPT_NO_KCV               PED error-NO KCV
 @constant PED_ERR_PIN_BYPASS_BYFUNKEY        PED error-press FN/ATM4 KEY for PIN input
 @constant PED_ERR_MAC                        PED error-verify MAC error
 @constant PED_ERR_CRC                        PED error-verify CRC error
 @constant PICC_ERR_START                     PICC error-start value
 @constant PICC_ERR_PARAMETER                 PICC error-Parameter error
 @constant PICC_ERR_NOT_OPEN                  PICC error-RF module close
 @constant PICC_ERR_NOT_SEARCH_CARD           PICC error-No specific card in sensing area
 @constant PICC_ERR_CARD_TOO_MANY             PICC error-Too much card in sensing area(communication conflict)
 @constant PICC_ERR_PROTOCOL                  PICC error-Protocol error(The data reeponse from card breaches the agreement)
 @constant PICC_ERR_CARD_NOT_REMOVED          PICC error-Card not removed
 @constant PICC_ERR_CARD_NO_ACTIVATION        PICC error-Card not activated
 @constant PICC_ERR_MUTI_CARD                 PICC error-Multi-card conflict
 @constant PICC_ERR_TIMEOUT                   PICC error-No response timeout
 @constant PICC_ERR_PROTOCOL2                 PICC error-protocol error
 @constant PICC_ERR_IO                        PICC error-Communication transmission error
 @constant PICC_ERR_M1_CARD_VERIFY            PICC error-M1 Card authentication failure
 @constant PICC_ERR_FAN_NOT_VERIFY            PICC error-Sector is not certified
 @constant PICC_ERR_DATA_BLOCK                PICC error-The data format of value block is incorrect
 @constant PICC_ERR_CARD_SENSE                PICC error-Card is still in sensing area
 @constant PICC_ERR_CARD_STATUS               PICC error-Card status error(If A/B card call M1 card interface, or M1 card call PiccIsoCommand interface)
 @constant PICC_ERR_NOT_CALL                  PICC error-Interface chip does not exist or abnormal.
 @constant PRN_ERR_START                      Printer error-start value
 @constant PRN_ERR_BUSY                       Printer error-busy
 @constant PRN_ERR_NO_PAPER                   Printer error-out of paper
 @constant PRN_ERR_DATA_FORMAT                Printer error-data format error
 @constant PRN_ERR_FAULT                      Printer error-printer fault
 @constant PRN_ERR_OVERHEATED                 Printer error-overheated
 @constant PRN_ERR_UNFINISHED                 Printer error-print unfinished
 @constant PRN_ERR_NO_SUCH_FONT               Printer error-no such font
 @constant PRN_ERR_DATA_TOO_LONG              Printer error-data package to long
 @constant UI_ERR_START                       UI error-start value
 @constant UI_ERR_PARAM                       UI error-error parameter
 @constant KEYBOARD_ERR_START                 keyboard error-start value
 @constant COMMON_ERR_START                   common error-start value
 @constant COMMON_ERR_DATA                    common error-common data error
 @constant COMMON_ERR_DATA_TYPE               common error-data type error
 @constant COMMON_ERR_DATA_VERIFY             common error-data verify error
 @constant COMMON_ERR_DATA_DECRYPT            common error-data decryption error
 @constant COMMON_ERR_DATA_ENCRYPT            common error-data encryption error
 @constant COMMON_ERR_DATA_INVALID_SOURCE     common error-data invalid source
 @constant COMMON_ERR_DATA_INTEGRITY          common error-data integrity error
 @constant COMMON_ERR_DATA_READ               common error-data read error
 @constant COMMON_ERR_DATA_WRITE              common error-data write error
 @constant COMMON_ERR_END                     common error-end value
 */
typedef enum {
    
    MPOSAPI_OK                          =0,
    
    GENERAL_ERR_PROTO_NAKED             = -2,
    GENERAL_ERR_PROTO_NO_ENOUGH_DATA    = -3,
    GENERAL_ERR_PROTO_DATA_FORMAT       = -4,
    GENERAL_ERR_PROTO_CHKSUM            = -5,
    GENERAL_ERR_PROTO_CONN              = -6,
    GENERAL_ERR_PROTO_SEND              = -7,
    GENERAL_ERR_PROTO_RECV              = -8,

    GERERAL_ERR_UNSUPPORTED_FUNCTION    = -0xFFFF,

    BASE_ERR_START = -0x80000,
    BASE_ERR_DATETIME_FORMAT_YY = BASE_ERR_START - 0x01,
    BASE_ERR_DATETIME_FORMAT_MM = BASE_ERR_START - 0x02,
    BASE_ERR_DATETIME_FORMAT_DD = BASE_ERR_START - 0x03,
    BASE_ERR_DATETIME_FORMAT_hh = BASE_ERR_START - 0x04,
    BASE_ERR_DATETIME_FORMAT_mm = BASE_ERR_START - 0x05,
    BASE_ERR_DATETIME_FORMAT_ss = BASE_ERR_START - 0x06,
    BASE_ERR_RTC = BASE_ERR_START - 0xff,

    EMV_ERR_START = -0xa0000,
    EMV_ERR_ICC_RESET     = EMV_ERR_START - 1,
    EMV_ERR_ICC_CMD       = EMV_ERR_START - 2,
    EMV_ERR_ICC_BLOCK     = EMV_ERR_START - 3,
    EMV_ERR_RSP      	  = EMV_ERR_START - 4,
    EMV_ERR_APP_BLOCK     = EMV_ERR_START - 5,
    EMV_ERR_NO_APP        = EMV_ERR_START - 6,
    EMV_ERR_USER_CANCEL   = EMV_ERR_START - 7,
    EMV_ERR_TIME_OUT      = EMV_ERR_START - 8,
    EMV_ERR_DATA          = EMV_ERR_START - 9,
    EMV_ERR_NOT_ACCEPT    = EMV_ERR_START - 10,
    EMV_ERR_DENIAL        = EMV_ERR_START - 11,
    EMV_ERR_KEY_EXP       = EMV_ERR_START - 12,
    EMV_ERR_NO_PINPAD     = EMV_ERR_START - 13,
    EMV_ERR_NO_PASSWORD   = EMV_ERR_START - 14,
    EMV_ERR_SUM   		  = EMV_ERR_START - 15,
    EMV_ERR_NOT_FOUND     = EMV_ERR_START - 16,
    EMV_ERR_NO_DATA       = EMV_ERR_START - 17,
    EMV_ERR_OVERFLOW      = EMV_ERR_START - 18,
    EMV_ERR_NO_TRANS_LOG      = EMV_ERR_START - 19,
    EMV_ERR_RECORD_NOTEXIST   = EMV_ERR_START - 20,
    EMV_ERR_LOGITEM_NOTEXIST  = EMV_ERR_START - 21,
    EMV_ERR_ICC_RSP_6985      = EMV_ERR_START - 22,
    
    CLSS_ERR_USE_CONTACT    	= EMV_ERR_START - 23,
    EMV_ERR_FILE				= EMV_ERR_START - 24,
    CLSS_ERR_TERMINATE      	= EMV_ERR_START - 25,
    CLSS_ERR_FAILED				= EMV_ERR_START - 26,
    CLSS_ERR_DECLINE			= EMV_ERR_START - 27,
    EMV_ERR_PARAM			  = EMV_ERR_START - 30,
    CLSS_ERR_WAVE2_OVERSEA      = EMV_ERR_START - 31,
    CLSS_ERR_WAVE2_TERMINATED   = EMV_ERR_START - 32,
    CLSS_ERR_WAVE2_US_CARD      = EMV_ERR_START - 33,
    CLSS_ERR_WAVE3_INS_CARD   	= EMV_ERR_START - 34,
    CLSS_ERR_RESELECT_APP      	= EMV_ERR_START - 35,
    CLSS_ERR_CARD_EXPIRED      	= EMV_ERR_START - 36,
    EMV_ERR_NO_APP_PPSE			= EMV_ERR_START - 37,
    CLSS_ERR_USE_VSDC			= EMV_ERR_START - 38,
    CLSS_ERR_CVMDECLINE			= EMV_ERR_START - 39,
    CLSS_ERR_REFER_CONSUMER_DEVICE			= EMV_ERR_START - 40,
    EMV_ERR_NO_CAPK  			= EMV_ERR_START - 41,
    EMV_ERR_NO_REVLIST			= EMV_ERR_START - 42,

    ICC_ERR_START = -0x30000,
    ICC_ERR_TIMEOUT = ICC_ERR_START - 0x01,
    ICC_ERR_PULLOUT_CARD = ICC_ERR_START - 0x02,
    ICC_ERR_PARITY = ICC_ERR_START - 0x03,
    ICC_ERR_CHANNEL = ICC_ERR_START - 0x04,
    ICC_ERR_DATA_LEN_OUT = ICC_ERR_START - 0x05,
    ICC_ERR_PROTOCOL = ICC_ERR_START - 0x06,
    ICC_ERR_NO_RESET_CARD = ICC_ERR_START - 0x07,
    ICC_ERR_NOT_CALL = ICC_ERR_START - 0xff,


    MAG_ERR_START = -0x20000,


    PED_ERR_START = -0x10000,
    PED_ERR_NO_KEY = PED_ERR_START - 301,
    PED_ERR_KEYIDX = PED_ERR_START - 302,
    PED_ERR_DERIVE = PED_ERR_START - 303,
    PED_ERR_CHECK_KEY_FAIL = PED_ERR_START - 304,
    PED_ERR_NO_PIN_INPUT = PED_ERR_START - 305,
    PED_ERR_INPUT_CANCEL = PED_ERR_START - 306,
    PED_ERR_WAIT_INTERVAL = PED_ERR_START - 307,
    PED_ERR_CHECK_MODE = PED_ERR_START - 308,
    PED_ERR_NO_RIGHT_USE = PED_ERR_START - 309,
    PED_ERR_KEY_TYPE = PED_ERR_START - 310,
    PED_ERR_EXPLEN = PED_ERR_START - 311,
    PED_ERR_DSTKEY_IDX = PED_ERR_START - 312,
    PED_ERR_SRCKEY_IDX = PED_ERR_START - 313,
    PED_ERR_KEY_LEN = PED_ERR_START - 314,
    PED_ERR_INPUT_TIMEOUT = PED_ERR_START - 315,
    PED_ERR_NO_ICC = PED_ERR_START - 316,
    PED_ERR_ICC_NO_INIT = PED_ERR_START - 317,
    PED_ERR_GROUP_IDX = PED_ERR_START - 318,
    PED_ERR_PARAM_PTR_NULL = PED_ERR_START - 319,
    PED_ERR_LOCKED = PED_ERR_START - 320,
    PED_ERROR = PED_ERR_START - 321,
    PED_ERR_NOMORE_BUF = PED_ERR_START - 322,
    PED_ERR_NEED_ADMIN = PED_ERR_START - 323,
    PED_ERR_DUKPT_OVERFLOW = PED_ERR_START - 324,
    PED_ERR_KCV_CHECK_FAIL = PED_ERR_START - 325,
    PED_ERR_SRCKEY_TYPE = PED_ERR_START - 326,
    PED_ERR_UNSPT_CMD = PED_ERR_START - 327,
    PED_ERR_COMM = PED_ERR_START - 328,
    PED_ERR_NO_UAPUK = PED_ERR_START - 329,
    PED_ERR_ADMIN = PED_ERR_START - 330,
    PED_ERR_DOWNLOAD_INACTIVE = PED_ERR_START - 331,
    PED_ERR_KCV_ODD_CHECK_FAIL = PED_ERR_START - 332,
    PED_ERR_PED_DATA_RW_FAIL = PED_ERR_START - 333,
    PED_ERR_ICC_CMD = PED_ERR_START - 334,
    PED_ERR_INPUT_CLEAR = PED_ERR_START - 339,
    PED_ERR_NO_FREE_FLASH = PED_ERR_START - 343,
    PED_ERR_DUKPT_NEED_INC_KSN = PED_ERR_START - 344,
    PED_ERR_KCV_MODE = PED_ERR_START - 345,
    PED_ERR_DUKPT_NO_KCV = PED_ERR_START - 346,
    PED_ERR_PIN_BYPASS_BYFUNKEY = PED_ERR_START - 347,
    PED_ERR_MAC = PED_ERR_START - 348,
    PED_ERR_CRC = PED_ERR_START - 349,
    PED_ERR_PAN = PED_ERR_START - 350,


    PICC_ERR_START = -0x50000,
    PICC_ERR_PARAMETER = PICC_ERR_START - 0x01,
    PICC_ERR_NOT_OPEN = PICC_ERR_START - 0x02,
    PICC_ERR_NOT_SEARCH_CARD = PICC_ERR_START - 0x03,
    PICC_ERR_CARD_TOO_MANY = PICC_ERR_START - 0x04,
    PICC_ERR_PROTOCOL = PICC_ERR_START - 0x05,
    PICC_ERR_CARD_NOT_REMOVED = PICC_ERR_START - 0x06,
    PICC_ERR_CARD_NO_ACTIVATION = PICC_ERR_START - 0x13,
    PICC_ERR_MUTI_CARD = PICC_ERR_START - 0x14,
    PICC_ERR_TIMEOUT = PICC_ERR_START - 0x15,
    PICC_ERR_PROTOCOL2 = PICC_ERR_START - 0x16,
    PICC_ERR_IO = PICC_ERR_START - 0x17,
    PICC_ERR_M1_CARD_VERIFY = PICC_ERR_START - 0x18,
    PICC_ERR_FAN_NOT_VERIFY = PICC_ERR_START - 0x19,
    PICC_ERR_DATA_BLOCK = PICC_ERR_START - 0x1A,
    PICC_ERR_CARD_SENSE = PICC_ERR_START - 0x1B,
    PICC_ERR_CARD_STATUS = PICC_ERR_START - 0x1C,
    PICC_ERR_NOT_CALL = PICC_ERR_START - 0xff,


    PRN_ERR_START = -0x90000,
    PRN_ERR_BUSY = PRN_ERR_START - 0x01,
    PRN_ERR_NO_PAPER = PRN_ERR_START - 0x02,
    PRN_ERR_DATA_FORMAT = PRN_ERR_START - 0x03,
    PRN_ERR_FAULT = PRN_ERR_START - 0x04,
    PRN_ERR_OVERHEATED = PRN_ERR_START - 0x08,
    PRN_ERR_UNFINISHED = PRN_ERR_START - 0xf0,
    PRN_ERR_NO_SUCH_FONT = PRN_ERR_START - 0xfc,
    PRN_ERR_DATA_TOO_LONG = PRN_ERR_START - 0xfe,

    UI_ERR_START = -0x60000,
    UI_ERR_PARAM = UI_ERR_START - 1,

    KEYBOARD_ERR_START  = -0x70000,
    
    COMMON_ERR_START = -0x100000,
    COMMON_ERR_DATA  = COMMON_ERR_START - 0x01,
    COMMON_ERR_DATA_TYPE  = COMMON_ERR_START - 0x02,
    COMMON_ERR_DATA_VERIFY  = COMMON_ERR_START - 0x03,
    COMMON_ERR_DATA_DECRYPT  = COMMON_ERR_START - 0x04,
    COMMON_ERR_DATA_ENCRYPT  = COMMON_ERR_START - 0x05,
    COMMON_ERR_DATA_INVALID_SOURCE  = COMMON_ERR_START - 0x06,
    COMMON_ERR_DATA_INTEGRITY  = COMMON_ERR_START - 0x07,
    COMMON_ERR_DATA_READ  = COMMON_ERR_START - 0x08,
    COMMON_ERR_DATA_WRITE  = COMMON_ERR_START - 0x09,
    
    COMMON_ERR_END = COMMON_ERR_DATA_WRITE,
    
    DATA_ENCRYPTED_BY_DUKPT_KEY = -0x110000,
    DATA_ENCRYPTED_BY_MS_KEY = (-0x110000 - 1)
    
}MposApiRetCode;

/*!
 @abstract MposApiRetCodes manages the return code
 */
@interface MposApiRetCodes : NSObject

/*!
 @abstract convert the return code into human readable string
 @discussion
 @param retCode
   return code to convert
 @result
    the converted string, empty if not recognized
 */
+ (NSString *)retCode2String:(MposApiRetCode)retCode;

@end
