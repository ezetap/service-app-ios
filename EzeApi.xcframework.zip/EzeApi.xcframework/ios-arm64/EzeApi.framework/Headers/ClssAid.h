//
//  ClssAid.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelCLSS_APP_LIST.h"
#import "MposUtils.h"

@interface ClssAid : NSObject

@property(strong, nonatomic) NSMutableArray *appList;
@end
