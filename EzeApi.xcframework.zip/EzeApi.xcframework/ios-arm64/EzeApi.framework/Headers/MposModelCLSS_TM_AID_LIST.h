//
//  MposModelCLSS_TM_AID_LIST.h
//  MposApi
//
//  Created by ytqk on 7/18/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract blocked AID parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_TM_AID_LIST : NSObject

/*!
 @abstract AID length
 */
@property Byte ucAidLen;

/*!
 @abstract AID, 5~16 bytes
 */
@property Byte *aucAID;	//[17];

/*!
 @abstract partial matching flag(1-partial matching. 0-full matching)
 */
@property Byte ucSelFlg;

/*!
 @abstract kernel type
 */
@property Byte ucKernType;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
