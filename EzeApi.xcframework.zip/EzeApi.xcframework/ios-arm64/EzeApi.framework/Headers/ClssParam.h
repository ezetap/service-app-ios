//
//  ClssParam.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelCLSS_READER_PARAM.h"
#import "MposModelClSS_VISA_AID_PARAM.h"
#import "MposModelCLSS_READER_PARAM_MC.h"
#import "MposModelClSS_MC_AID_PARAM_MC.h"
#import "MposModelCLSS_TERM_CONFIG_MC.h"

@interface ClssParam : NSObject

@property (strong, nonatomic) MposModelCLSS_READER_PARAM *clssReaderParam;
@property  (strong, nonatomic)  MposModelClSS_VISA_AID_PARAM *clssVisaAidParam;
@property  (strong, nonatomic) MposModelCLSS_READER_PARAM_MC *clssReaderParamMC;
@property (strong, nonatomic) MposModelClSS_MC_AID_PARAM_MC *clssMcAidParamMC;
@property (strong, nonatomic) MposModelCLSS_TERM_CONFIG_MC *clssTermConfigMC;

@end
