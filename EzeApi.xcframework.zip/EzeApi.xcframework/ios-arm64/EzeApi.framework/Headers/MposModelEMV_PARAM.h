//
//  MposModelEMV_PARAM.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract EMV terminal parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_PARAM : NSObject

/*!
 @abstract merchant name(usually no need to set), maximum 255 bytes
 */
@property Byte *MerchName;//[256]

/*!
 @abstract merchant catalog code(usually no need to set), 2 bytes
 */
@property Byte *MerchCateCode;//[2]

/*!
 @abstract merchant identification(should be set), 15 bytes
 */
@property Byte *MerchId;//[15]

/*!
 @abstract terminal identification(should be set), 8 bytes
 */
@property Byte *TermId;//[8]

/*!
 @abstract terminal type(if this is used on a POS terminal, no need set it)
 */
@property Byte TerminalType;

/*!
 @abstract terminal capability(if this is used on a POS terminal, no need set it)
 */
@property Byte *Capability;//[3]

/*!
 @abstract terminal extended capability(if this is used on a POS terminal, no need set it)
 */
@property Byte *ExCapability;//[5]

/*!
 @abstract transaction currency exponent (default : 0x02). For example :  RMB, USD, HKD: 0x02, Korean WON: 0x00
 */
@property Byte TransCurrExp;

/*!
 @abstract reference currency exponent (default: "0x02")
 */
@property Byte ReferCurrExp;

/*!
 @abstract reference currency code (default: "\x08\x40"), 2 bytes
 */
@property Byte *ReferCurrCode;//[2]

/*!
 @abstract terminal country code (default : "\x08\x40") USA: "\x08\x40", China: "\x01\x56", Korea : "\x04\x10", Singapore: "\x07\x02",  2 bytes
 */
@property Byte *CountryCode;//[2]

/*!
 @abstract transaction currency code (default : "\x08\x40") USA: "\x08\x40", China: "\x01\x56", Korea : "\x04\x10", Singapore: "\x07\x02",  2 bytes
 */
@property Byte *TransCurrCode;//[2]

/*!
 @abstract the conversion quotients between transaction currency and reference currency (default : 1000) (the exchange rate of transaction currency to reference currency *1000)
 */
@property UInt32 ReferCurrCon;

/*!
 @abstract set current transaction type, see @link //apple_ref/c/tdef/EmvTransType @/link<br>
 can be: <br>
 @link //apple_ref/c/econst/EMV_TRANS_TYPE_CASH @/link<br>
 @link //apple_ref/c/econst/EMV_TRANS_TYPE_SERVICE @/link<br>
 @link //apple_ref/c/econst/EMV_TRANS_TYPE_GOODS @/link | @link //apple_ref/c/econst/EMV_TRANS_TYPE_SERVICE @/link <br>
 @link //apple_ref/c/econst/EMV_TRANS_TYPE_SERVICE @/link | @link //apple_ref/c/econst/EMV_TRANS_TYPE_CASHBACK @/link <br>
 */
@property Byte TransType;

/*!
 @abstract merchant force online (1 means always online transaction)
 */
@property Byte ForceOnline;

/*!
 @abstract read the IC card PIN retry counter before verify the PIN or not (1 : read, 0 : not read, default : 1)
 */
@property Byte GetDataPIN;

/*!
 @abstract support PSE selection mode or not (1 : support, 0 : not support, default : 1)
 */
@property Byte SurportPSESel;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
