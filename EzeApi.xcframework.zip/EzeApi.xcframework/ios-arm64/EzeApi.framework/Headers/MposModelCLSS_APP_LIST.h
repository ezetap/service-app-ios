//
//  MposModelCLSS_APP_LIST.h
//  MposApi
//
//  Created by admin on 14-10-23.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelCLSS_APP_LIST.h"
@class MposModelCLSS_PRE_PROC_INFO;

/*!
 @abstract blocked AID parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_APP_LIST : NSObject

/*!
 @abstract Terminal action code(denial)
*/
@property Byte *TACDenial; /*Terminal action code(denial) */ //[6]

/*!
 @abstract Terminal action code(online)
*/
@property Byte *TACOnline; /* Terminal action code(online) */ //[6]

/*!
 @abstract Terminal action code(default)
*/
@property Byte *TACDefault; /* Terminal action code(default) */ //[6]

/*!
 @abstract CVM Capability, 1 - CVM Required
*/
@property Byte ucCVMCap;/*DF8118  CVM Capability - CVM Required 1*/

/*!
 @abstract CVM Capability, 1 - No CVM Required
*/
@property Byte ucNoCVMCap; /*DF8119  CVM Capability - No CVM Required 1*/

/*!
 @abstract terminal risk
*/
@property Byte *aucTermRisk; /*Term Risk */ //[8]

/*!
 @abstract set the clss core to detect CVM limit automatically or not
 */
@property Byte ucRdClssTxnLmtFlg_McNoDeviceCvm;

/*!
 @abstract \xDF\x81\x24 (no on-device CVM limit)  - if on-device verification not supported -- indicates if the transaction is allowed or not
 */
@property UInt32 ulRdClssTxnLmt_McNoDeviceCvm;

/*!
 @abstract pre processing information 
 @link //apple_ref/occ/cl/MposModelCLSS_PRE_PROC_INFO @link
 */
@property MposModelCLSS_PRE_PROC_INFO *stPreProcInfo;//50 bytes

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end

