//
//  MposApiUIManager.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiRetCodes.h"

/*!
 @abstract Image type enuermation
 @constant UI_IMAGE_TYPE_BMP        BMP
 @constant UI_IMAGE_TYPE_JPG        JPG
 @constant UI_IMAGE_TYPE_PNG        PNG
 */
typedef enum {
    UI_IMAGE_TYPE_BMP = 0,
    UI_IMAGE_TYPE_JPG = 1,
    UI_IMAGE_TYPE_PNG = 2,
}UIImageType;

/*!
 @abstract Image prcessing commands enumeration
 @constant UI_PROCESS_IMAGE_CMD_LOAD        load, if loaded, will generate ".t+number" file. which can be cleaned with command @link UI_PROCESS_IMAGE_CMD_CLEAN @/link
 @constant UI_PROCESS_IMAGE_CMD_DISPLAY     display
 @constant UI_PROCESS_IMAGE_CMD_CLEAN       clean temp file
 */
typedef enum {
    UI_PROCESS_IMAGE_CMD_LOAD = 0,
    UI_PROCESS_IMAGE_CMD_DISPLAY = 1,
    UI_PROCESS_IMAGE_CMD_CLEAN = 3,
}UIProcessImageCmd;

/*!
 @abstract Language type for preset string
 @constant UI_LANG_ZH       Chinese
 @constant UI_LANG_EN       English
 */
typedef enum {
    UI_LANG_ZH = 0x00,
    UI_LANG_EN = 0x01
}UILang;

/*!
 @abstract <b><font color="red">NOTE: support for functions may vary among models</font></b><br>
 MposApiUIManager is used to control the UI, only valid for model with display screen
 */
@interface MposApiUIManager : NSObject

/*!
 @abstract encoding of the string to display, default to kCFStringEncodingGB_18030_2000
 */
@property CFStringEncoding encoding;        //default to kCFStringEncodingGB_18030_2000

/*!
 @abstract get MposApiUIManager shared instance
 @result
 MposApiUIManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract clear the screen
 @result
 return code.
 */
- (MposApiRetCode)scrCls;

/*!
 @abstract display a string. 
 @discussion
 Note that it may include special format, such as position, font, inversion etc.
 @param txt
	the string to display<br>
	support\n<br>
	support extra control as follows:
	<ul>
		<li>%Pccrr, Position control, in unit of pixel, cc stands for column(x coord.), rr stands for row(y coord.). cc and rr are in hex string format, default value is %P0000
		<li>%Ff, Font control, f is font size, ranged from 0 to 7, 8 fonts for english and chinese each.<br>
		For English,  0: 6*8, 1: 8*16, 2: 12*24<br>
		For Chinese,  0: 12*12, 1: 16*16, 2: 24*24
		<li>%Rr, Inversion control, r toggles inversion. 0 is normal, 1 is invert.
	</ul>
 @result
 return code.
 */
- (MposApiRetCode)scrShowText:(const NSString *)txt;

/*!
 @abstract get preset text with specified id and lang
 @param txt
 [output] the preset text of the specified id and lang
 @param txtId
 id of the preset string (0 ~ 9) 
 @param lang
 language type
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)scrGetTxt:(NSString **)txt byId:(Byte)txtId lang:(UILang)lang;

/*!
 @abstract set preset text with specified id and lang
 @param txt
 [input] the preset string to set
 @param txtId
 id of the preset string (0 ~ 9) 
 @param lang
 language type
 @result
 return code.
 */
- (MposApiRetCode)scrSetTxt:(const NSString *)txt byId:(Byte)txtId lang:(UILang)lang;

/*!
 @abstract display preset text with specified id and lang
 @param txtId
 id of the preset string (0 ~ 9) 
 @param lang
 language type
 @result
 return code.
 */
- (MposApiRetCode)scrShowTxtbyId:(Byte)txtId lang:(UILang)lang;

/*!
 @abstract <b><font color="red">NOTE: D180 doesn't support this function </font></b><br>
 display image
 @param name
 image file name
 @param type
 image type
 @param cmd
 command type
 @param x
 the x position to show the image
 @param y
 the y position to show the image
 @result
 return code.
 */
- (MposApiRetCode)scrProcessImageWithName:(const NSString *)name type:(UIImageType)type cmd:(UIProcessImageCmd)cmd posX:(UInt32)x posY:(UInt32)y;

/*!
 @abstract <b><font color="red">NOTE: D200 doesn't support this function </font></b><br>
 set screen backlight mode<br>
 @discussion
 default mode is 1. Not applicable for OLED.
 @param mode
 0 =off; 1=D210: auto-off after 30 seconds, other model: auto-off after 1 minute; 2 - on;
 @result
 return code.
 */
- (MposApiRetCode)scrBacklightWithMode:(Byte)mode;

@end
