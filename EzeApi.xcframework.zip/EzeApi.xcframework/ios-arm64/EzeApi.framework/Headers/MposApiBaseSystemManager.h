//
//  BaseSystemManager.h
//  MposApi
//
//  Created by admin on 5/29/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposApiRetCodes.h"
#import "MposAppInfo.h"
/*!
 @abstract data type enumeration
 @constant DATA_TYPE_EMV_PARAM_CMAC             EMV_PARAM + CMAC(8B)
 @constant DATA_TYPE_SERVER_RANDOM              auth dukpt engine no.(1B) + data dukpt engine no.(1B) + server random(16B)
 @constant DATA_TYPE_DEV_AND_SERVER_TOKEN       encrypted (device token(16B) + server token(16B))
 */
typedef enum {
    DATA_TYPE_EMV_PARAM_CMAC = 0,
    DATA_TYPE_SERVER_RANDOM,
    DATA_TYPE_DEV_AND_SERVER_TOKEN
} DataType;

/*!
 @abstract MposApiBaseSystemManager manages the basic system functionalities, including getting system information, controlling beeper etc.
 */
@interface MposApiBaseSystemManager : NSObject

/*!
 @abstract get MposApiBaseSystemManager shared instance
 @result
 MposApiBaseSystemManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract  test if terminal reachable.
 @result
    true - reachable,  false - unreachable
 */
- (BOOL)ping;

/*!
 @abstract Beeper beeps for 100ms
 @result
 return code
 */
- (MposApiRetCode)beep;

/*!
 @abstract system sleep
 @result
 return code
 */
- (MposApiRetCode)sleep;

/*!
 @abstract get app info for D180
 @param MposAppInfo
 [input] MposAppInfo contains appName, appVersion and release time
 @result
 return code
 */
-(MposApiRetCode) getAppInfo:(MposAppInfo*) appInfo;


/*!
 @abstract Set system date and time
 @param time
 [input]the date & time string, format is YYMMDDhhmmss
 @result
 return code
 */
- (MposApiRetCode)setTime:(const NSString  *)time;

/*!
 @abstract Get system date and time
 @param time
 [output]the date & time string, format is YYMMDDhhmmssww, ww stands for weekday,ranged from 01~07, corresponding to Monday~Sunday 
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getTime:(NSString **)time;

/*!
 @abstract Read the serial number of the terminal.
 @param sn
 [output]device Serial No<br>return "" if the serial number does not exists.
 @result
 	
 */
- (MposApiRetCode)readSN:(NSString **)sn;

/*!
 @abstract Read the extended serial number of the terminal.
 @param exSn
 [output]device extended Serial No<br>return "" if the serial number does not exists.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)readExSN:(NSString **)exSn;

/*!
 @abstract <b><font color="red">D180 does not support this function</font></b><br>
 reboot the terminal
 @result
 return code.
 */
- (MposApiRetCode)reboot;

/*!
 @abstract get 8 bytes true random number
 @param random
 [output]8 bytes true random number 
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pciGetRandom:(Byte[8])random;

/*!
 @abstract read the battery level
 @param level
 [output] bettery level<br>
 0 - Battery voltage low and battery icon blinks. Suggested that do not process transaction, print and wireless communication etc. at this moment. You should recharge the battery immediactely to avoid shut down and lost data. <br>
 1 - Battery icon displays 1 grid. <br>
 2 - Battery icon displays 2 grid. <br>
 3 - Battery icon displays 3 grid. <br>
 4 - Battery icon displays 4 grid. <br>
 5 - Powered by external power supply and the battery in charging.<br>
 6 - Powered by external power supply and the battery charging finished. Battery icon displays full grids.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)batteryCheck:(Byte *)level;

/*!
 @abstract Get version information of the terminal.
 @param verInfo
 [output]Version information (8 bytes)<br>
	VerInfo[0] : BOOT version number (ascending from 1) <br>
	VerInfo[1] : monitor major version number (ascending from 1) <br>
    VerInfo[2] : monitor minor version number (ascending from 1) <br>
    VerInfo[3] : main PCB hardware version number(reter to hardware version) <br>
    VerInfo[4] : interface PCB configuration information <br>
    VerInfo[5]: extended PCB configuration information <br>
    VerInfo[6]: magcard reader PCB configuration information <br>
    VerInfo[7]: Reserved
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)readVerInfo:(Byte[8])verInfo;

/*!
 @abstract Get terminal model and configuration information.
 @param termInfo
 [output]model and configuration information
 TermInfo[0]: terminal model[0x00-0xFF]<br>
	1-P60-S <br>
	2-P70 <br>
	3-P60-S1 <br>
	4-P80 <br>
	5-P78 <br>
	6-P90 <br>
	7-S80 <br>
	8-SP30 <br>
	9-S60 <br>
	10-S90 <br>
	11-S78 <br>
	12-MT30 <br>
	13-T52 <br>
	14-S58 <br>
	15-D200<br>
	16-D210<br>
	17-D300<br> 
    35-D180<br>
	0x80-R50 <br>
	0x81-P50 <br>
	0x82-P58 <br>
	0x83-R30 <br>
	0x84-R50-M <br>
	0x91-D800<br>
	TermInfo[1]: printer type <br>
	'S'-Stylus printer. <br>
	'T'-Thermal printer.
	</p>
	<p>
	TermInfo[2]: MODEM module configuration information 0 -do not
	support MODEM communication module Others -MODEM module type code
	<br>
	0x01 -TDK 73K222 1200/1200 <br>
	0x02 -TDK 73K224 2400/2400 <br>
	0x10 -Silicon 2414 14.4k/2400 <br>
	0x20 -conexant 81802 33.6k/9600 <br>
	0x40 -conextant 93001-V92 56k/9600 <br>
	0x41 -conextant 93001-V32B 14.4K/9600 <br>
	0x80 -Zilog combine Modem 14.4K/2400
	</p>
	<p>
	TermInfo[3]: MODEM highest sync. baud rate <br>
	1-1200 <br>
	2-2400 <br>
	3-9600 <br>
	4-14400
	</p>
	<p>
	TermInfo[4]: MODEM highest async. baud rate <br>
	1-1200 2-2400 3-4800 4-7200 5-9600 6-12000 7-14400 8-19200
	9-24000 10-26400 11-28800 12-31200 13-33600 14-48000 15-56000
	</p>
	<p>
	TermInfo[5]: PCI configuration information <br>
	0-no embedded PCI secure module. <br>
	Others-compliant PCI secure module.
	</p>
	<p>
	Out_info[6]: USB HOST configuration information <br>
	0 -no USB host interface. <br>
	Others-USB host interface version code.
	</p>
	<p>
	TermInfo[7]: USB device interface information <br>
	0-no dependent USB device interface. <br>
	Others-USB device interface version code.
	</p>
	<p>
	TermInfo[8]: LAN(TCP/IP)module configuration information <br>
	0 -no TCP/IP module. <br>
	Others-TCP/IP module version code.
	</p>
	<p>
	TermInfo[9]: GPRS module configuration information <br>
	0 -no GPRS module. <br>
	Others-GPRS module version code.
	</p>
	<p>
	TermInfo[10]: CDMA module configuration information <br>
	0 -no CDMA module. <br>
	Others-CDMA module version code.
	</p>
	<p>
	TermInfo[11]: WI-FI module configuration information <br>
	0 -no WI-FI module. <br>
	Others-WI-FI module version code(Invalid for S80).
	</p>
	<p>
	TermInfo[12]: Contactless reader module configuration information
	<br>
	0 -no contactless reader module <br>
	0x01 -RF interface chip is RC531 <br>
	0x02 -RF interface chip is PN512 <br>
	Only S90 can supply 'TermInfo[12] judge the chip type'.
	</p>
	<p>
	TermInfo[13]: has Chinese font library or not <br>
	0 -not Chinese font library. <br>
	1 -Chinese font library.
	</p>
	<p>
	TermInfo[14]: the version information of font library <br>
	0 -no font library file. <br>
	Others-the version number of font library.
	</p>
	<p>
	TermInfo[15]: ICC reader module configuration information <br>
	0x00 -no ICC reader. <br>
	Others-has ICC reader.
	</p>
	<p>
	TermInfo[16]: MSR reader module <br>
	0x00 -no MSR reader. <br>
	Others-has MSR reader.
	</p>
	<p>
	TermInfo[17]: has Tilt Sensor or not <br>
	0 -no Tilt Sensor. <br>
	1 -has Tilt Sensor.
	</p>
	<p>
	TermInfo[18]: has WCDMA module or not <br>
	0 -no WCDMA module. <br>
	Others-WCDMA module version code.
	</p>
	<p>
	TermInfo[19]: has touch screen or not <br>
	0 -no touch screen. <br>
	1 -has touch screen.
	</p>
	<p>
	TermInfo[20]: has bluetooth or not <br>
	0 -no bluetooth. <br>
	1 -has bluetooth.
	</p>
	<p>
	TermInfo[18]-[29]:reserved
	</p>
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)getTermInfo:(Byte[30])termInfo;

/*!
 @abstract Beep at specified frequency and lasts for specified time. Stop beep when
     any key pressed (stop respond to key pressing when the buffer is full),
     then quit the function (except On/Off key).
 @param mode
 Specify the frequencies. mode% 7 could be 0 ~ 6. <br>
     0 indicates the lowest frequency <br>
     6 indicates the highest frequency
 @param DlyTime
 Lasting time of beep(unit: ms)
 @result
 return code.
 */
- (MposApiRetCode)beepFWithMode:(UInt8)mode delay:(UInt32)DlyTime;

/*!
@abstract close the connection with POS terminal
*/
- (void)closeConnection;

/*!
 @abstract exchanged data with POS terminal
 @param type
    @link //apple_ref/c/econst/DATA_TYPE_EMV_PARAM_CMAC @/link: EMV_PARAM + CMAC(8B)<br>
    @link //apple_ref/c/econst/DATA_TYPE_SERVER_RANDOM @/link: auth dukpt engine no.(1B) + data dukpt engine no.(1B) + server random(16B)<br>
    @link //apple_ref/c/econst/DATA_TYPE_DEV_AND_SERVER_TOKEN @/link: encrypted (device token(16B) + server token(16B))<br>
 @param dataIn
    data to send to POS terminal
 @param dataOut
    data receive from POS terminal
 @result
 return code.
 */
- (MposApiRetCode)exchangeDataWithType:(UInt8)type withDataIn:(const NSData *)dataIn withDataOut:(NSData **)dataOut;

/*!
 @abstract calculate CMAC, See http://en.wikipedia.org/wiki/CMAC for details.
 @param data
    data to calculate CMAC(3DES).
 @param cmac
    CMAC, 8 bytes
 @result
 return code.
 */
- (MposApiRetCode)calcCMACForData:(const NSData *)data cmacOut:(Byte[8])cmac;

@end
