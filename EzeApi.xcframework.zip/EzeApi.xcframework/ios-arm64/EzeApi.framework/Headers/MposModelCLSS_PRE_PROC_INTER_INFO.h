//
//  MposModelCLSS_PRE_PROC_INTER_INFO.h
//  MposApi
//
//  Created by ytqk on 7/18/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract internal flag parameters which are set dynamically during preliminary transaction processing, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelCLSS_PRE_PROC_INTER_INFO : NSObject

/*!
 @abstract AID, 5~16 bytes
 */
@property Byte *aucAID;//[17];

/*!
 @abstract AID length
 */
@property Byte ucAidLen;

// payWave
/*!
 @abstract 0-transaction amount!=0; 1-transaction amount=0
 */
@property Byte   ucZeroAmtFlg; 

/*!
 @abstract whether supports status check or not
 */
@property Byte   ucStatusCheckFlg;

/*!
 @abstract Terminal transaction Qualifiers, used in VISA/PBOC, tag =9F66
 */
@property Byte *aucReaderTTQ;//[5];

/*!
 @abstract 1-the AID doen't support contactless transaction,  0- the AID support contactless transaction
 */
@property Byte   ucCLAppNotAllowed;

// common
/*!
 @abstract Whether the Terminal Floor Limit is exceeded or not, 0-no, 1-yes
 */
@property Byte ucTermFLmtExceed;

/*!
 @abstract Whether the Reader Contactless Transaction Limit is exceeded or not, 0-no, 1-yes
 */
@property Byte ucRdCLTxnLmtExceed;

/*!
 @abstract Whether the Reader CVM Required Limit is exceeded or not, 0-no, 1-yes
 */
@property Byte ucRdCVMLmtExceed;

/*!
 @abstract Whether the Reader Contactless Floor Limit is exceeded or not, 0-no, 1-yes
 */
@property Byte ucRdCLFLmtExceed;

/*!
 @abstract Is Terminal Floor Limit present? 0-no, 1-yes
 */
@property Byte ucTermFLmtFlg;

/*!
 @abstract Terminal Floor Limit, 4 bytes
 */
@property Byte *aucTermFLmt;//[5];

/*!
 @abstract reserved, 2 bytes
 */
@property Byte *aucRFU;//[2];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
