//
//  Capk.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelEMV_CAPK.h"

@interface Capk : NSObject

@property(strong, nonatomic) NSMutableArray<MposModelEMV_CAPK *> *capkList;
- (MposModelEMV_CAPK *) getSpecificApp: (Byte *)bytes keyId:(Byte)byteID;
@end
