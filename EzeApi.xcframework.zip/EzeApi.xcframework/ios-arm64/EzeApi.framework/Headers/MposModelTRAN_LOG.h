//
//  MposModelTRAN_LOG.h
//  MposApi
//
//  Created by admin on 6/11/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelCURRENCY_CONFIG.h"

@interface MposModelTRAN_LOG : NSObject

/*!
 @abstract transaction type
 */
@property Byte	ucTranType;					// 交易类型
/*!
 @abstract original transaction type
 */
@property Byte	ucOrgTranType;				// 原交易类型
/*!
 @abstract PAN, maximum 19 bytes
 */
@property Byte *	szPan;		//[19+1];				// 卡号
/*!
 @abstract expiry date, 4 bytes
 */
@property Byte *	szExpDate;	//[4+1];				// 有效期
/*!
 @abstract transaction amount, 12 bytes
 */
@property Byte *	szAmount;	//[12+1];				// 交易金额
/*!
 @abstract tip amount, 12 bytes
 */
@property Byte *	szTipAmount;	//[12+1];			// 小费金额
/*!
 @abstract original transaction amount, 12 bytes
 */
@property Byte *	szOrgAmount;	//[12+1];			// 原交易金额
/*!
 @abstract transaction date time (YYYYMMDDhhmmss), 14 bytes
 */
@property Byte *	szDateTime;		//[14+2];			// YYYYMMDDhhmmss
/*!
 @abstract authorization code, 6 bytes
 */
@property Byte *	szAuthCode;		//[6+1];
/*!
 @abstract response Code, 2 byes
 */
@property Byte *	szRspCode;		//[2+1];				// 响应码
/*!
 @abstract RRN, system ref. no, 13 bytes
 */
@property Byte *	szRRN;		//[13+1];				// RRN, system ref. no
/*!
 @abstract holder name, maximum 26 bytes
 */
@property Byte *	szHolderName;		//[26+1];        //

/*!
 @abstract transaction currency configuration
 */
@property MposModelCURRENCY_CONFIG *stTranCurrency;   //10 bytes

/*!
 @abstract holder currency configuration
 */
@property MposModelCURRENCY_CONFIG *stHolderCurrency; // 10bytes

/*!
 @abstract
 * transaction status<br/>
 * 0x0000 - transaction accepted <br/>
 * 0x0001 - transaction not sent to host <br/>
 * 0x0002 - transaction adjusted <br/>
 * 0x0004 - transaction reversed <br/>
 * 0x0008 - transaction voided <br/>
 * 0x0010 - reserved <br/>
 * 0x0020 - transaction amount less than floor limit <br/>
 * 0x0040 - offline send <br/>
 * 0x0080 - no need upload <br/>
 * 0x0100 - need upload TC <br/>
 */
@property UInt16 uiStatus;				// 交易状态

/*!
 @abstract
 * entry mode, can be used for iso8583 field 22 <br/>
 * 0x0000 - no input <br/>
 * 0x0001 - manual input <br/>
 * 0x0002 - magnetic swipe card <br/>
 * 0x0004 - EMV chip card <br/>
 * 0x0008 - EMV MSD (fallback) <br/>
 * 0x0010 - online PIN <br/>
 * 0x0020 - offline PIN (for AMEX) <br/>
 * 0x0040 - CVV/4DBC entered <br/>
 * 0x0080 - contactless <br/>
 * 0x0100 - fallback manual <br/>
 * 0x0200 - signature <br/>
 */
@property UInt16 uiEntryMode;			// 输入模式, 可计算出Bit 22

// EMV related data
/*!
 @abstract application label, 1~16 bytes
 */
@property Byte *szAppLabel;		//[16+1];
/*!
 @abstract true: PAN Seq. read OK
 */
@property Byte bPanSeqOK;					// TRUE: PAN Seq read OK
/*!
 @abstract PAN Seq. No.
 */
@property Byte ucPanSeqNo;
/*!
 @abstract AID length
 */
@property Byte ucAidLen;
/*!
 @abstract application cryptogram, 8 bytes
 */
@property Byte *sAppCrypto;		//[8];
/*!
 @abstract TVR
 */
@property Byte *sTVR;			//[6];
/*!
 @abstract TSI
 */
@property Byte *sTSI;			//[2+1];
/*!
 @abstract ATC
 */
@property Byte *sATC;			//[2+1];
/*!
 @abstract ICC data length (field 55)
 */
@property UInt16 uiIccDataLen;
/*!
 @abstract AID, 1~16 bytes
 */
@property Byte *sAID;			//[16+1];
/*!
 @abstract application preferred name, 1~16 bytes
 */
@property Byte *szAppPreferName;	//[16+1];
/*!
 @abstract ICC data (field 55), maximum 260 bytes
 */
@property Byte *sIccData;		//[LEN_ICC_DATA];

/*!
 @abstract invoice no.
 */
@property UInt32 ulInvoiceNo;			// 票据号
/*!
 @abstract STAN
 */
@property UInt32 ulSTAN;					// STAN
/*!
 @abstract original STAN
 */
@property UInt32 ulOrgSTAN;				// 原交易流水

/*!
 @abstract merchant ID, maximum 16 bytes
 */
@property Byte *uMerchantID;		//[16];
/*!
 @abstract terminal ID, maximum 9 bytes
 */
@property Byte *uPosTID;			//[9];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
