//
//  MposModelEMV_APPLIST.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract EMV application list, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_APPLIST : NSObject

/*!
 @abstract
Local application name, The string ends with '\x00' and is 32 bytes in maximum, Terminal can prompt for the application label or application preferred name of the IC card EMV application to let the cardholder to choose, But the language of the application label or application preferred name may be English and not convenient for the operator, In order to display the application name in local language, the kernel offers the setting of AppName,<br>
If AppName[0]=0, terminal will prompt for the application label or application prferred name, <br>
If AppName is set with a application name, for example, "CUP EMV Card", the application name on the terminal will be prompted as "CUP EMV Card",<br> */
@property Byte *AppName;//[33];

/*!
 @abstract Application ID, 16 bytes in maximum, (AID is corresponding to  the AppName, The kernel searchs application according to the AID)
 */
@property Byte *AID;//[17];

/*!
 @abstract AID length
 */
@property Byte AidLen;

/*!
 @abstract Application selection flag, see @link //apple_ref/c/econst/EmvAppSelFlag @/link
 */
@property Byte SelFlag;

/*!
 @abstract priority indicator(It's returned by ICC, so nothing needs to be done by application)
 */
@property (readonly) Byte Priority;

/*!
 @abstract Target percent (0~99) (provided by acquirer) (Refer to the risk management in EMV specification)
 */
@property Byte TargetPer;

/*!
 @abstract Max target percent(0~99) (provided by acquirer) (Refer to the risk management in EMV specification)
 */
@property Byte MaxTargetPer;

/*!
 @abstract check the floor limit or not (1: check, 0 : not check, default:1)
 */
@property Byte FloorLimitCheck;

/*!
 @abstract perform random transaction selection or not (1: perform, 0 : not perform, default : 1)
 */
@property Byte RandTransSel;

/*!
 @abstract perform velocity check or not (1 : perform, 0 not perform, default : 1)
 */
@property Byte VelocityCheck;

/*!
 @abstract Floor limit (provided by acquirer)(Refer to the risk management in EMV specification)
 */
@property UInt32 FloorLimit;

/*!
 @abstract Threshold (provided by acquirer)(Refer to the risk management in EMV specification)<br>
 Notes: If TargetPer=99 and Threshold=0xffffffff, all the transaction will be done online
 */
@property UInt32 Threshold;

/*!
 @abstract Terminal action code - denial (default : "\x00\x10\x00\x00\x00" (Visa140))(It must be set if acquirer provides it) 6 bytes
 */
@property Byte *TACDenial;//[6];

/*!
 @abstract Terminal action code - online (default : "\xD8\x40\x04\xF8\x00" (Visa140)) (It must be set if acquirer provides it), 6 bytes
 */
@property Byte *TACOnline;//[6];

/*!
 @abstract Terminal action code - default (default : "\xD8\x40\x00\xA8\x00" (Visa140)) (It must be set if acquirer provides it) 6 bytes
 */
@property Byte *TACDefault;//[6];

/*!
 @abstract Acquirer identifier (6 to 11 digits, stored as compressed BCD, right padded with 'F', totally 6 bytes) (It must be set if acquirer provides it, otherwise set 0x0)
 */
@property Byte *AcquierId;//[6];

/*!
 @abstract terminal default DDOL, dDOL[0] is the length of DDOL, the others are the value of DDOL,(default : "\x03\x9F\x37\x04" (Visa140))(It must be set if acquirer provides it)
 */
@property Byte *dDOL;//[256];

/*!
 @abstract terminal default TDOL, tDOL[0] is the length of TDOL, the others are the value of TDOL, (default : "\x0F\x9F\x02\x06\x5F\x2A\x02\x9A\x03\x9C\x01\x95\x05\x9F\x37\x04" (Visa140)) (It must be set if acquirer provides it)
 */
@property Byte *tDOL;//[256];

/*!
 @abstract application version (It's returned by ICC, so nothing needs to be done by application)
 */
@property (readonly) Byte *Version;//[3];

/*!
 @abstract Risk management data, RiskManData[0] is the length of Risk management data, the others are the value of Risk management data,(RiskManData[0] default : 0)(It needn't be set unless issuer requires)
 */
@property Byte *RiskManData;//[10];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;


@end
