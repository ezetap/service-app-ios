//
//  PaxImgLib.h
//  PaxImgLib
//
//  Created by kevintu@paxsz.com on 7/24/15.
//  Copyright (c) 2015 pax. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/*!
 @abstract  the algorithm to convert RGB to monochrome
 @param r   Red
 @param g   Green
 @param b   Blue
 @result    the result, 0 means black, 1 means white
 */
typedef int (^RgbToMonoAlgorithm)(int r, int g, int b);

/*!
 @abstract an helper class to convert image format
 */
@interface PaxImgLib : NSObject

/*!
 @abstract get PaxImgLib shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract set RGB to Monochrome algorithm, this will be used where neccessary
 @discussion the default algorithm is as follows:
     RgbToMonoAlgorithm defaultAlgo = ^(int r, int g, int b) {
         int v = (int)(0.299 * r + 0.587 * g + 0.114 * b);
         if (v < 128) {
             return 0;
         } else {
             return 1;
         }
     };
 @param algo    the algorithm, nil to set the algorithm to default
 */
- (void)setRgbToMonoAlgorithm:(RgbToMonoAlgorithm)algo;

/*!
 @abstract convert an UIImage object to JBIG format data
 @param image   an UIImage object
 @result    the JBIG format data, nil on error
 */
- (NSData *)uiImageToJbig:(UIImage *)image;

/*!
 @abstract convert JBIG format data to an UIImage object
 @param jbig    the JBIG format data
 @result    an UIIMage object, nil on error
 */
- (UIImage *)jbigToUIImage:(NSData *)jbig;

/*!
 @abstract convert an UIImage object to monochrome dots, with x coordinate from left to right and y coordinate from top to bottom,
 totally (width * height) bytes, each byte represents one pixel, 0 means black, 1 means white
 @param image   an UIImage object
 @result    the dots
 */
- (NSData *)uiImageToMonoDots:(UIImage *)image;

/*!
 @abstract convert an UIImage object to monochrome BMP file format
 @param image   an UIImage object
 @result    the BMP file format data, nil on error
 */
- (NSData *)uiImageToMonoBmp:(UIImage *)image;

@end
