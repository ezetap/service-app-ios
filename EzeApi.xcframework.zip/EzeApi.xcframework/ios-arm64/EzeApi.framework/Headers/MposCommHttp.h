//
//  MposCommHttp.h
//  MposComm
//
//  Created by kevintu@paxsz.com on 7/16/14.
//  Copyright (c) 2014 pax. All rights reserved.
//

#import <Foundation/Foundation.h>

#define COMM_HTTP_CON_TIMEOUT_DEFAULT   (27000)
#define COMM_HTTP_TRANS_TIMEOUT_DEFAULT (32000)

@interface MposCommHttp : NSObject <NSURLConnectionDelegate, NSURLConnectionDataDelegate>

/*!
 @abstract SSL authenticate type, default to kNeverAuthenticate
 */
@property SSLAuthenticate sslAuthType;
/*!
 @abstract whether to abort connection when redirecting
 */
@property BOOL abortWhenRedirecting;
/*!
 @abstract http headers
 */
@property (nonatomic) NSDictionary *headers;
/*!
 @abstract connection timeout, default to 27000ms
 */
@property NSInteger connectTimeout;
/*!
 @abstract data transmit timeout, default to 32000ms
 */
@property NSInteger transTimeout;

/*!
 @abstract init
 @result an MposCommHttp instance
 */
- (id)init;
/*!
 @abstract init with CA cert file name
 @param cert
    X.509 cert in PEM format, the name MUST be in "name.ext" format
 @result an MposCommHttp instance
 */
- (id)initWithCACertFileName:(NSString *)cert;

/*!
 @abstract post data
 @param reqData data to post
 @param url url
 @param respData    a pointer to a pointer of data received
 @param httpResp    a pointer to a pointer of http response
 */
- (void)postData:(NSData *)reqData to:(NSString *)url respData:(NSData **)respData httpResp:(NSHTTPURLResponse **)httpResp;

/*!
 @abstract get
 @param url url
 @param param param
 @param respData    a pointer to a pointer of data received
 @param httpResp    a pointer to a pointer of http response
 */
- (void)getFrom:(NSString *)url withParam:(NSString *)param rspData:(NSData **)respData httpResp:(NSHTTPURLResponse **)httpResp;

@end
