//
//  MposModelAPDU_RESP.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the data from ICC/PICC, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelAPDU_RESP : NSObject

/*!
 @abstract Returned data from ICC, maximum length is 512 bytes
 */
@property UInt16 LenOut;/* The actual returned data length */

/*!
 @abstract Returned data from ICC, maximum length is 512 bytes
 */
@property Byte* DataOut; /* Returned data from ICC */

/*!
 @abstract ICC status 1
 */
@property Byte SWA;/* ICC status 1 */

/*!
 @abstract ICC status 2
 */
@property Byte SWB;/* ICC status2 */

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
