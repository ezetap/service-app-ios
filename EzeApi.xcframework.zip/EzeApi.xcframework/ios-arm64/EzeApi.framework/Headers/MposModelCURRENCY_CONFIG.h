//
//  MposModelCURRENCY_CONFIG.h
//  MposApi
//
//  Created by admin on 6/11/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposModelCURRENCY_CONFIG : NSObject

/*!
 @abstract Currency name, 3 bytes (e.g. "HKD", "USD")
 */
@property Byte *szName;				//[3+1];	        // 货币简称，如"HKD","USD"
/*!
 @abstract ISO-4217 currency code, 2 bytes
 */
@property Byte *sCurrencyCode;		//[2];		// ISO-4217   货币代码，如新台币"\x09\x01"
/*!
 @abstract ISO-3166-1 country code, 2 bytes
 */
@property Byte *sCountryCode;		//[2];        // ISO-3166-1 国家或地区代码，如台湾"\x01\x58"
/*!
 @abstract currency exponent<br/>
  For example :  RMB, USD, HKD: 0x02, Korean WON: 0x00
 */
@property Byte ucDecimal;		        // 货币小数点位置。JPY为0，USD，HKD等为2，极少数货币为3
/*!
 @abstract number of digits to truncate from the right of the transaction amount(ISO8583 field 4)
 */
@property Byte ucIgnoreDigit;	 // 货币用ISO8583 bit4表示时，转换成普通金额数字串之前先忽略掉的尾数个数

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
