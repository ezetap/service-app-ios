//
//  MposModelRSA_PINKEY.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the RSA PIN KEY, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelRSA_PINKEY : NSObject

/*!
 @abstract  modulus length, in bits
 */
@property UInt32 modlen;

/*!
 @abstract  modulus, 2048 bits(256 bytes) maximum
 */
@property Byte *mod; // [256];

/*!
 @abstract  exponent length, in bits
 */
@property UInt32 expLen;

/*!
 @abstract  exponent, 1 or 3 bytes
 */
@property Byte *exp; // [4];

/*!
 @abstract  length of random number from ICC 
 */
@property Byte iccrandomlen;

/*!
 @abstract  random number from ICC, 8 bytes
 */
@property Byte *iccrandom; // [8];

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
