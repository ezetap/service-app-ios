//
//  MposCommBt.h
//  MposComm
//
//  Created by kevintu@paxsz.com on 11/13/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import "MposCommBase.h"

/*
 @abstract MposCommBt manages Bluetooth communication
 */
@interface MposCommBt: MposCommBase<MposCommInf>

/*!
 @abstract init with BT address
 @param address
    bluetooth address, either MAC address(BT2.x/3.x) or UUID(BT4.x)
 @result
    the BT instance
 */
- (id)initWithAddress:(NSString *)address;

/*!
 @abstract set BLE write type, default to CBCharacteristicWriteWithoutResponse
 @param type
    The type of write to be executed.
 */
- (void)setBLEWriteType:(CBCharacteristicWriteType)type;

@end
