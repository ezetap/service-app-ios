//
//  ByteUtils.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/9/13.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DemoUtils : NSObject

+(Byte *) stringToBytes: (NSString *)str;

+(Byte *) NSDataToByteArray: (NSData *) data;

+(BOOL *) initBoolPointer;

+(NSString*) extractPan: (NSString *)pan;

+(NSString *) getShiftedPan: (NSString *) pan;
@end
