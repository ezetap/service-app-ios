//
//  MposModelEMV_TM_ECP_PARAM.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract terminal electronic cash paramters, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_TM_ECP_PARAM : NSObject

/*!
 @abstract TSI flag present or not(TSI-Electronic cash terminal support indicator)
 */
@property Byte ucECTSIFlg;

/*!
 @abstract TSI value(TSI-Electronic cash terminal support indicator)
 */
@property Byte ucECTSIVal;

/*!
 @abstract TTL flag present or not(TTL-Electronic cash terminal transaction limit)
 */
@property Byte ucECTTLFlg;

/*!
 @abstract TTL value(TTL-Electronic cash terminal transaction limit)
 */
@property UInt32 ulECTTLVal;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
