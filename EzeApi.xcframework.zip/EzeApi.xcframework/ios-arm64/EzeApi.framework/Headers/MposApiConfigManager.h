//
//  ConfigManager.h
//  MposApi
//
//  Created by admin on 5/28/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract MposApiConfigManager manages the configuration information, including communication parameters etc.
 */
@interface MposApiConfigManager : NSObject

/*!
 @abstract communication type: "ip"/"bluetooth", default is "ip", if there's no ip module, please change this configuration
 */
@property (nonatomic, copy) NSString *commType;
/*!
 @abstract server address: in ip communication type, either an IP address or a host name, default to 192.168.100.101
 */
@property (nonatomic, copy) NSString *serverAddr;
/*!
 @abstract server port: server port in ip communication type, default to 10297, usually need not change this setting.
 */
@property (nonatomic, assign) UInt32 serverPort;
/*!
 @abstract bluetooth MAC address, default to "00:00:00:00:00:00", you MUST set this to a valid address to use bluetooth
 */
@property (nonatomic, copy) NSString *bluetoothMac;
/*!
 @abstract receive timeout, default to 2000 ms
 */
@property (nonatomic, assign) UInt32 receiveTimeout;

/*!
 @abstract get MposApiConfigManager shared instance
 @result
    MposApiConfigManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract load saved configuration
 */
- (void)load;

/*!
 @abstract save configuration
 */
- (void)save;

@end
