//
//  MposICCStatus.h
//  MposApi
//
//  Created by sunny on 2016/10/14.
//  Copyright © 2016年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposICCStatus : NSObject

/*!
 *@abstract SW1.
 */
@property Byte SW1;

/*!
 *@abstract SW2.
 */
@property Byte SW2;

@end
