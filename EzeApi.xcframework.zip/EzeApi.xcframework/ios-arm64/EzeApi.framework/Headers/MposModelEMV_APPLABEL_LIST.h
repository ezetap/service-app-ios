//
//  MposModelEMV_APPLABEL_LIST.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract application label list, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_APPLABEL_LIST : NSObject

/*!
 @abstract application preferred name, 1~16 bytes
 */
@property Byte *aucAppPreName;//[17]

/*!
 @abstract application label, 1~16 bytes
 */
@property Byte *aucAppLabel;//[17]

/*!
 @abstract Data in template "BF0C" or "73", in the format of length+value, where 1 byte for length and other bytes for value
 */
@property Byte *aucIssDiscrData;//[244]

/*!
 @abstract AID, 1~16 bytes
 */
@property Byte *aucAID;//[17]

/*!
 @abstract AID length
 */
@property Byte ucAidLen;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;


@end
