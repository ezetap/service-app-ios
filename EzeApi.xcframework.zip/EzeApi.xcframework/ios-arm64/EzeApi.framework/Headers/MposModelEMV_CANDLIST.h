//
//  MposModelEMV_APPLIST.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract EMV application candidate list, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_CANDLIST : NSObject


/*!
 @abstract application preferred name, &lt;= 16 bytes
 */
@property Byte *aucAppPreName;//[17];

/*!
 @abstract application label, &lt;= 16 bytes
 */
@property Byte *aucAppLabel;//[17];

/*!
 @abstract tag 'BF0C' data: 1 byte length + data(maximum 222 bytes), tag '73' data: 1 byte length + data(maximum 242 bytes)
 */
@property Byte *aucIssDiscrData;//[244];
/*!
 @abstract Application ID, &lt;= 16 bytes, (AID is corresponding to  the AppName, The kernel searchs application according to the AID)
 */
@property Byte *aucAID;//[17];
/*!
 @abstract AID length
 */
@property Byte ucAidLen;
/*!
 @abstract priority indicator
 */
@property (readonly) Byte ucPriority;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;


@end
