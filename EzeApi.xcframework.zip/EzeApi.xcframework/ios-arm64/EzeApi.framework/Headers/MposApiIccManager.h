//
//  MposApiIccManager.h
//  MposApi
//
//  Created by admin on 7/5/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelAPDU_SEND.h"
#import "MposModelAPDU_RESP.h"
#import "MposApiRetCodes.h"

//bit 0 ~ 2
/*!
 @abstract SLOT0 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT0 (0x00)
/*!
 @abstract SLOT1 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT1 (0x01)
/*!
 @abstract SLOT2 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT2 (0x02)
/*!
 @abstract SLOT3 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT3 (0x03)
/*!
 @abstract SLOT4 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT4 (0x04)
/*!
 @abstract SLOT5 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT5 (0x05)
/*!
 @abstract SLOT6 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT6 (0x06)
/*!
 @abstract SLOT7 bit of the ICC SLOT argument
 */
#define ICC_SLOT_BIT_SLOT7 (0x07)

//bit 3 ~ 4
/*!
 @abstract 1.8V bit
 */
#define ICC_SLOT_BIT_1_8V	(0x08)
/*!
 @abstract 3V bit
 */
#define ICC_SLOT_BIT_3V	(0x10)
/*!
 @abstract 5V bit
 */
#define ICC_SLOT_BIT_5V	(0x18)

//bit 5
/*!
 @abstract do NOT support PPS protocol bit
 */
#define ICC_SLOT_BIT_NO_PPS (0x00)
/*!
 @abstract support PPS protocol bit
 */
#define ICC_SLOT_BIT_PPS	(0x20)

//bit 6
/*!
 @abstract speed used in ATR, 9600 bit
 */
#define ICC_SLOT_BIT_9600	(0x00)
/*!
 @abstract speed used in ATR, 38400 bit
 */
#define ICC_SLOT_BIT_38400	(0x40)

//bit 7
/*!
 @abstract specification EMV bit
 */
#define ICC_SLOT_BIT_EMV	(0x00)
/*!
 @abstract specification ISO7816-3 bit
 */
#define ICC_SLOT_BIT_ISO7816_3 (0x80)

/*!
 @abstract MposApiIccManager is used to control the ICC reader to interact with the ICC.
 */
@interface MposApiIccManager : NSObject

/*!
 @abstract get MposApiIccManager shared instance
 @result
 MposApiIccManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract Reset IC card and return ATR of the card.
 @param slot
 slot number and related parameters<br>
 <ul>
 <li> bit[2:0]: bit[2:0]: channel, 0~7 channel No. 0 is half-inserted big slot(user card), 1 is full-inserted big slot, 2, 3, 4,5 are SAM card small slot
 <ul>
 <li>@link ICC_SLOT_BIT_SLOT0 @/link
 <li>@link ICC_SLOT_BIT_SLOT1 @/link
 <li>@link ICC_SLOT_BIT_SLOT2 @/link
 <li>@link ICC_SLOT_BIT_SLOT3 @/link
 <li>@link ICC_SLOT_BIT_SLOT4 @/link
 <li>@link ICC_SLOT_BIT_SLOT5 @/link
 <li>@link ICC_SLOT_BIT_SLOT6 @/link
 <li>@link ICC_SLOT_BIT_SLOT7 @/link
 </ul>
 <li> bit[4:3]: 00：5V, 01：1.8V, 10：3V, 11：5V
 <ul>
 <li>@link ICC_SLOT_BIT_5V @/link
 <li>@link ICC_SLOT_BIT_1_8V @/link
 <li>@link ICC_SLOT_BIT_3V @/link
 </ul>
 <li> bit[5]: support for PPS protocol, 0 not support PPS, 1
 <ul>
 <li>@link ICC_SLOT_BIT_PPS @/link
 <li>@link ICC_SLOT_BIT_NO_PPS @/link
 </ul>
 <li> bit[6]: speed used in ATR, 0: default(9600), 1:38400
 <ul>
 <li>@link ICC_SLOT_BIT_9600 @/link
 <li>@link ICC_SLOT_BIT_38400 @/link
 </ul>
 <li> bit[7]: specification, 0: EMV, 1: ISO7816-3
 <ul>
 <li>@link ICC_SLOT_BIT_EMV @/link
 <li>@link ICC_SLOT_BIT_ISO7816_3 @/link
 </ul>
 </ul>
 <p> you may do bit-or some of them to generate this argument  </p>
 @param atrOrNil
 [output]Answer To Reset information of the card.<br>
 as an output: Answer To Reset information of the card.<br>
 as an input, set to nil if you are not interested in ATR value.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)iccInitSlot:(Byte)slot atr:(NSData **)atrOrNil;

/*!
 @abstract Close specified contact IC card slot, switches off IC card power.
 @param slot
 see slot description of @link iccInitSlot:atr: @/link
 @result
 return code.
 */
- (MposApiRetCode)iccCloseSlot:(Byte)slot;

/*!
 @abstract Set up whether IccIsoCommand () sends Get Response instruction automatically or not
 @param slot
 see slot description of @link iccInitSlot:atr: @/link
 @param flag
 1 = auto-send<br>
 0 = do not send<br>
 Others: Invalid.
 @result
 return code.
 */
- (MposApiRetCode)iccSlot:(Byte)slot autoResp:(Byte)flag;

/*!
 @abstract IC card operation function. This function supports IC card universal interface protocol (T=0 and T=1)
 @param slot
 see slot description of @link iccInitSlot:atr: @/link
 @param send
 [input] Data structure send to IC card.
 @param resp
 [output] Data structure received from IC card.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)iccIsoCommandSlot:(Byte)slot send:(const MposModelAPDU_SEND *)send recv:(MposModelAPDU_RESP *)resp;

/*!
 @abstract Check whether card is inserted in specified slot. In-place check will take place for No.0-1 slots. Power-on and resetting will take place for No. 2-5 slots.
 @param slot
 see slot description of @link iccInitSlot:atr: @/link
 @param result
 [output] true : icc detected, false : no icc detected
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)iccDetectSlot:(Byte)slot result:(BOOL *)result;

@end
