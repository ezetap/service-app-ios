//
//  MposModelClSS_VISA_AID_PARAM.h
//  MposApi
//
//  Created by sunny on 7/23/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract describes the data of visa app id parameter, and provides interfaces to serialize data
 *into a NSData object or to read data from a NSData object
 */
@interface MposModelClSS_VISA_AID_PARAM : NSObject

/*!
 * @abstract Terminal floor limits - the same as floor limits of contact EMV
 */
@property UInt32 ulTermFLmt;

/*!
 * @abstract  01(default):only supports domestic ctless transaction
 * 00 or not present: supports international ctless transaction
 */
@property Byte ucDomesticOnly;

/*!
 * @abstract cardholder veryfy method request number
 */
@property Byte ucCvmReqNum;

/*!
 * @abstract  whether a CVM is required when the amount is higher than the Contactless CVM Required
 * Limit. 01-Signature 02-Online PIN
 * */
@property Byte *aucCvmReq;//[5]

/*!
 * @abstract default is 0, support offline transaction for all version of DDA
 * 01 - only support  offline transaction for version 01 of DDA
 */
@property Byte ucEnDDAVerNo;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
