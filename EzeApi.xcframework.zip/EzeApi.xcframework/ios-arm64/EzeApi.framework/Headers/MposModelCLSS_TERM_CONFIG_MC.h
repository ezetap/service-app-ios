//
//  MposModelCLSS_TERM_CONFIG_MC.h
//  MposApi
//
//  Created by admin on 6/6/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposModelCLSS_TERM_CONFIG_MC : NSObject

/*!
 @abstract if aucMaxLifeTimeTorn valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucMaxLifeTimeTornFlg;
/*!
 @abstract Max Lifetime of Torn Log, 2 bytes
 */
@property Byte *aucMaxLifeTimeTorn;		//[2];   /*Max Lifetime of Torn Log*/
/*!
 @abstract if ucMaxNumberTorn valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucMaxNumberTornFlg;
/*!
 @abstract Max number of Torn Log
 */
@property Byte ucMaxNumberTorn;          /*Max number of Torn Log*/
/*!
 @abstract if aucBalanceBeforeGAC valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucBalanceBeforeGACFlg;
/*!
 @abstract Balance read before GAC, 6 bytes
 */
@property Byte *aucBalanceBeforeGAC;	//[6];  /*Balance read before GAC*/
/*!
 @abstract if aucBalanceAfterGAC valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucBalanceAfterGACFlg;
/*!
 @abstract Balance read after GAC, 6 bytes
 */
@property Byte *aucBalanceAfterGAC;		//[6];    /*Balance read after GAC*/
/*!
 @abstract if ucMobileSup valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucMobileSupFlg;
/*!
 @abstract Mobile Support Indicator
 */
@property Byte ucMobileSup;                   /*Mobile Support Indicator*/
/*!
 @abstract if ucHoldTimeValue valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucHoldTimeValueFlg;
/*!
 @abstract Hold Time Value
 */
@property Byte ucHoldTimeValue;            /*Hold Time Value*/
/*!
 @abstract if aucInterDevSerNum valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucInterDevSerNumFlg;
/*!
 @abstract Interface Device Serial Number, 4 bytes
 */
@property Byte *aucInterDevSerNum;		//[4];    /*Interface Device Serial Number*/
/*!
 @abstract if ucKernelID valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucKernelIDFlg;
/*!
 @abstract Kernel ID
 */
@property Byte ucKernelID;                     /*Kernel ID*/
/*!
 @abstract if aucMsgHoldTime valid or not. 1 for yes, 0 otherwise
 */
@property Byte ucMsgHoldTimeFlg;
/*!
 @abstract Message Hold Time, 3 bytes
 */
@property Byte *aucMsgHoldTime;			//[3];       /*Message Hold Time*/

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
