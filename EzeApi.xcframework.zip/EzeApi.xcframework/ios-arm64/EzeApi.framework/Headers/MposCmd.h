//
//  Cmd.h
//  MposApi
//
//  Created by admin on 5/28/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

#define CMD 0x90
#define CMD1 0x91
#define CMD_PASSIVE 0xb0

typedef enum {
    //ped
    PED_CMD_START                   = 0x9000,
    
    PED_GET_VER                     = 0x9000,
    PED_WRITE_KEY                   = 0x9001,
    PED_WRITE_TIK                   = 0x9002,
    PED_MS_GET_PIN                  = 0x9003,
    PED_MS_GET_MAC                  = 0x9004,
    PED_MS_CALC_DES                 = 0x9005,
    PED_DUKPT_GET_PIN               = 0x9006,
    PED_DUKPT_GET_MAC               = 0x9007,
    PED_ICC_VERIFY_PLAIN_PIN        = 0x9009,
    PED_ICC_VERIFY_CIPHER_PIN       = 0x900a,
    PED_GET_KCV                     = 0x900b,
    PED_ERASE                       = 0x900d,
    PED_SET_KEY_TAG                 = 0x900f,
    PED_SET_FUNCKEY                 = 0x9014,
    PED_INJECT_KEY                  = 0x9015,
    PED_WRITE_RSA_KEY               = 0x9016,
    PED_RSA_RECOVER                 = 0x9017,
    PED_DUKPT_DES                   = 0x9018,
    PED_DUKPT_GET_KSN               = 0x9019,
    PED_DUKPT_INCREASE_KSN          = 0x9020,
    
    PED_CMD_END,
    
    //base system
    BASE_CMD_START                  = 0x9030,
    
    BASE_BEEP                       = 0x9031,
    BASE_SET_DATETIME               = 0x9032,
    BASE_GET_DATETIME               = 0x9033,
    BASE_READ_SN                    = 0x9034,
    BASE_READ_EXSN                  = 0x9035,
    BASE_PING                       = 0x9036,
    BASE_REBOOT                     = 0x9037,
    BASE_GET_RANDOM                 = 0x9038,
    BASE_BATTERY_CHECK              = 0x9039,
    BASE_SLEEP                      = 0x903a,
    GET_APP_INFO                    = 0x903b,
    BASE_READ_VER_INFO              = 0x903d,
    BASE_READ_TERM_INFO             = 0x903e,
    BASE_BEEF                       = 0x903f,
    
    BASE_CMD_END,
    
    //msr
    MSR_CMD_START                   = 0x9050,
    
    MSR_OPEN                        = 0x9050,
    MSR_CLOSE                       = 0x9051,
    MSR_RESET                       = 0x9052,
    MSR_IS_SWIPED                   = 0x9053,
    MSR_READ                        = 0x9054,
    
    MSR_CMD_END,
    
    //icc L1
    ICC_CMD_START                   = 0x9055,
    ICC_INIT                        = 0x9055,
    ICC_CLOSE                       = 0x9056,
    ICC_AUTO_RESP                   = 0x9057,
    ICC_ISOCOMMAND                  = 0x9058,
    ICC_DETECT                      = 0x9059,
    ICC_CMD_END,
    
    //picc
    PICC_CMD_START                  = 0x9060,
    
    PICC_OPEN                       = 0x9060,
    PICC_SETUP                      = 0x9061,
    PICC_DETECT                     = 0x9062,
    PICC_ISOCOMMAND                 = 0x9063,
    PICC_REMOVE                     = 0x9064,
    PICC_CLOSE                      = 0x9065,
    PICC_M1_AUTH                    = 0x9066,
    PICC_M1_READ_BLOCK              = 0x9067,
    PICC_M1_WRITE_BLOCK             = 0x9068,
    PICC_M1_OPERATE                 = 0x9069,
    PICC_LIGHT                      = 0x906a,
    PICC_INIT_FELICA                = 0x906b,
    
    PICC_CMD_END,
    
    //ui - lcd
    UI_CMD_START                   = 0x9040,
    
    LCD_CLS                         = 0x9040,
    LCD_SHOW_TEXT                   = 0x9041,
    LCD_GET_TEXT_BY_ID              = 0x9042,
    LCD_SET_TEXT_BY_ID              = 0x9043,
    LCD_SHOW_TEXT_BY_ID             = 0x9044,
    LCD_PROCESS_IMAGE               = 0x9045,
    LCD_BACKLIGHT                   = 0x9046,

    //ui - kbd
    KBD_FLUSH                       = 0x9047,
    KBD_GET_KEY                     = 0x9048,
    KBD_GET_STRING                  = 0x9049,
    KBD_GET_HZ_STRING               = 0x904a,
    KBD_BACKLIGHT                   = 0x904b,
    KBD_LOCK                        = 0x904c,
    KBD_CHECK                       = 0x904d,
    KBD_MUTE                        = 0x904e,
    KBD_HIT                         = 0x904f,
    
    UI_CMD_END,
    
    //printer
    PRN_CMD_START                   = 0x9070,
    
    PRN_SET_SPACES                  = 0x9070,
    PRN_SET_INDENT                  = 0x9071,
    PRN_SET_GRAY                    = 0x9072,
    PRN_GET_STATUS                  = 0x9073,
    PRN_STR                         = 0x9074,
    PRN_IMAGE                       = 0x9075,
    PRN_FEED                        = 0x9076,
    PRN_RESET                       = 0x9077,
    PRN_START                       = 0x9078,
    
    PRN_CMD_END,
    
    //EMV
    EMV_CMD_START                   = 0x9080,
    
    EMV_GET_PARAM                   = 0x9080,
    EMV_SET_PARAM                   = 0x9081,
    EMV_GET_TLV_DATA                = 0x9082,
    EMV_SET_TLV_DATA                = 0x9083,
    EMV_GET_SCRIPT_RESULT           = 0x9084,
    EMV_SET_PCI_MODE_PARAM          = 0x9085,
    EMV_READ_VER_INFO               = 0x9086,
    EMV_CLEAR_TRANS_LOG             = 0x9087,
    EMV_ADD_ICC_TAG                 = 0x9088,
    EMV_SET_SCRIPT_PROC_METHOD      = 0x9089,
    
    EMV_ADD_CAPK                    = 0x908a,
    EMV_DEL_CAPK                    = 0x908b,
    EMV_GET_CAPK                    = 0x908c,
    EMV_CHECK_CAPK                  = 0x908d,

    EMV_ADD_APP                     = 0x908e,
    EMV_GET_APP                     = 0x908f,
    EMV_DEL_APP                     = 0x9090,
    EMV_GET_FINAL_APP_PARA          = 0x9091,
    EMV_MOD_FINAL_APP_PAR           = 0x9092,
    EMV_GET_LABEL_LIST              = 0x9093,
    
    EMV_ADD_REVOC_LIST              = 0x9094,
    EMV_DEL_REVOC_LIST              = 0x9095,
    EMV_DEL_ALL_REVOC_LIST          = 0x9096,
    
    EMV_INIT_TLV_DATA               = 0x9097,
    EMV_APP_SELECT                  = 0x9098,
    EMV_READ_APP_DATA               = 0x9099,
    EMV_CARD_AUTH                   = 0x909a,
    EMV_PROC_TRANS                  = 0x909b,
    EMV_APP_SELECT_FOR_LOG          = 0x909c,
    EMV_READ_LOG_RECORD             = 0x909d,
    EMV_GET_LOG_ITEM                = 0x909e,
    EMV_GET_MCK_PARAM               = 0x909f,
    EMV_SET_MCK_PARAM               = 0x90a0,
    EMV_SET_TM_ECP_PARAM            = 0x90a1,
    EMV_GET_CARD_ECB_BALANCE        = 0x90a2,
    EMV_START_TRANS                 = 0x90a3,
    EMV_COMPLETE_TRANS              = 0x90a4,
    EMV_SET_CONFIG_FLAG             = 0x90a5,
    EMV_SWITCH_CLSS                 = 0x90a6,
    EMV_SET_AMOUNT                  = 0x90a7,
    EMV_READ_SINGLE_LOAD_LOG        = 0x90a8,
    EMV_GET_SINGLE_LOAD_LOG_ITEM    = 0x90a9,
    EMV_READ_ALL_LOAD_LOGS          = 0x90aa,
    
    EMV_DEL_ALL_CAPK                = 0x90ab,
    EMV_DEL_ALL_APP                 = 0x90ac,
    
    EMV_GET_LOG_DATA                = 0x90ad,
    
    EMV_GET_DEBUG_INFO              = 0x90ae,
    EMV_GET_ICC_STATUS              = 0x90af,
    
    EMV_CMD_END,
    
    //clss
    
    CLSS_CMD_START                  = 0x90c0,
    CLSS_ENTRY_READ_VER_INFO        = 0x90c0,
    CLSS_ENTRY_ADD_AID_LIST         = 0x90c1,
    CLSS_ENTRY_DEL_AID_LIST         = 0x90c2,
    CLSS_ENTRY_DEL_ALL_AID_LIST     = 0x90c3,
    CLSS_ENTRY_SET_PRE_PROC_INFO    = 0x90c4,
    CLSS_ENTRY_DEL_PRE_PROC_INFO    = 0x90c5,
    CLSS_ENTRY_DEL_ALL_PRE_PROC_INFO  = 0x90c6,
    CLSS_ENTRY_PRE_TRANS_PROC       = 0x90c7,
    CLSS_ENTRY_APPSLT               = 0x90c8,
    CLSS_ENTRY_FINAL_SELECT         = 0x90c9,
    CLSS_ENTRY_DEL_CUR_CAND_APP     = 0x90ca,
    CLSS_ENTRY_GET_PRE_PROC_INTER_FLG   = 0x90cb,
    CLSS_ENTRY_GET_FINAL_SELECT_DATA    = 0x90cc,
    CLSS_ENTRY_APP_SELECT_UNLOCK_APP    = 0x90cd,
    CLSS_ENTRY_GET_ERROR_CODE           = 0x90ce,
    CLSS_ENTRY_SET_MC_VERSION           = 0x90cf,
    
    CLSS_PBOC_READ_VER_INFO             = 0x90e0,
    CLSS_PBOC_GET_TLV_DATA              = 0x90e1,
    CLSS_PBOC_SET_TLV_DATA              = 0x90e2,
    CLSS_PBOC_SET_EMV_UNKNOWN_TLV_DATA  = 0x90e3,
    CLSS_PBOC_GET_READER_PARAM          = 0x90e4,
    CLSS_PBOC_SET_READER_PARAM          = 0x90e5,
    CLSS_PBOC_SET_AID_PARAM             = 0x90e6,
    CLSS_PBOC_ADD_CAPK                  = 0x90e7,
    CLSS_PBOC_DEL_CAPK                  = 0x90e8,
    CLSS_PBOC_GET_CAPK                  = 0x90e9,
    CLSS_PBOC_DEL_ALL_CAPK              = 0x90ea,
    CLSS_PBOC_ADD_REVOC_LIST            = 0x90eb,
    CLSS_PBOC_DEL_REVOC_LIST            = 0x90ec,
    CLSS_PBOC_DEL_ALL_REVOC_LIST        = 0x90ed,
    CLSS_PBOC_SET_FINAL_SELECT_DATA     = 0x90ee,
    CLSS_PBOC_SET_TRANS_DATA            = 0x90ef,
    CLSS_PBOC_PROC_TRANS                = 0x90f0,
    CLSS_PBOC_CARD_AUTH                 = 0x90f1,
    CLSS_PBOC_GET_CVM_TYPE              = 0x90f2,
    CLSS_PBOC_GET_TRACK1_MAP_DATA       = 0x90f3,
    CLSS_PBOC_GET_TRACK2_MAP_DATA       = 0x90f4,
    CLSS_PBOC_GET_GPO_DATA              = 0x90f5,
    CLSS_PBOC_RESEND_LAST_CMD           = 0x90f6,
    CLSS_PBOC_GET_DATA_CMD              = 0x90f7,
    CLSS_PBOC_PROC_TRANS_UNLOCK_APP     = 0x90f8,

    CLSS_CMD_END,
    
    
    
    CLSS_CMD1_START,
    
    CLSS_INTEGRATE_DOWNLOAD_CAPK                = 0x9130,
    CLSS_INTEGRATE_DOWNLOAD_APP                 = 0x9131,
    CLSS_INTEGRATE_DOWNLOAD_VISA_READER_PARAM   = 0x9132,
    CLSS_INTEGRATE_DOWNLOAD_VISA_AID_PARAM      = 0x9133,
    CLSS_INTEGRATE_DOWNLOAD_MC_READER_PARAM     = 0x9134,
    CLSS_INTEGRATE_DOWNLOAD_MC_AID_PARAM        = 0x9135,
    CLSS_INTEGRATE_DOWNLOAD_MC_TERM_CONFIG      = 0x9136,
    CLSS_INTEGRATE_DELETE_ALL_CAPK              = 0x9137,
    CLSS_INTEGRATE_DELETE_ONE_CAPK              = 0x9138,
    CLSS_INTEGRATE_DELETE_ALL_AID               = 0x9139,
    CLSS_INTEGRATE_DELETE_ONE_AID               = 0x913a,
    CLSS_INTEGRATE_TRANS_INIT                   = 0x913b,
    CLSS_INTEGRATE_TRANS_CANCEL                 = 0x913c,
    CLSS_INTEGRATE_WAIT_CARD_STATUS             = 0x913d,
    CLSS_INTEGRATE_TRANS_START                  = 0x913e,
    CLSS_INTEGRATE_TRASN_WAVE_FINISH            = 0x913f,
    CLSS_NTEGRATE_SET_TLV                       = 0x9140,
    CLSS_NTEGRATE_GET_TLV                       = 0x9141,
    
    CLSS_CMD1_END,
    
    //P2PE related, can be in diff manager
    CMD_EXCHANGE_DATA                   = 0x9110,
    CMD_CALC_CMAC                       = 0x9111,
    
    
    //env callbacks
    EMV_CALLBACK_WAIT_APP_SEL       = 0xb0b0,
    EMV_CALLBACK_INPUT_AMOUNT       = 0xb0b1,
    EMV_CALLBACK_GET_HOLDER_PWD     = 0xb0b2,
    EMV_CALLBACK_REFER_PROC         = 0xb0b3,
    EMV_CALLBACK_ONLINE_PROC        = 0xb0b4,
    EMV_CALLBACK_ADVICE_PROC        = 0xb0b5,
    EMV_CALLBACK_VERIFY_PIN_OK      = 0xb0b6,
    EMV_CALLBACK_UNKNOWN_TLV_DATA   = 0xb0b7,
    EMV_CALLBACK_CERT_VERIFY        = 0xb0b8,
    EMV_CALLBACK_SET_PARAM          = 0xb0b9,
    
    EMV_CALLBACK_PICC_ISO_COMMAND   = 0xb0ba,
    EMV_CALLBACK_ICC_ISO_COMMAND    = 0xb0bb,
    EMV_CALLBACK_PED_VERIFY_PLAIN_PIN   = 0xb0bc,
    EMV_CALLBACK_PED_VERIFY_CIPHER_PIN  = 0xb0bd,
    EMV_CALLBACK_SM2_VERIFY             = 0xb0be,
    EMV_CALLBACK_SM3                    = 0xb0bf,
    
    EMV_CALLBACK_CAND_APP_SEL   = 0xb0c0,

}MposCmdType;

@interface MposCmd : NSObject

+ (NSString  *)cmd2Str:(MposCmdType)cmd;
+ (BOOL)isCmdPassive:(MposCmdType)cmd;
+ (BOOL)mayRecvPassiveCmd:(MposCmdType)cmd;
@end
