//
//  MposDebugInfo.h
//  MposApi
//
//  Created by sunny on 2016/10/14.
//  Copyright © 2016年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposDebugInfo : NSObject

/*!
 *@abstract Assist information.
 */
@property NSData *paucAssistInfo;

/*!
 *@abstract The error code.
 */
@property int pnErrorCode;


@end