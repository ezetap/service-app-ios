//
//  MposModelClSS_MC_AID_PARAM_MC.h
//  MposApi
//
//  Created by admin on 6/6/14.
//  Copyright (c) 2014 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposModelClSS_MC_AID_PARAM_MC : NSObject

/*!
 @abstract Terminal floor limits - the same as floor limits of contact EMV
 */
@property UInt32 FloorLimit;				/*Terminal floor limits - the same as floor limits of contact EMV*/
/*!
 @abstract Threshold
 */
@property UInt32 Threshold;             /*Threshold*/
/*!
 @abstract length of UDOL
 */
@property UInt16 usUDOLLen;          /*UDOL*/
/*!
 @abstract Terminal default UDOL, valid length is usUDOLLen, maximum 256 bytes
 */
@property Byte *uDOL;		//[256];            /*Terminal default UDOL*/
/*!
 @abstract Target Percentage
 */
@property Byte TargetPer;             /*Target Percentage*/
/*!
 @abstract Maximum Target Percentage
 */
@property Byte MaxTargetPer;       /*Maximum Target Percentage*/
/*!
 @abstract Whether to do floor limits checking ?1:yes 0:no
 */
@property Byte FloorLimitCheck;     /*Whether to do floor limits checking ?1:yes 0:no*/
/*!
 @abstract Whether to do random transaction ?1:yes,0:no
 */
@property Byte RandTransSel;       /*Whether to do random transaction ?1:yes,0:no*/
/*!
 @abstract Whether to do velocity checking?1:yes,0:no
 */
@property Byte VelocityCheck;       /*Whether to do velocity checking?1:yes,0:no*/
/*!
 @abstract Terminal action code(denial), 5 bytes
 */
@property Byte *TACDenial;		//[6];       /*Terminal action code(denial) */
/*!
 @abstract Terminal action code(online), 5 bytes
 */
@property Byte *TACOnline;		//[6];       /* Terminal action code(online) */
/*!
 @abstract Terminal action code(default), 5 bytes
 */
@property Byte *TACDefault;		//[6];      /* Terminal action code(default) */
/*!
 @abstract Acquirer identification
 */
@property Byte *AcquirerId;		//[6];       /*Acquirer identification*/
/*!
 @abstract Terminal default DDOL, maximum 256 bytes
 */
@property Byte *dDOL;			//[256];           /*Terminal default DDOL*/
/*!
 @abstract Terminal default TDOL, maximum 256 bytes
 */
@property Byte *tDOL;			//[256];            /*Terminal default TDOL*/
/*!
 @abstract Application Version, 2 bytes
 */
@property Byte *Version;		//[3];           /*Application Version*/
/*!
 @abstract Merchant forced online Flag, 1: yes,0:no
 */
@property Byte ForceOnline;         /*Merchant forced online Flag, 1: yes,0:no*/
/*!
 @abstract Magnetic stripe application version, 2 bytes
 */
@property Byte *MagAvn;			//[3];          /* Magnetic stripe application version*/
/*!
 @abstract 1-card reader supports MagStripe  0-does not support
 */
@property Byte ucMagSupportFlg;                    /*1-card reader supports MagStripe  0-does not support*/
/*!
 @abstract Mag-stripe CVM Capability - CVM Required
 */
@property Byte ucMagStrCVMCapWithCVM;      /*Mag-stripe CVM Capability - CVM Required*/
/*!
 @abstract Mag-stripe CVM Capability - No CVM Required
 */
@property Byte ucMagStrCVMCapNoCVM;        /*Mag-stripe CVM Capability - No CVM Required*/
/*!
 @abstract kernel configuration
 */
@property Byte ucKernelConfig;                      /*kernel configuration*/
/*!
 @abstract reserved
 */
@property Byte ucRFU;			                       /*RFU*/


/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
