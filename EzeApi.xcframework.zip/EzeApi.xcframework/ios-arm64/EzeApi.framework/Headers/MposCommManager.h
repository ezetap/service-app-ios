//
//  MposCommManager.h
//  MposComm
//
//  Created by kevintu@paxsz.com on 5/28/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//
#import <CoreBluetooth/CoreBluetooth.h>
#import "MposCommBt.h"
#import "MposCommTcp.h"

/*!
 @abstract MposCommManager is a helper class to get communcation handle
 */
@interface MposCommManager:NSObject

/*!
 @abstract get MposCommManager shared instance
 @result
    the MposCommManager instance
 */
+ (id)sharedInstance;

/*!
 @abstract create a BT commucation shared instance
 @param address     bluetooth address(UUID for BT4.0 or above, MAC otherwise)
 @result
 the BT communcation instance
 */
- (MposCommBt *)createBtCommWithAddress:(NSString *)address;

/*!
 @abstract create a BT commucation shared instance
 @param address     bluetooth address(UUID for BT4.0 or above, MAC otherwise)
 @param connectTimeout  connection timeout(ms)
 @param sendTimeout  send timeout(ms)
 @param recvTimeout  receive timeout(ms)
 @result
 the BT communcation instance
 */
- (MposCommBt *)createBtCommWithAddress:(NSString *)address
                           connectTimeout:(NSInteger)connectTimeout
                              sendTimeout:(NSInteger)sendTimeout
                              recvTimeout:(NSInteger)recvTimeout;

/*!
 @abstract create a TCP commucation instance
 @discussion    connection timeout default to 10000ms, send/receive timeout default to 20000ms
 @param host    host name or IP address
 @param port    port
 @result
 the TCP communcation instance
 */
- (MposCommTcp *)createTcpCommWithHost:(NSString *)host
                                   port:(NSInteger)port;

/*!
 @abstract create a TCP commucation instance
 @param host    host name or IP address
 @param port    port
 @param connectTimeout  connection timeout(ms)
 @param sendTimeout  send timeout(ms)
 @param recvTimeout  receive timeout(ms)
 @result
 the TCP communcation instance
 */
- (MposCommTcp *)createTcpCommWithHost:(NSString *)host
                                   port:(NSInteger)port
                         connectTimeout:(NSInteger)connectTimeout
                            sendTimeout:(NSInteger)sendTimeout
                            recvTimeout:(NSInteger)recvTimeout;

@end
