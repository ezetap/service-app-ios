//
//  MposAppInfo.h
//  MposApi
//
//  Created by Song Liao on 2018/8/14.
//  Copyright © 2018年 paxsz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MposAppInfo : NSObject


@property NSString* appName;

@property NSString* appVersion;

@property NSString* appReleaseTime;

@end
