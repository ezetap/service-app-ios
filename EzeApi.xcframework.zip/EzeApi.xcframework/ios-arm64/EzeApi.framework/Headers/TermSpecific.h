//
//  TermSpecific.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/9/13.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TermSpecific : NSObject

+ (id)sharedInstance;

- (BOOL) hasPicc;
- (BOOL) isScr12864;

@end
