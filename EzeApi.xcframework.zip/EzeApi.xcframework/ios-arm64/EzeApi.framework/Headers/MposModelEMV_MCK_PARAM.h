//
//  MposModelEMV_MCK_PARAM.h
//  MposApi
//
//  Created by admin on 7/15/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @abstract MCK parameter, and provides interfaces to serialize data into a NSData object or to read data from a NSData object
 */
@interface MposModelEMV_MCK_PARAM : NSObject

/*!
 @abstract 0- Not supported, 1-Supported. Default value is 1
 */
@property Byte ucBypassPin;

/*!
 @abstract 0-ODC, 1-BDC,默认为BDC (ODC: Online Data Capture; BDC: Batch Data Capture)
 */
@property Byte ucBatchCapture;

/*!
 @abstract 0-ODC, 1-BDC. Default value is BDC(ODC: Online Data Capture; BDC: Batch Data Capture)
 */
@property Byte ucUseTermAIPFlg;

/*!
 @abstract 0-TRM is based on AIP of card, 1-TRM is based on AIP of Terminal,  the default value is 0.
 */
@property Byte *aucTermAIP;

/*!
 @abstract The bit4 of byte1 decide whether force to perform TRM,  "08 00"- Yes; "00 00"- No. Default value is "00 00"
 */
@property Byte ucBypassAllFlg;

/*!
 @abstract get data from this object and write to NSData
 @result
 data after serialization
 */
- (NSData *)serialToBuffer;

/*!
 @abstract get data from NSData to this object
 @param b 
 data to read
 */
- (void)serialFromBuffer:(NSData *)b;

@end
