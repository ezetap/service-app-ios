//
//  DownloadClssParam.h
//  Pax-MPOS
//
//  Created by Song Liao on 2018/8/20.
//  Copyright © 2018年 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Capk.h"
#import "ClssAid.h"
#import "ClssParam.h"
#import "EmvAid.h"
#import "MposApiClssManager.h"
#import "MposApiRetCodes.h"

@interface DownloadClssParam : NSObject

@property (strong, nonatomic) MposApiClssManager *clss;

@property (strong, nonatomic) ClssAid *clssAid;
@property (strong, nonatomic) ClssParam *clssParam;
@property (strong, nonatomic) Capk *capk;

- (void) downloadClssParam;

@end
