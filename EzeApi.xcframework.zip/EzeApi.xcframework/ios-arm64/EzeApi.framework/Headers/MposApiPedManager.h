//
//  PedManager.h
//  MposApi
//
//  Created by admin on 7/8/13.
//  Copyright (c) 2013 paxhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MposModelST_KCV_INFO.h"
#import "MposModelST_KEY_INFO.h"
#import "MposModelST_RSA_KEY.h"
#import "MposModelRSA_PINKEY.h"
#import "MposApiRetCodes.h"

/*!
 @abstract PED cipher mode enumeration
 @constant PED_DECRYPT  decryption
 @constant PED_ENCRYPT  encryption
 */
typedef enum {
    PED_DECRYPT =0x00,
    PED_ENCRYPT =0x01,
}PedCipherMode;

/*!
 @abstract Key type enumeration
 @constant PED_TLK      TLK
 @constant PED_TMK      TMK
 @constant PED_TPK      TPK
 @constant PED_TAK      TAK
 @constant PED_TDK      TDK
 @constant PED_TIK      TIK
 */
typedef enum {
    PED_TLK =0x01,
    PED_TMK =0x02,
    PED_TPK =0x03,
    PED_TAK =0x04,
    PED_TDK =0x05,
    PED_TIK =0x06,
}PedKeyType;

/*!
 @abstract MAC calculation mode enuermation
 @constant PED_MAC_MODE_ANSIX9_9    ANSIX9.9. Doing DES/TDES encryption for BLOCK1 by using MAC key. Doing DES/TDES encryption again by using TAK when and after bitwise XOR the previous encryption result with BLOCK2. Processing in turn to get the 8 bytes encryption result.
 @constant PED_MAC_MODE_1           Doing bitwise XOR for BLOCK1 and BLOCK2; Do bitwise XOR again by using previous XOR result with BLOCK3. Do it in turn and finally get the 8 bytes XOR result. Using TAK to process DES/TDES encryption for the result.
 @constant PED_MAC_MODE_ANSIX9_19   ANSIX9.19. Do DES encryption for BLOCK1 by using TAK (only take the first 8 bytes of key). The encryption result wills bitwise XOR with BLOCK2, and then doing DES encryption by using TAK again. Do it in turn and get the 8 bytes encryption result. Using DES/TDES to encrypt in the last time.
 */
typedef enum {
    PED_MAC_MODE_ANSIX9_9 =0x00,
    PED_MAC_MODE_1 =0x01,
    PED_MAC_MODE_ANSIX9_19 =0x02,
}PedMacMode;

/*!
 @abstract PINBLOCK algorithm enumeration
 @constant PED_PINBLOCK_ISO9564_0   ISO9564-0
 @constant PED_PINBLOCK_ISO9564_1   ISO9564-1
 @constant PED_PINBLOCK_ISO9564_3   ISO9564-3
 @constant PED_PINBLOCK_HK_EPS      HK EPS
 */
typedef enum {
    PED_PINBLOCK_ISO9564_0 =0x00,
    PED_PINBLOCK_ISO9564_1 =0x01,
    PED_PINBLOCK_ISO9564_3 =0x02,
    PED_PINBLOCK_HK_EPS =0x03,
}PedPinBlockCalcMode;

/*!
 @abstract variation key for DUKPT DES enumeration
 @constant PED_DUKPT_DES_WITH_MAC_KEY   MAC key
 @constant PED_DUKPT_DES_WITH_DES_KEY   DES key
 @constant PED_DUKPT_DES_WITH_PIN_KEY   PIN key
 */
typedef enum {
    PED_DUKPT_DES_WITH_MAC_KEY =0x00,
    PED_DUKPT_DES_WITH_DES_KEY =0x01,
    PED_DUKPT_DES_WITH_PIN_KEY =0x02,
}PedDukptDesKeyVarType;

/*!
 @abstract DUKPT DES calculation mode enumeration
 @constant PED_DUKPT_DES_EBC_DECRYPTION EBC decrypt
 @constant PED_DUKPT_DES_EBC_ENCRYPTION EBC encrypt
 @constant PED_DUKPT_DES_CBC_DECRYPTION CBC decrypt
 @constant PED_DUKPT_DES_CBC_ENCRYPTION CBC encrypt
 */
typedef enum {
    PED_DUKPT_DES_EBC_DECRYPTION =0x00,
    PED_DUKPT_DES_EBC_ENCRYPTION =0x01,
    PED_DUKPT_DES_CBC_DECRYPTION =0x02,
    PED_DUKPT_DES_CBC_ENCRYPTION =0x03,
}PedDukptDesCalcMode;

/*!
 @abstract <b><font color="red">NOTE: maximum number of key supported may vary among models</font></b><br>MposApiPedManager is used to manage the keys, and to perform data encryption/decryption
 */
@interface MposApiPedManager : NSObject

/*!
 @abstract get MposApiPedManager shared instance
 @result
 MposApiPedManager shared instance
 */
+ (id)sharedInstance;

/*!
 @abstract To write or derive one key to PED, including BKLK, TMK, TWK, and use KCV to check the key correction.
 @discussion
 Writing the cryptograph and plaintext of a key to the specific index position of the specific key type area. Using this function have following key points:
		1. When usScrKeyIdx=0, system considering that the aucDstKeyValue of stKey is the plaintext of key and do not judge usSrcKeyType and ucSrcKeyIdx. Write the aucDstKeyValue to ucDstKeyIdx in ucDstKeyType area directly. Only when PED_TLK does not exist, it allows plaintext to type in or download any key;<br>
		2. When PED_TLK exist,it is not allowed plaintext to write or download key. PED_TLK can be 16 or 24 byte.8 byte key is not allowed;<br>
		3. When type in PED_TLK, PED can be formatting firstly. Clear all downloaded key and write again;<br>
		4. If ucSrcKeyIdx is valid, PED consider the aucDstKeyValue of KeyInfoIn as key cryptograph, thus decrypt it by key of ucSrcKeyIdx and write the key to ucDstKeyIdx. ucDstKeyType >= ucSrcKeyType;<br>
		5. ucDstKeyLen only could be 8 or 16 or 24. If ucDstKeyLen = 8, the key could only be used for DES. If ucDstKeyLen = 16 OR 24, the key could be used for TDES;<br>
		6. If ucDstKeyType=PED_TPK, the key only be used to encrypt PIN Block. If ucDstKeyType=PED_TAK, the key can only be used for MAC encryption. If ucDstKeyType=PED_TDK, the key can only be used for DES/TDES;
 @param keyInfo
 [input]<br>
 <ul>
 <li>ucSrcKeyType: PED_TLK, PED_TMK, PED_TPK, PED_TAK, PED_TDK
 <li>ucSrcKeyIdx:
 <ul>
 <li>If ucSrcKeyType = PED_TLK,UcSrcKeyIdx = 1;
 <li>If ucSrcKeyType = PED_TMK,ucSrcKeyIdx = [1~100] (D180 [1~20]);
 <li>If ucSrcKeyType = PED_TPK or PED_TAK or PED_TDK, ucDstKeyIdx = [1~100] (D180 [1~20])
 </ul>
 <li>ucDstKeyType: PED_TLK, PED_TMK, PED_TPK, PED_TAK, PED_TDK <br>
 <li>ucDstKeyIdx:
 <ul>
 <li>If ucDstKeyType = PED_TLK, ucDstKeyIdx = 1;
 <li>If ucDstKeyType = PED_TMK, ucDstKeyIdx = [1~100] (D180 [1~20]);
 <li>If ucDstKeyType = PED_TPK or PED_TAK or PED_TDK, ucDstKeyIdx = [1~100] (D180 [1~20]);
 </ul>
 <li>iDstKeyLen: 8/16/24
 <li>aucDstKeyValue: Key plaintext or ciphertext.
 </ul>
 @param kcvInfo
 [input] <br>
 iCheckMode: Check mode
 <ul>
	<li> 0x00: No KCV check
	<li> 0x01: Perform DES/TDES encryption on 8 bytes 0x00, and use first 4 bytes as KCV.
	<li> 0x02: Perform parity check 1st, then perform DES/TDES encryption on 8 bytes "\x12\x34\x56\x78\x90\x12\x34\x56", and use first 4 bytes as KCV
	<li> 0x03: Send in data KcvData, use source key to perform specified mode of MAC on [aucDesKeyValue + KcvData], and use the result as KCV.
 </ul>
 <p>aucCheckBuf:<br>
 <ul>
	<li> iCheckMode is  0: PED wont check KCV, this data is no meaning.
	<li> iCheckMode is  1 or 2 : aucCheckBuf[0]=KCV length(4) aucCheckBuf[1]~[4] 4bytes KCV
	<li> iCheckMode is  3: aucCheckBuf[0]= KcvData Length, aucCheckBuf+1: KcvData, 
		aucCheckBuf[1+KcvDataLen]=MAC mode, see @link pedGetMacWithKeyIdx:withData:withLen:mode:macOut: @/link.
		aucCheckBuf[2+KcvDataLen]=KCV length, 
		aucCheckBuf[3+KcvDataLen]=KCV value
 </ul>
 @result
 return code.
 */
- (MposApiRetCode)pedWriteKeyWithKeyInfo:(const MposModelST_KEY_INFO *)keyInfo withKcv:(const MposModelST_KCV_INFO *)kcvInfo;

/*!
 @abstract To use usKeyIdx key calculate the MAC following the Mode algorithm, output the MAC result
 @param keyIdx
 1~100 (D180 1~20) TAK index
 @param data
 [input]The data to calculate MAC.
 @param len
 The length data to calculate MAC.
 @param mode
 MAC calculation mode
 @param macOut
 [output]8 bytes MAC result
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetMacWithKeyIdx:(Byte)keyIdx withData:(const Byte *)data withLen:(UInt32)len mode:(PedMacMode)mode macOut:(Byte[8])macOut;

/*!
 @abstract To use TDK encrypt or decrypt data by DES/TDES. Using DES or TDES depends on the key length.
 @param keyIdx
 1~100 (D180 1~20) TDK index
 @param data
 [input]The data to calculate DES.
 @param len
 Data length &lt;=1024, should be multiple of 8, right padded with 0x00s if NOT
 @param mode
 PED cipher mode
 @param dataOut
 [output]encryption/decryption result
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedCalcDesWithKeyIdx:(Byte)keyIdx withData:(const Byte *)data withLen:(UInt32)len mode:(PedCipherMode)mode dataOut:(NSData **)dataOut;

/*!
 @abstract Verify plaintext offline PIN Get plaintext PIN. Send plaintext PIN BLOCK 
     to card, according to card command and card slot number, which are 
     provided by application.
 @param iccSlot
 0x00 ICC slot number
 @param expPinLen
 [input]see expPinLen of @link pedGetPinBlockWithKeyIdx:expPinLen:withData:mode:timeout:pinBlockOut: @/link
 @param mode
 0x00 Currently only support EMV2000
 @param timeout
 The timeout of PIN entry [ms] Maximum is 300000ms.
 @param swOut
 [output]2 bytes Card response code (2 bytes: SW1++SW2)
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedVerifyPlainPinWithIccSlot:(Byte)iccSlot expPinLen:(const NSString *)expPinLen mode:(Byte)mode timeout:(UInt32)timeout swOut:(Byte[2])swOut;

/*!
 @abstract Getting value of KCV for key verification of to side,using specific key
      and algorithm to encrypt data, and then return part of cryptograph.
 @param keyType
 key type<br>
 PED_TLK, PED_TMK, PED_TAK, PED_TPK, PED_TDK
 @param keyIdx
 Index number of the key,for example:TLK,only 1 <br>
     TMK can select from 1~100 (D180 1~20).<br>
     TWK can select from 1~100 (D180 1~20).<br>
     TIK can select from 1~10 (D180 1~5).
 @param kcvInfoInOut
 [input/output] <br>
 <ul>
     <li>[input] iCheckMode iCheckMode = 0x00:using this key to process
     	DES/TDES encryption operation for data,the first 4 byte of
     	cryptograph are KCV
     <li>aucCheckBuf
     <ul>
     	<li>[input] If iCheckMode =0,aucCheckBuf[0] is the data length of required
     		operation. aucCheckBuf+1 point to required operation data
     	<li>[output] When returned correctly,aucCheckBuf point to 4 byte length of KCV.
     	<li>The length of aucCheckBuf should be multiple of 8.<br>
     	<li>If KeyType is PED_TIK, KCV value is the same as which when writing TIK with pedWriteTIK, none if not provided when writing key.
	  </ul>
 </ul>
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetKcvWithKeyType:(Byte)keyType keyIdx:(Byte)keyIdx kcvInfoInOut:(MposModelST_KCV_INFO *)kcvInfoInOut;

/*!
 @abstract Get the PED version information.
 @param ver
 PED version information.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetVer:(NSString **)ver;

/*!
 @abstract Clear all key information of PED.
 @result
 return code.
 */
- (MposApiRetCode)pedErase;

/*!
 @abstract set key tag value
 @param tag
 [input] key tag value, 8 bytes
 @result
 return code.
 */
- (MposApiRetCode)pedSetKeyTag:(const Byte[8])tag;

/*!
 @abstract Write in RSA to the PED
 @discussion
 PED can maximum support 10 set of RSA Key,and the
 maximum supported length of RSA key is 256 byte. The stored RSA is the
 pulic key or private key will be determined by the exponent length. It is
 private key if the length of key exponent is equal to modulus. PED write
 in RSA key through PedWriteRsaKey; processing RSA operation by using
 written key through PedRsaRecover. RSA key can be rewritten at any time.
 @param keyIdx
 the index of RSAKEY, [1~10];
 @param keyValue
 [input] RSA key
 @result
 return code.
 */
- (MposApiRetCode)pedWriteRsaKeyWithKeyIdx:(Byte)keyIdx keyValue:(const MposModelST_RSA_KEY *)keyValue;

/*!
 @abstract Using the RSA key which stored in PED to process RSA data operation.
 @param keyIdx
 the index of RSAKEY, [1~10];
 @param data
 [input] The data to be encrypted/decrypted, it's length MUST equals modulus length
 @param dataOut
 [output] The encrypted/decrypted data.
 @param keyInfoOutOrNULL
 [output] the output Key information, can be NULL if not interested in it.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedRsaRecoverWithKeyIdx:(Byte)keyIdx withData:(const NSData *)data recoveredData:(NSData **)dataOut keyInfo:(Byte *)keyInfoOutOrNULL;

/*!
 @abstract Setting some function of function key. When PED power on,the default
 function of CLEAR button: card holder can clear inputted PIN by pressing
 CLEAR button. Can set different functions for CLEAR button by using this
 function.
 @param key
 <ul>
 <li>0x00: if no PIN code currently (either cleared or not input yet), pressing CLEAR key will quit PIN input process and return PED_RET_ERR_INPUT_CLEAR
 <li>0x01: pressing CLEAR key only clears PIN code one by one, and won't quit if there's no PIN code.
 </ul> 
 @result
 return code.
 */
- (MposApiRetCode)pedSetFunctionKey:(Byte)key;

/*!
 @abstract Reading the KSN which will be computed at next time.
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @param ksnOut
 [output]10 bytes KSN
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetDukptKSNWithGroupIdx:(Byte)groupIdx ksnOut:(Byte[10])ksnOut;

/*!
 @abstract Increase KSN by 1
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @result
 return code.
 */
- (MposApiRetCode)pedDukptIncreaseKSNWithGroupIdx:(Byte)groupIdx;

/*!
 @abstract Write TIK into PED and optionaly check KCV.
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @param srcKeyIdx
 [0~1] The key index which is used for TIK Derivation .
 @param keyLen
 8 or 16, TIK Length, Currently supports 8 and 16 bytes.
 @param keyValue
 [input] TIK plain text(SrcKeyIdx == 0) or cryptograph(SrcKeyIdx == 1).
 @param ksn
 [input] Initial KSN.
 @param kcvInfo
 [input] kcv, see kcvInfo of @link pedWriteKeyWithKeyInfo:withKcv: @/link.
 @result
 return code.
 */
- (MposApiRetCode)pedWriteTIKWithGroupIdx:(Byte)groupIdx srcKeyIdx:(PedKeyType)srcKeyIdx keyLen:(Byte)keyLen keyValue:(const Byte *)keyValue ksn:(const Byte[10])ksn kcvInfo:(const MposModelST_KCV_INFO *)kcvInfo;

/*!
 @abstract Scan the keyboard PIN entry and output the PIN BLOCK using TPK.
 @param keyIdx
 [1~100] (D180 [1~20]) TPK index
 @param expPinLen
 Enumeration of 0-12 <br>
 Application enumerates of all possible lengths of PIN. ',' will be used to separate each number of length. If no PIN, or 4 or 6 digits of PIN are allowed, the string will be set as '0,4,6'. 0 means that no PIN is required, and pressing 'Enter' will return.
 @param data
 [input]<br>
 <ul>
 <li>if Mode=@link PED_PINBLOCK_ISO9564_0 @/link,nil, unused for ISO9564 format 0.
 <li>if Mode=@link PED_PINBLOCK_ISO9564_1 @/link,Input parameters for participation in PinBlock formatting, 8 bytes data(refer to ISO9564 standard,this data can be Random number,the transaction serial number or time stamp,etc.)
 <li>if Mode=@link PED_PINBLOCK_ISO9564_3 @/link, DataIn point to the 8 bytes data which has participated in PinBlock formatting(refer to ISO9564 standard,this data can be Random number,the transaction serial number or time stamp,etc.But the higher 4 bits and lower 4 bits of each byte should between oxA~oxF.So,if the Mode=0x02,the bottom lever will do this check for the 8 bytes data,it will return an error if does not meet the requirement.).
 <li>if Mode=@link PED_PINBLOCK_HK_EPS @/link, data is ISN [6 Bytes, ASCII code]
 </ul>
 @param mode
 PIN BLOCK format
 @param timeout
 The timeout of PIN entry [ms, Input], Maximum is 300000Ms.
 @param pinBlockOut
 [output] 8bytes PINBlock
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetPinBlockWithKeyIdx:(Byte)keyIdx expPinLen:(const NSString *)expPinLen withData:(const NSData *)data mode:(PedPinBlockCalcMode)mode timeout:(UInt32)timeout pinBlockOut:(Byte[8])pinBlockOut;

/*!
 @abstract Scan the keyboard PIN entry and output the PIN BLOCK using TIK.
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @param expPinLen
 Enumeration of 0-12 <br>
 Application enumerates of all possible lengths of PIN. ',' will be used to separate each number of length. If no PIN, or 4 or 6 digits of PIN are allowed, the string will be set as '0,4,6'. 0 means that no PIN is required, and pressing 'Enter' will return.
 @param data
 [input]<br>
 <ul>
 <li>if Mode=@link PED_PINBLOCK_ISO9564_0 @/link, nil, unused for ISO9564 format 0.
 <li>if Mode=@link PED_PINBLOCK_ISO9564_1 @/link,Input parameters for participation in PinBlock formatting, 8 bytes data(refer to ISO9564 standard,this data can be Random number,the transaction serial number or time stamp,etc.)
 <li>if Mode=@link PED_PINBLOCK_ISO9564_3 @/link, DataIn point to the 8 bytes data which has participated in PinBlock formatting(refer to ISO9564 standard,this data can be Random number,the transaction serial number or time stamp,etc.But the higher 4 bits and lower 4 bits of each byte should between oxA~oxF.So,if the Mode=0x02,the bottom lever will do this check for the 8 bytes data,it will return an error if does not meet the requirement.).
 <li>if Mode=@link PED_PINBLOCK_HK_EPS @/link, data is ISN [6 Bytes, ASCII code]
 </ul>
 @param ksnOut
 [output] current KSN
 @param pinBlockOut
 [output] 8bytes PINBlock
 @param mode
 PIN BLOCK format
 @param timeout
 The timeout of PIN entry [ms, Input], Maximum is 300000Ms.
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetPinDukptWithGroupIdx:(Byte)groupIdx expPinLen:(const NSString *)expPinLen withData:(const NSData *)data ksnOut:(Byte[10])ksnOut pinBlockOut:(Byte[8])pinBlockOut mode:(PedPinBlockCalcMode)mode timeout:(UInt32)timeout;

/*!
 @abstract Calculate MAC using DUKPT.
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @param data
 [input] data to be calculated MAC
 @param len
  length of data to be calculated MAC, &lt;= 1024, right padded with 0x00s if it's length is not multiple of 8
 @param macOut
 [output] 8bytes MAC
 @param ksnOut
 [output] Current KSN
 @param mode
 MAC mode
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedGetMacDukptWithGroupIdx:(Byte)groupIdx withData:(Byte *)data len:(UInt16)len macOut:(Byte[8])macOut ksnOut:(Byte[10])ksnOut mode:(PedMacMode)mode;

/*!
 @abstract Verify offline enciphered PIN. <br>
     Get plaintext PIN; Use RsaPinKey, which is provided by application, to encrypt plaintext PIN according to EMV standard <br>
     Send enciphered PIN to card, according to card command and card slot number, which are provided by application.
 @param iccSlot
 0x00 ICC slot number
 @param expPinLen
 Enumeration of 0-12 <br>
 Application enumerates of all possible lengths of PIN. ',' will be used to separate each number of length. If no PIN, or 4 or 6 digits of PIN are allowed, the string will be set as '0,4,6'. 0 means that no PIN is required, and pressing 'Enter' will return.
 @param rsaPinKey
 [input]RSA PIN key
 @param mode
 0x00 Currently only support EMV2000
 @param timeout
 The timeout of PIN entry [ms] Maximum is 300000ms.
 @param swOut
 2 bytes Card response code (2 bytes: SW1+SW2)
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedVerifyCipherPinWithIccSlot:(Byte)iccSlot expPinLen:(const NSString *)expPinLen rsaPinKey:(const MposModelRSA_PINKEY *)rsaPinKey mode:(Byte)mode timeout:(UInt32)timeout swOut:(Byte[2])swOut;

/*!
 @abstract Use MAC key or DES key of DUKPT to encrypt or decrypt the data which have been input into the buffer.
 @param groupIdx
 1~10(D180 1~5) DUKPT group ID
 @param keyVarType
 the variation key type of DUKPT DES
 @param iv
 [input] 8bytes IV used for CBC encryption/decryption
 @param len
 length of data to be encrypted/decrypted, &lt;= 8192, mutliple of 8.
 @param data
 [input] data to be calculated DES
 @param dataOut
 [output] data encrypted/decrypted
 @param ksnOut
 [output] Current KSN
 @param mode
 DUKPT DES caculation mode
 @result
 return code. The output value is only valid if the return code is @link //apple_ref/c/econst/MPOSAPI_OK @/link.
 */
- (MposApiRetCode)pedDukptDesWithGroupIdx:(Byte)groupIdx keyVarType:(PedDukptDesKeyVarType)keyVarType iv:(Byte[8])iv withLen:(UInt16)len withData:(const Byte *)data dataOut:(NSData **)dataOut ksnOut:(Byte[10])ksnOut mode:(PedDukptDesCalcMode)mode;

@end
